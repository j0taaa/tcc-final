# 24 — Aproximação por profundidade com erro probabilístico certificado

## Continuação atual: consumidor Mosaic (2026-10-16)

Os oito critérios de `work/consumer-v3-contract.md` antecedem a nova ponte.
O Mosaic publicado, pin36945e4b3c64913e23962e0924a8b40a84c58807, oferece um
consumidor existente de amostras e confianças conjuntas e usa profundidade3
em subesquemas arbitrários. Seus DOIS kernels GPU e minimização clássica são
controles obrigatórios; os resultados antigos não os venceram implicitamente.
A diferença candidata continua o certificado específico de24, não a ponte,
minimização, limite de pilha, tratamento de EOS ou nova teoria de parsing.

A primeira etapa SEM EOS passa5576 checks de linguagem em bytes,21220
marginais e8640 amostras CPU/CUDA, kernels externos intactos. Dados e dois
drafts de fixture que falharam ficam em `work/evidence/consumer-v3-*`.
É compatibilidade no ambiente Torch2.8 declarado, não reprodução do serving
completo Torch2.13, novos forwards, desempenho ou confirmação de publicação.
`work/consumer-v3-termination-proof.md` escreve ANTES de código o contrato
variável EOT/PAD: massa rasa da linguagem VERDADEIRA e cauda conservadora
no lexer surrogate. A implementação posterior passa8284 checks de linguagem,
28 de massa/cauda,3720 marginais nativos e1200 amostras CPU/CUDA, preservados
em `work/evidence/consumer-v3-termination-v1`. O benefício operacional continua
pendente. Não atribuir a nova evidência ao piloto V2 nem ampliar aquele gate.

Screen de recursos congelado em4c80a59 concluiu45/45:42 massas positivas e3
rasas zero,190 configurações nativas completas/corretas,20 guards estimados,
0 erros/warnings e30 checks contra massas completas exatas. Gate de
viabilidade14/15; não é vantagem temporal nem novo corpus/forward. Relatório:
`work/evidence/consumer-v3-resource-v1/report.md`. V4 escreve ANTES de código
o controle CPU simbólico competente e cache de compilação por canvas compatível:
`work/consumer-v4-cache-proof.md`. Devem entrar em todos os métodos antes de
uma alegação de custo. Objetivo científico contínuo ainda aberto.

**Vantagem de certificação demonstrada por escrito e ganho de consulta
confirmado em3/15 estados independentes, contra seis controles.** Todos30
ciclos MDLM são funcionais; novidade específica/publicação e superioridade
geral de geração não estão estabelecidas. Critérios e fases iniciais abaixo
são históricos; as decisões finais preservam também todas as perdas.
Motivação: as inferências completas22/23 ficam caras quando permitem todas as
estruturas profundas de probabilidade pequena. Um limite de profundidade
arbitrário é rápido, mas altera uma distribuição em quantidade desconhecida.
Aqui o limite só é autorizado por um certificado do erro condicionado.

## Oito critérios científicos (versão inicial, refinados abaixo)

1. **Uso real.** Preencher ou gerar JSON recursivo com uma dLLM, usando TODOS
os IDs originais e uma distribuição conjunta válida. Permitir a um serviço
escolher tolerância de erro frente ao posterior de recursão irrestrita, em
vez de trocar silenciosamente a gramática por uma de profundidade fixa.
Saída: amostra válida, marginais aproximadas e certificado de massa/distância.
2. **Novidade/significância.** Limitar pilhas, aproximar gramáticas por
autômatos, calcular probabilidades por DP e propagar erro entre kernels são
antecedentes. Denkinger2017 trata inclusive aproximação ponderada de storage;
Mohri/Nederhof2001 regularizam gramáticas ponderadas. Não reivindicá-los.
O recorte candidato é um certificado barato, sobre os eventos originais do
tokenizer, para o erro CONDICIONADO a JSON, com ligação ao decoder completo.
Precisamos conferir se este certificado já é uma aplicação descrita desses
antecedentes. Sua significância permanece aberta, não presumida pelo enunciado.
3. **Por que escolher.** Decoder finito limitado à profundidade d, com
certificado contra o posterior recursivo completo. Comparadores: inferência
completa competente por CFG/pilhas; o MESMO decoder limitado com certificado
mais simples de atingir profundidade excessiva; limites triviais de cauda.
Hipótese: um limite de massa que exige também fechamento do documento permite
usar d menor e pagar menos, mantendo a tolerância declarada. Custos completos.
4. **Prova sem código.** Se L_d é a massa válida até profundidade d e U_d
limita a massa válida acima dela, então TV <= U_d/(L_d+U_d). Calcular U_d
por lexer determinístico e contador de delimitadores, exigindo profundidade
não negativa e zero ao final, sem memória dos tipos. Isso conta cada evento
original uma vez e fornece upper bound polinomial. Provar U_d <= bound que
só observa overflow. Conectar tolerâncias por passo à trajetória com a MESMA
política de commits usando acoplamento. Não inferir exatidão global de um passo.
5. **Experimentos honestos.** Antes de timing, definir tolerâncias, d
candidatos, todos os documentos externos, controles, recursos e regra de
escolha/refusa/fallback. Usar os logits originais já arquivados como
desenvolvimento. Não excluir casos de certificados fracos ou decoder caro.
Os cinco documentos externos ainda sem forwards ficam reservados até gate.
Não medir ainda: novidade e prova vêm primeiro, depois protótipo mínimo.
6. **Custo dLLM.** Incluir tabela, full softmax, agregação de TODOS os tokens,
counter, preparação do decoder limitado, amostra, marginais e forward.
Counter precisa O(n D Q F) operações para altura máxima física D, estados
lexicais Q e efeitos F; memória streaming. Decoder limitado tem dependência
exponencial em d, não é gratuitamente linear. Aridade de tokens e bits entram.
Modelos mudam entre passos: limite da trajetória exige orçamento de erro ao
longo de TODAS as histórias e mesma política. Recursos insuficientes recusam.
7. **Objeção forte.** U_d pode ser largo demais quando validade é rara; uma
cauda absoluta pequena não basta. O decoder completo ou o certificado simples
pode ser mais barato. Aproximação ponderada existente pode já conter o recorte.
Mosaic/FactorDLM podem aproveitar o MESMO certificado; não alegar exclusividade
do decoder finito. Diferença de política baseada em marginais aproximadas pode
invalidar o acoplamento global; usar política comum, ou certificar estabilidade.
8. **Artigo.** Falta conferir o antecedente mais próximo, terminar prova/
custo, enumerar eventos originais independentemente, medir todos os controles
e confirmar externamente. Não há revisão humana, Lean novo, treinamento ou
publicação. Um certificate que sempre recusa não cumpre a utilidade desejada.

Fontes primárias: [Denkinger2017](https://arxiv.org/abs/1703.09910),
[artigo completo](https://cgi.cse.unsw.edu.au/~eptcs/paper.cgi?GANDALF2017.7.pdf=),
[Mohri/Nederhof2001, catálogo do autor](https://sites.cs.st-andrews.ac.uk/people/mn31/publications/),
[Diffinity2026](https://arxiv.org/html/2602.12468v1),
[FactorDLM](https://arxiv.org/html/2609.32900v1).

`work/specification.md` delimita o argumento. Nenhum módulo importa tentativas
mutáveis anteriores. Cada futuro protótipo terá cópias e snapshots próprios.

## Protótipo e fronteira dos antecedentes

`work/{certificate,stack_control}.py` materializa o counter e o decoder
limitado. Cópias/extrações independentes do commit cd8267f estão identificadas
por SHA256 em `work/reference-origin.json`. Seis testes enumeram massa,
marginais, bounds e a lei efetiva de sorteio, inclusive aliases, UTF8,
remasking e picos intratoken. Não são evidência de velocidade ou novidade.

[Future Validity, Nie et al.2026](https://arxiv.org/html/2605.07698v1),
seção4/teorema7 e apêndicesB/C, já relaciona erro de normalização à TV e
propaga erro local na geração autoregressiva. Nossa desigualdade elementar
e o acoplamento não são novidade genérica. O recorte que resta investigar
é um certificado DETERMINÍSTICO computável, sem ground truth da massa total,
para posterior recursivo no vocabulário completo de um passo de dLLM.
Denkinger2017, seção4.4/teorema34, já fornece bounds ponderados por abstração
de storage; não atribuir originalidade a esse princípio. Prioridade dessa
especialização e tamanho da contribuição continuam questões abertas.

[Sakharov2017](https://arxiv.org/html/1707.07670), seções3/4,
proposições1/4, já aproxima GLCs por linguagens one-counter que as contêm.
Exigir contador zero ao final e obter custo quadrático não são novidade.
Sua construção geral é não determinística, voltada ao reconhecimento e
reconstrução de árvores; nosso certificado probabilístico conta eventos
originais de um produto posicional, não a multiplicidade dessas derivações.
Essa diferença delimita a implementação, sem provar prioridade acadêmica.

Antes de timings competitivos, `work/diagnostic-protocol.json` fixa todos
os18 estados de desenvolvimento existentes, profundidades e tolerâncias.
A primeira execução verifica se o certificado consegue autorizar alguma
aproximação útil; ela NÃO confirma rapidez, geração completa ou vantagem
externa. Se não certificar, não iniciar outra infraestrutura grande.

## Refinamento: primeira ultrapassagem gramatical e continuação abstrata

Os oito critérios anteriores continuam válidos. O comparador reforçado é
agora o limite de massa descartada na primeira ultrapassagem de d por um
PREFIXO GRAMATICAL, calculado pelo próprio decoder limitado. Esse controle
não paga um counter separado. Antes de ampliar, a hipótese distintiva é
continuar esses prefixos com um counter lexical ponderado: exigir fechamento
provável, em vez de cobrar massa1 a todo futuro desconhecido. A prova em
`work/handoff-proof.md` mostra dominância simultânea sobre esse comparador
e sobre o counter independente, e uma família onde o aperto é ilimitado.
Essa família é objeto da prova, não benchmark de desempenho.

Essa operação NÃO adiciona uma nova política de commitment ou acerto
semântico. Preserva a amostra de J_d e melhora o certificado frente a J.
O custo extra é um DP de counter que ignora tipos e sintaxe somente APÓS
a primeira ultrapassagem. Abstração de storage, primeira passagem e DP são
conhecidos; novidade da combinação/aplicação continua sem confirmação.
Medir contra grammar-hit, suffix-hit, counter-closed e posterior completo.
Uma vitória contra hit lexical fraco não basta. Oráculos precisam encontrar
erros na partição de primeira ultrapassagem, inclusive quando ela ocorre
dentro de um único token que abre E fecha várias estruturas.

## Reavaliação antes de medidas competitivas

1. **Aplicação.** Preenchimento probabilístico de JSON, preservando trechos
fixos, com marginais usadas por uma política de geração. A saída é uma
distribuição conjunta válida com tolerância escolhida pelo consumidor, e não
apenas uma string que um validador aceita. O posterior é o produto de um
forward congelado da dLLM, sem alegação de qualidade semântica.
2. **Diferença científica.** `work/certificate-separation.md` prova, com um
tokenizer FIXO e documentos com campo `payload`, uma separação de poder entre
certificados. Fechamento ponderado autoriza profundidade1 e erro
`4/[3(n+1)!]`; primeira ultrapassagem gramatical exige profundidade pelo menos
`n+2` para tolerância abaixo de1/9. A implicação de espaço é exponencial
somente para compiladores de pilhas explícitas. A abstração ponderada geral
é antecedente; suficiência para publicação e prioridade específica não estão
confirmadas. A prova não pressupõe que um modelo real produza essa família.
3. **Escolha e comparadores.** Uma pessoa escolheria o método se certificados
determinísticos permitirem inferência útil mais barata frente ao posterior
completo, com erro conhecido. Grammar-hit recebe prefixos gramaticais e todos
os testes necessários existentes; suffix-hit recebe contexto lexical e
capacidade de fechamento. Quatro inferências EXATAS competentes incluem CFG
compacta, poda bidirecional, scanner epsilon e pilhas com cache. Rejeição é
controle de primeira amostra, mas não calcula massa/marginais certificadas.
4. **Benefício provado.** A separação acima independe do código. Handoff
domina simultaneamente o counter fechado e grammar-hit porque conserva a
sintaxe até a primeira ultrapassagem e relaxa só a continuação. Dominância de
bound não implica rapidez. Corolário JSON, custo em bits e a perturbação para
suportes positivos estão escritos. A amostra continua exata em J_d.
5. **Protocolo.** `work/protocol.json` fixa ANTES de timings9 métodos, todos18
estados de desenvolvimento, três rotações e erro1/1000. Regra: melhoria de
20% na mediana pareada wall E CPU e sinal favorável em todas repetições contra
TODOS seis controles obrigatórios, ou capacidade localizada com mesmos limites.
Selecionar uma variante só no desenvolvimento; zero vitórias rejeita o gate.
Somente depois, avaliar todos cinco documentos externos ainda sem forwards,
com nove rotações. Nenhuma perda será removida. `analyze.py` impede adoção
positiva de campanhas parciais e confere certificados contra massa exata.
6. **Custo completo.** Pagar conversão full-V, TODOS os d tentados, fallback,
certificado, amostra, marginais originais e o mesmo forward arquivado. Registrar
também início a frio com tabela/normalização. Controle exato usa fonte imutável
de23/v2, nunca imports de uma tentativa mutável. Inteiros/denominadores,
memória, timeouts e recusas permanecem explícitos. Ainda não é uma medição de
geração completa; essa etapa terá política comum e orçamento de trajetória.
7. **Objeções.** Um counter pode não compensar, o certificado de primeira
passagem pode ser suficiente, a CFG exata pode ser mais rápida e rejeição pode
ganhar na amostra única. Fora da família do teorema não há bound universal de
aceleração. Gramáticas ambíguas, semântica e EOS não são ampliados. O resultado
não deve ser descrito como vitória sobre execuções nativas de EPIC/FactorDLM.
8. **Pendências e evidências.** Nove oráculos pequenos passam; enumeração
independente full-V confere168 comparações sobre24 frames de uma lacuna e
1.206.192 escolhas originais (`work/evidence/full-vocabulary-oracle-v1.json`).
São testes de correção. O diagnóstico handoff congelado em f8ad7b9 conserva108
consultas: sete de18 quadros permitem d menor que grammar-hit e seis d menor
que counter-closed, em erro1/1000. Dados em
`work/evidence/handoff-feasibility-v1`. Não confirmar velocidade com esses
diagnósticos. Faltam timings competitivos, confirmação externa, ciclo dLLM,
revisão humana e redação final; não foram inventados.

Reprodução offline após o freeze, com caches originais disponíveis:

```bash
.venv/bin/python -m unittest attempts.24-certified-depth-approximation.work.test_correctness
.venv-live/bin/python -m attempts.24-certified-depth-approximation.work.run --capture .cache/a22-development-cuda-v1 --output .cache/a24-development-measure-v1
.venv/bin/python -m attempts.24-certified-depth-approximation.work.analyze --input .cache/a24-development-measure-v1 --output .cache/a24-development-decision-v1
```

Pesos de modelo, logits/cache e grandes matrizes continuam locais; snapshots
preservam fontes, protocolo, hashes e evidências declaradas. Capturas adicionais
dependem da passagem pelo gate e usam modelo/tokenizer pinados.

## Decisão completa do desenvolvimento —2026-10-10

Produtor b2dcd2e394d11d056eef04ccb2189d5f4206935f:486/486 registros,445
completos,41 recusas internas,216 verificações de certificado contra massa
exata. As DUAS variantes passam o critério previamente definido em3/18
configurações:017a7a6d-16,05dacb44-16,0ce7169f-16. Há benefício a frio nos
mesmos três. Handoff é selecionado exclusivamente pela regra de desempate
congelada. Nenhum caso apresenta melhoria forte de20% de handoff sobre
closed: o ganho prático observado pertence à família, não à alegação de
rapidez adicional do refinamento. A amostra aproximada vence os controles
de primeira saída em2/18, não18/18; rejeição continua melhor nos casos fáceis.

Todos os resultados, incluindo perdas, estão em `work/evidence/development-v1`.
O inventário das grandes matrizes registra a igualdade integral verificada
durante a execução; estas permanecem locais. Não confundir integridade do
arquivo com recomputação do solver. Captura real independente será de TODOS
os cinco documentos pinados. `capture.py` e `corpus.py` foram copiados de
23/v2 com hashes em `capture-origin.json`; não importam tentativas mutáveis.

A operação aqui continua sendo posterior aproximado J_d com certificado
contra J, massa e marginais. A nova25 investiga usar a cauda como PROPOSTA
e rejeitar apenas conclusões inválidas para amostragem exata em J. Não
transferir os timings ou a decisão positiva de24 à operação25.

## Aplicação adicional dos mesmos marginais: amplificação certificada

As oito perguntas permanecem aplicáveis. **Uso:** uma aplicação pode usar os
intervalos já produzidos para aumentar uma probabilidade de proposta paralela
da dLLM, com garantia de aumentar a massa de JSON válido. **Significância:**
a identidade de reponderação não é nova; este é um corolário útil do certificado,
não outra alegação de prioridade ou outro protagonista. **Comparador:** produto
original sem a alteração e marginais CFG exatos para a MESMA decisão de
reponderação. A alteração muda o produto; não preservar sua distribuição
original silenciosamente nem atribuir semântica à melhora sintática.

**Prova/custo:** `work/amplification.md` demonstra o multiplicador mínimo de
massa válida por comparações inteiras, sem benchmarks, incluindo a condição
na qual não alterar nada. Consulta/marginais, seleção da coordenada e cópia da
linha custam e devem ser contabilizadas. **Teste/objeção:** enumeração pequena
independente verifica o ganho real e também recusa quando não há sinal
certificado. Não é garantia de menor latência total nem melhora semântica.
**Artigo:** falta a demonstração com os inputs reais e novos forwards; ela
fica separada do protocolo de timings24 em execução. O kernel, os casos,
critérios e produtores dessa campanha continuam intactos. Intervalos úteis
não autorizam inventar superioridade de geração sobre EPIC.

## Confirmação independente concluída

Todos os1.215 registros previstos foram executados no produtor510d807:
1.071 completos,144 recusas e540 verificações contra a massa exata. Handoff,
selecionado antes da captura, confirma o gate em3/15 estados, todos com16
lacunas (8d5fc991,c87bca6a,d829cdbc). Closed obtém os mesmos três. O gate
usa medianas pareadas wall E CPU<=0.8 e sinal favorável em todas as nove
repetições contra TODOS seis controles; não exige20% em cada repetição.
As perdas e os15 estados estão em `work/evidence/independent-v1`. A amostra
aproximada confirma benefício em2/15. Isso não é resultado do sampler25.

O pacote opcional `work/evidence/first-full-head-v2/packet.zip` publica
uma captura escolhida antes de observar timings: logits originais, full
softmax, vocabulário, bytes originais, licença e hashes. A reprodução Torch
CPU é bit-exata; os demais grandes heads/matrizes permanecem locais. A política
efetiva é full-V, MASK zerado, sem top-K ou injeção de gabarito. Campos antigos
de configuração de outros experimentos não alteram essa política.

## Reavaliação para o uso iterativo, antes de novos forwards

**Uso:** preencher lacunas JSON com dLLM e escolher commitments a partir da
probabilidade condicional estrutural de cada token original, conservando o
contexto fixo. **Significância:** a política de confiança não é nova; materializa
o certificado confirmado, sem transformar tipagem em semântica. **Escolha:**
calcular intervalos certificados quando calcular todo posterior é mais caro.
O comparador de aplicação é a pilha exata imutável; controles compactos e
first-overflow continuam na campanha independente, sem vitória nativa EPIC.

**Matemática:** `work/generation-theory.md` usa a MESMA política exata para
amostras aproximadas ou completas. Se o intervalo atravessa0.8, refinar ou
calcular posterior completo, mantendo a mesma amostra. O mapa de commitments
comum permite TV final<=0.001 por acoplamento, sob recursos conclusivos.
Isso compara decoders de produtos congelados, não a lei nativa condicionada
da MDLM. **Protocolo:** `work/generation-protocol.json`, todos cinco documentos,
4/8/16 lacunas, dois métodos, uma semente,30 execuções funcionais, sem alegação
estatística de velocidade total. **Custo:** cada novo forward real, construção,
marginais, refinamentos, captura e IPC são contados; lexer pode persistir,
floresta não é reutilizada indevidamente. **Objeção:** ambiguidades de confiança
ou novos suportes podem eliminar a economia; refusas permanecem inconclusivas.
**Artigo:** faltam executar a aplicação e a auditoria de amplificação, consolidar
os resultados e obter revisão humana. Oráculo pequeno dos dois serviços CPU
passa, mas não é uma execução neural nem evidência de novidade.

## Aplicação executada, produtor d0f25fd

`work/evidence/generation-v1` conserva TODAS30 execuções funcionais:15/15
concluem em cada método, JSON válido e IDs fixos preservados,92 novos forwards
por método (184 total), zero ambiguidades não resolvidas/recusas/erros. Nenhum
refinamento adicional foi necessário nesta seed; sua implementação permanece
verificada no oráculo de fronteira. O máximo da soma de bounds no caminho
observado é0.00014004; não é TV de trajetória empiricamente medida. A garantia
global<=0.001 decorre da prova sob recursos conclusivos. Uma seed não estabelece
superioridade estatística do decoder nem equivalência das amostras pela seed.

`work/evidence/amplification-v1` guarda33/33 certificados de aumento estrito
da massa válida, com fator4. O ganho mínimo garantido varia de1.00869 a3.99995;
todos são comparados à identidade usando marginais completos originais. Não
é recomputação independente de33 produtos alterados, nem novos forwards.
A interpretação útil é a decisão matemática segura de mudar uma probabilidade
quando seu posterior estrutural justifica; uma melhoria pequena continua
publicada e custos de consulta podem impedir amortização. Não reclassificar
esta auditoria funcional como gate de velocidade.

## Entrada offline mínima da mesma implementação

`work/demo.py` empacota a operação24 sobre o head público escolhido antes de
observar resultados. As oito respostas de posterior/confiança acima continuam
válidas: não há outro método, ganho alegado, alteração da distribuição, redução
de suporte ou validação neural nova. O objetivo é permitir uso e recomputação
fora dos caches locais, preservando originais e imprimindo os intervalos do
próprio token amostrado. Preparação do lexer, leitura/check do pacote, consulta
e marginais são relatados separadamente; seu único exemplo não é benchmark
nem comprovação de velocidade. A implementação em `work/` permanece isolada
para evitar duplicar um segundo solver no núcleo de produção.

A redação da família matemática agora explicita o token de whitespace como
um único espaço ASCII0x20, permitido dentro de strings; não é tab/newline/cr.
As versões anteriores ficam preservadas. Nenhuma probabilidade capturada,
semente, método, caso ou gate experimental foi alterado. A consequência de
TV para qualquer score em[0,1] também é explícita: o decoder ideal conserva
sua esperança até o orçamento, sem provar que a referência seja boa.


Correção de fronteira de recursos após a auditoria25: a desativação do timer
agora também é coberta, e um alarme nessa fronteira recusa antes de qualquer
commit. Novo oráculo injeta essa chegada; junto do worker25 passam quatro
checks de serviço/medição (0.224s). Não altera os produtos, os certificados,
as políticas ou os30 resultados históricos, todos já concluídos sem erros;
não houve nova medição comparativa. Demo público offline usa a MESMA referência
sobre `first-full-head-v2/packet.zip`, sem modelo/GPU/network: produziu JSON
válido, delta0 neste caso e intervalos de tokens originais. É reprodução
funcional, não novo benchmark. `scripts/exact_commit/build_depth_certificate_results.py`
recalcula decisões dos1701 registros24 e702 registros25 e confere as30
transições, os IDs e bytes contra tokenizer/contextos publicados.


Fechamento de reprodução: o CI anterior não importava os novos checks porque
NumPy só existia na máquina local. O extra `dev` agora declara `numpy==2.4.6`,
mesmo pin já presente nas constraints; o núcleo continua sem dependência de
modelo/Torch. Isso permite que `make bootstrap`, testes e demo funcionem em
instalação limpa. Não é melhoria do algoritmo nem nova medição; validação limpa
e resultado real de CI são registrados separadamente.

## Consumidor V2: nova avaliação integral, sem nova alegação de teoria

O contrato e as oito respostas estão em `work/consumer-v2-contract.md`, com
prova de equivalência em `work/consumer-v2-proof.md`. A operação consome uma
conclusão conjunta e as decisões de confiança necessárias para até quatro
commits. Agregação numérica e consultas esparsas são clássicas e são oferecidas
aos controles; não constituem nova teoria. Os quinze estados externos antigos
agora são DESENVOLVIMENTO conhecido, não confirmação independente.

O produtor a5219c5 encerrou540/540 operações: zero erros/recusas,4/15 estados
passam contra todas as interfaces de pilha/first-overflow/sufixo igualmente
otimizadas. O suplemento imutável8541f4f encerrou180/180:144 conclusões,
36 recusas de recursos e99 comparações de massa exata sem divergências.
Os quatro estados anteriores sobrevivem; parte envolve capacidade sob3GiB,
que não equivale a vitória de latência contra os controles recusados.
Fontes, protocolos e registros integrais estão em `work/consumer_v2/` e
`work/evidence/consumer-v2-{development,compact}`.

Antes de novos heads, `work/consumer-v2-neural-protocol.json` define270
trajetórias: todos15 estados, nove métodos e duas seeds novas. Cada canvas
novo paga um forward real, captura, hash, IPC, consulta e saída. CPU inclui
pai e serviço filho. Custos a frio são reconstruídos das preparações medidas,
não novas execuções a frio; recusas e erros permanecem no denominador.
O auditor compara literalmente cursor/full-sparse e confere os certificados
contra massas completas disponíveis para o mesmo canvas/head. As sementes
servem a um piloto; não demonstram qualidade semântica, independência do
corpus, ganho sobre EPIC nativo ou originalidade suficiente para publicação.
O resultado pode consolidar utilidade deste consumidor específico; permanece
necessário justificar um consumidor externo e conferir a novidade da A24.

O piloto foi concluído no produtor `451de4199be5f9884d4c84e886862f314880b571`.
Os resultados derivados, incluindo TODOS os quinze estados, estão em
[`work/evidence/consumer-v2-neural-v1/decision.md`](work/evidence/consumer-v2-neural-v1/decision.md).
São270 registros,246 conclusões/24 recusas,1345 forwards novos mais um warmup.
A candidata conclui30/30; as interfaces esparsas preservam literalmente30
trajetórias e735 checks conferem o certificado contra a massa exata disponível.
O ganho integral quente sobrevive em2/15 estados contra todos os controles
que concluem. Nesses dois, três controles compactos recusam por recursos;
nenhum estado oferece vitória de tempo com TODOS seis controles concluídos.
O resultado de consulta4/15 no desenvolvimento não se transforma em4/15
ganhos de geração. As perdas, os custos e as recusas permanecem publicados.

Não há corpus novo independente, tarefa semântica ou execução nativa de EPIC.
O benefício medido é para este consumidor de posterior/commit com modelo e
serviço preparados. A fronteira de custo e os limites da lei gerenciada estão
explicitados no relatório. O comando e o alcance da reprodução estão em
[`work/consumer-v2-reproduction.md`](work/consumer-v2-reproduction.md); os3,43GB
de heads completos permanecem locais, sem alegação de pacote offline completo.
A rechecagem primária delimitada em `work/consumer-v2-primary-refresh.md`
reforça que truncamento, abstrações, marginais e consultas esparsas são
antecedentes. Originalidade suficiente e aplicação externa útil continuam
obrigações reais; o piloto não encerra a meta científica do usuário.
