# TASKS.md — Certified grammar inference for dLLMs

## How to use this file

This is the authoritative checklist for current and future work. `AGENTS.md`
defines stable scientific invariants; accepted ADRs explain the maintained
design. `IMPLEMENTATION_PLAN.md` now indexes those sources and the archived
legacy Portuguese plan. Detailed completed evidence through M12 is archived in
[`docs/history/TASKS-through-M12.md`](docs/history/TASKS-through-M12.md),
which preserves links to the earlier history files.

Status convention: `[ ]` incomplete, `[x]` completed with immutable evidence,
and `BLOCKED:` a concrete gate failure. Complete required tasks in dependency
order, never substitute measurements with estimates, and do not redo a closed
milestone unless a regression invalidates its evidence.

## Current starting point

The historical article centers on M44/T4406: confirmed3/15 independent query
advantage under its original comparators, written certificate separation and
complete30/30 neural application. Later M73's full consumer comparison fails
0/15 against stronger GPU symbolic controls; do not present the historical
result as current general superiority. A58's synthetic head resource gate
also fails for all eight candidates. The positive scientific goal remains OPEN.
A25 is a separately preregistered exact-sampling evaluation and cannot inherit
query timings. M42/M43 and earlier
conditional branches below are historical; failed development gates do not
require executing their untriggered independent campaigns. Do not reopen them
or restore removed infrastructure. Human review/publication remain external.
The renewed user goal requires a defensible original contribution, not only
consolidating A24. M69/V29 reconstructs A49's advertised bound by a competent
classical composition and downgrades its claimed separating advantage. Its
precision/storage application stays negative. M70/A50 investigates exact
grammatical residual sampling: written upper-profile/provenance theorem,
single preparation and conditional attempts independent of1/TV. Correctness
oracles pass, but publication significance, novelty and useful full-generation
cost remain open. No new neural campaign is credited to M70.

- [x] T7520-preflight: V18 six moment/certificate/selection oracles, full279
  PASS86.714s, make check/Ruff; synthetic48 full-V and FAKE8960 pipeline pass.
  Freeze80 sources/runtime/five inputs BEFORE real V18 auxiliaries.
- [x] T7520: Execute ALL8960 old-head conditional auxiliaries and frozen2268
  necessity tables; retain negative/inconclusive estimates. No new forwards,
  decoder paths, labels or updates; not full-cost/population/RLOO validation.
  Producer c28da4a completes8960/8960; both frozen families NEGATIVE, ratios
  .9864/.9121 fail .8 with optimistic zero extra cost. Independent AFTER-data
  8960-answer/1258878-coordinate check passes1.522e-14. No large fresh neural
  campaign/training triggered; see work/conditional-result-v18.md. Goal OPEN.

## M91 — Constant-query residual sampling, before a complete sampler

- [x] T9100: Revalidated previous goal turn as PROGRESS: T9002 is closed and
  synced25b6eb4; no live scientific process, only unrelated PDF untracked.
  New A68 eight criteria/proof/protocol BEFORE code adopts the CLASSICAL n-1
  operator. Candidate f-independent HG residual envelope has mass<=9H/(8m^1.5),
  allowing <=9 callback calls per full output under enlarged2H gap. Input
  mean n0+24H/sqrt(n0) explicitly exceeds tighter classical control. Original
  Morina2.4/2.5, Lee AppendixC and2510.01941v2 scopes read: importance/sign/
  nonadaptive principles known. Own quantitative specialization/priority/use
  still open. No new implementation/execution at this written stage.
- [ ] T9101: Freeze minimal independent coefficient/law auditor, then execute
  ALL specified six functions/old16,64/new k. Check every residual/envelope/
  probability/law/callback count and finite exact-evaluation lower-bound
  instance, retaining tighter/direct controls. No full sampler or frequency
  proof of exactness; failures preserved. Protocol68/work/protocol-v1.json.
- [ ] T9102: Determine whether the quantitative query advantage survives
  equally informed coefficient-free, signed-estimation, importance and lazy
  integration controls, with input/bit/preparation costs and real consumer.
  No production implementation/campaign/article promotion from correctness
  alone. T9005/T8809/T8903 and positive goal stay OPEN until enough evidence.
- [ ] T9103: Preserve source/proof/evidence independently, run appropriate
  checks, normal commit/push and verify upstream. No maintained345-test rerun
  solely for isolated mathematical audit or change to earlier frozen attempts.

## M90 — Effective value-only smooth Bernoulli factory, before implementation

- [x] T9000: Reassess closed applications and primary antecedents BEFORE a
  new prototype. A67 eight criteria/proof/protocol define another justified
  theoretical/library scope: three-value corrected coefficients, explicit
  power-of4 consistency and positive-mixture count independent of p-coins.
  Candidate EN=n0+12(M+H)/sqrt(n0), with separate full-bit arithmetic contract.
  HNP already supplies smooth finite-mean capability; no invention of that
  fact, finite differences, Bernstein or mixture/binary-splitting principles.
  Specific priority/useful consequence remains unconfirmed. At that written
  stage, no code/sampling/model/head/gold/forward/update/timing. See theory-v1.
- [x] T9001: Freeze coefficient reference/independent auditor14b2b7a after
  written contract9a22308; one execution PASS/direct0. All2034 coefficient/
  derivative/denominator checks,1932 independent power-basis elevations,
  1356 mixture bounds,126 rational bracket points,9 refusals36 controls pass.
  No full sampler, p-coin sampling, fast-bit engine, model/head/gold/forward or
  timing. Polynomial closed-form controls are MUCH cheaper; retained explicitly.
  Raw a67_local_bernstein_v1_initial; full scope67/work/result-v1.md. No naive
  unit-cost Fraction or empirical-frequency proof of exactness is claimed.
- [x] T9002: Original author2004 Section2.2 and independent quadratic
  reproduction derivation yield classical n-1 control with SAME three-value
  stencil. Written contract/proof1f86722 before source2b3c338/ONE PASS/direct0:
  2034 coefficients/calls/derivatives/denominators,1932 independent elevations
  and both discrepancy bounds,1017 mixture bounds126 bracket points63 exact
  quadratic points21/322 moment laws12 guards. Explicit delta=H/n^(3/2),
  same finite-mean/full-bit route, spline E N=41/2 vs V1's91/4, ANALYTICAL.
  V1's proposed generic locality/effective separation is WITHDRAWN. No full
  sampler/p-coins/model/head/gold/forward/timing or next campaign; no own
  publication result. V1 remains intact; result67/work/result-v3.md. Goal OPEN.
- [x] T9003: Preserve independent v1-local-coefficient-audit, source14b2b7a/
  evidence5bb6dc7,724 files11,395,054 bytes; create+original-Git comparison PASS.
  Four frozen source/proof/protocol hashes agree; focused own Ruff/format2 PASS.
  Maintained345 tests NOT rerun. Final make check directly exits0:67 attempts,
  262 versions,198556 files7,957,239,050 bytes. Full receipts in
  docs/evidence/a67-v1-final-{make-check.log,verification.json}. Integrity is
  not proof of own novelty, full-cost benefit or achieved user goal.
- [x] T9004: V3 independent archive source2b3c338/evidence734d652,735 files
  11,420,922 bytes; create+original-Git comparison/direct0. Seven frozen hashes
  and four unchanged V1 files agree with original Git; focused Ruff/format2
  PASS. Final make check/direct0:67 attempts263 versions199291 files
  7,968,659,972 bytes. Receipts docs/evidence/a67-v3-final-{make-check.log,
  verification.json}. Normal commit/push followed; no new science case or
  maintained345-test rerun. Integrity is not the positive scientific objective.
- [ ] T9005: Before further substantial implementation, identify a useful
  own consequence beyond the equally informed local classical control, or
  justify another operation from primary sources. Do not tune degree/stencil/
  constants merely to reopen the withdrawn generic advantage. T8809/T8903 and
  the positive scientific objective remain open.

## M89 — Adaptive typed-read interface audit, classical correction only

- [x] T8900: Identify distinct actual operation in vLLM source pinb05ede56;
  copy Apache2 source/README/LICENSE independently with hashes. Read auto
  controller and aggregation; write eight criteria, bias/conditional-order
  proof and prospective small-packet protocol BEFORE reference/replay.
  Originality sufficient for a protagonist is unsupported; no model/head/
  tokenizer/gold/forward. A53 duplicates the abandoned stopping lead; no
  new A53/A65 old-path replay or asynchronous-tool prototype is selected.
- [x] T8901: Freeze reference/auditor38cd351 AFTER contractb68f8b9, execute
  unchanged decide_group/read_many with
  stub packet acquisition, independently check all rational laws/caps and
  same request/seed accounting, retain unfavorable MSE comparisons and the
  identical classical control. One audit PASS/direct0:48 cases,2308 tapes/
  conditional-order controls,480 exact covariance entries;587 body executions
  (586 successful,1 expected failure),1422 SYNTHETIC packet calls,5 refusals.
  Zero real forwards. Analytical bias±1533/16384 verified; native MSE can be
  LOWER, not universal superiority. No corrected stderr/neural iid certificate.
  All raw records/log/after-run receipt in a66_adaptive_readout_v1_initial;
  see66/work/result-v1.md. Maintained345 tests not rerun.
- [x] T8902: Preserve complete bounded audit and source pins in independent
  v1-adaptive-packet-audit, source38cd351/evidenced0a60ac; create+Git comparison
  PASS727 files11,470,764 bytes. Five own hashes match original producer Git,
  three external hashes intact. Focused Ruff/format3 files PASS; full maintained
  345 tests NOT rerun. Final make check directly exits0:66 attempts261 versions
  197832 files7,945,843,996 uncompressed bytes. Receipts in
  docs/evidence/a66-v1-final-{make-check.log,verification.json}. Preservation
  does not certify a neural result or sufficient scientific originality.
- [ ] T8903: Establish a substantive OWN useful contribution before another
  large prototype/campaign. A66's conditioning control is identical to a
  classical method; native auto can have lower MSE. No neural/quality followup
  or article promotion follows from this audit. Overall goal/T8809 stay OPEN.

## M88 — Terminal numerical forecast readout for the real Mosaic/JevBench consumer

- [x] T8800: Inspect actual external consumer BEFORE a new prototype. Read-only
  Mosaic36945e4b runner/data/scoring/grammar/native sampler sources: final valid
  commit reprojects log-marginals, temperature0 still samples paths, native
  numbers have<=2 decimals. Eight MIT files copied/hashed, no vendor execution.
  RAIL2024 original Sections1--3.2/Algorithm1/Table1 and forecasting2025 III-B
  establish mean/MBR precedents. Consumer/theory2277130 before all code. No
  task/gold data files, model/tokenizer instance, weights or forward. Published
  aggregates and ONE concrete documentation task example HAVE been read;
  work/exposure-addendum-v2.md discloses hard-sol-b-judge_hard-18. No pristine
  independent-corpus claim. Actual26B/48GB setup not reproduced on local12GB.
- [x] T8801: Prospective oraclesb470a72/source70ad390 BEFORE execution. Three
  rational oracles PASS/direct exit0:414 kernel leaves1176 abstract helper
  calls/four invalid guards;414 whole-absorbing leaves/seven original paths,
  unchanged model-step/failure probabilities;78 rounding comparisons and wrong
  normalization counterexample. Positive all-gold squared-risk identity is
  CLASSICAL and assumes exact same conditional terminal kernel. No new native
  or neural execution; JSON native_model_step_law is a SYNTHETIC control.
  No maintained full-suite rerun. Results/evidence8009d75 in65/work/result-v2.md.
- [x] T8802: Native correctness only: contract/source copies3a2b57e before
  adapter/oracle/runner3e62727. First actual run ERROR after16 CPU rows; exact
  failed draft preserved. Written correctionc5a571b before runner2f55fc4 and
  whole repeat PASS48/48 CPU/CUDA,96 full native steps/560 proposals including
  320 helpers. Literal original IDs/tensors/control/RNG and post-advance cloned
  kernel survive. Eight original partial outputs skip helpers; all320 actual
  helpers complete. Incomplete native paths are independently enumerated, not
  claimed as observed incomplete-helper draws. Max marginal error1.9074e-6,
  120 exact post-run mean recomputations,14 native-source hashes unchanged.
  Evidencee8ddb26,65/work/native-result-v4.md. SYNTHETIC logits only, no model/
  pretrained tokenizer/data row/forward/update/competitive timing. AST original
  functions, NOT full vLLM serving. Literal replay does not prove finite-RNG iid.
- [x] T8803: Freeze and execute the DISTINCT small Tiny-A2D/Mosaic MASKED
  application, not original26B reproduction. Protocol7c79ad5 before selector
  dabfd45/8 hash-ranked inputs. Gold bytes decoded to discard, no values used.
  V7 fake-loop source1986ecc before16/16 CPU/CUDA PASS; V8 producer04c8cf9
  before real tokenizer/model. Tokenizer preflight8/8; real capture3fbb952
  finishes ALL8 valid originals/129 real forwards,0 errors/refusals/updates.
  Only1/8 passes ideal N7 risk-removal>=0.005, versus required4/8. Necessary
  gate NEGATIVE, all favorable/unfavorable data retained. Tiny16-step64-slot
  application CLOSED; no relabeled mean/breadth gate or quality/seed/model
  expansion. DP/MAP/normalized controls paid; diagnostic IO-dominated timing
  is not latency superiority. Overall own novelty/use/positive goal OPEN.
  Result65/work/native-resource-result-v8.md; evidence7ea716b plus RNG540c988.
- [x] T8807: V7 native MASKED-loop literal replay in Torch2.8, source1986ecc
  after prospective7c7ce15, complete16/16 CPU/CUDA/float32/BF16 cases.290 FAKE
  heads (288 paired calls+2 support diagnostics),128 helpers; full original
  IDs/inputs/logit bits/RNG and final4-mask commit preserved. Shared sparse DP/
  original-ID word MAP agree with independent enumeration, including partial
  support. Evidence62b7b79. No pretrained model/forward in this prerequisite.
- [x] T8808: POST-capture auditorf64a129 independently validates129 retained
  heads,8 BF16 expansions, all prompts/mask progress/pins,72 byte-BPE JSONs,
  24 exact Fraction means/renderings/64 helpers, binomial formula and negative
  decision. No model/gold evaluation/new forward. Codec21b8a9d losslessly
  roundtrips137 ORIGINAL NPZ byte SHA256; RNG/metadata copied byte exactly.
  Data/running/source commits distinguished, raw packets preserved separately.
  Standalone restoration540c988 PASS/direct0 restores ALL279 original files/
  2,023,497,815 bytes, including137 NPZ byte hashes/137 RNG packets. All280
  encoded files are tracked; complete whole-archive receipt below.
- [ ] T8809: Re-establish a grounded operation and plausible OWN positive
  comparative consequence before the next substantive prototype. No relaxing
  A65's negative Tiny gate, larger/quantized campaign by default, new coupling
  toy or promotion of known MBR/conditional means. Original26B remains untested;
  absence of that test is not a new positive practical/theoretical result.
- [x] T8805: Competent classical finite-grid sum/moment DP, contractd24974e
  before source217b752/one execution.114 spellings/eight invalid/four EOT-PAD
  guards, three Fraction laws, per-sum moments and ALL12 native fixture/device
  comparisons PASS. Max semantic discrepancy6.6614e-16, marginal1.9074e-6.
  Native12 steps24 proposals added; synthetic only. Ordinary float64 ideal
  path weights, exact semantic grid, NOT finite-RNG certificate/new theory.
  Tiny alpha overshoots retained. Evidence59fb467;65/work/grid-result-v5.md.
- [x] T8804: Preserve v1-terminal-proof-reference/source70ad390/evidence8009d75,
  checked against original Git trees. Eight copied consumer-source and two
  oracle-file hashes verified. Focused Ruff/format2 PASS, no maintained-suite
  rerun. Final make check directly exits0:65 attempts255 versions192487 files;
  full receipt docs/evidence/a65-v1-final-make-check.log and exact scope/index
  docs/evidence/a65-v1-final-verification.json. Integrity does not establish
  new native calibration, useful magnitude, sufficient own priority or goal.

- [x] T8806: Preserve independent v2-native/source2f55fc4/evidencee8ddb26,
  v3-grid/source217b752/evidence59fb467, v4-prospective/source=evidencee469e09.
  Each created/checked against original Git trees. Raw draft/V4/V5 evidence
  hashes and all8 selected-input hashes/allowed fields independently verified.
  Focused Ruff/format6 PASS; maintained345 tests NOT rerun. Final make check
  directly exit0:65 attempts258 versions194991 files6,053,748,913 bytes.
  Full receipt docs/evidence/a65-v4-final-make-check.log and scope/index
  docs/evidence/a65-v4-final-verification.json. Including failed draft there
  were142 SYNTHETIC native steps/773 proposals; zero neural forward. Masked
  loop not yet executed, raw gold bytes decoded only to discard. Useful own
  contribution and overall goal remain OPEN; T8803 execution pending.

- [x] T8810: Preserve independent v5-masked-preflight/source1986ecc/evidence
  62b7b79 and v6-real-necessity/source04c8cf9/evidence25a356e. Creation checks
  exact original Git trees; v6 has33 independent full-bit supplements, every
  archive<100MiB. All280 encoded files/137 RNG files verified tracked. Full
  restoration/129-head audit source and original metadata remain separate.
  Focused Ruff/format7 PASS; full maintained345 tests NOT rerun. Final make
  check directly exits0:65 attempts260 versions197105 files7,934,373,232 bytes.
  Receipt docs/evidence/a65-v6-final-make-check.log and exact scope/index
  docs/evidence/a65-v6-final-verification.json. Primary real necessity remains
  NEGATIVE1/8 vs4/8, no quality campaign or sufficient own contribution/goal.

## M87 — Arbitrary-key distinct-four stopping, exactly rejected

- [x] T8700: A64 eight criteria/contractc22fa4d BEFORE sourced6de16f and one
  solve. Different arbitrary-alphabet question, fixed classical matching6 law,
  distinct-four stop. Existing matching/covariance source copied immutably,
  no mutable A42/A63 imports. Conditional25% diffuse consequence was explicitly
  contingent on an achiever, never an established gain or real-use claim.
- [x] T8701: One solve only:278 anonymous prefixes875 variables340 rows,
  HiGHS status2/observed exit2, original INCONCLUSIVE record preserved.
  No feasible primal, secondary U3 optimum or full7776-tail audit. No retries,
  changed law, relaxed distinct condition, model/forward/label/update/timing.
- [x] T8702: Written obstructiond270de7 BEFORE independent checker52bdeff.
  New exporter/checker observed0/0, no second solve. Twenty named tapes/300
  matching checks reconstruct seven original rows; exact Farkas yA>=0,yb=-1
  proves original LP infeasible and zeros prove impossibility for ALL universal
  rules, beyond the anonymous model. Two corruptions rejected. Old numeric
  record not relabeled. Primary distinct-four/25% hypothesis CLOSED;5-query
  lower/6.25% upper are not an achieved smaller goal. Source/evidence9e04c49,
  work/infeasibility-v2.md/result-v2.md. A63 remains intact; goal OPEN.
- [x] T8703: Start the next substantive direction from an independently
  identified real software/research operation and its strongest existing
  alternatives, before another abstract coupling prototype. Need a plausible
  own positive comparative consequence and complete-cost use. No relaxed
  A64 five-query/law/cap search, closed old consumer reopening or promotion
  of another correct small sampler. M88 now starts from the real pinned
  Mosaic/JevBench numerical consumer and its native terminal semantics, before
  code; useful native magnitude/own priority remain OPEN in T8802/T8803.
  A different grounded TCC is authorized.
- [x] T8704: Preserve separate v1-prospective-no-primal and v2-exact-obstruction
  snapshots, both checked against original Git trees. Six origin-file hashes
  and unchanged originald6de16f producer independently checked. Experimental
  Ruff/format4 PASS, no maintained-suite rerun. Full make check directly exits0:
  64 attempts254 versions191749 files, complete receipt in
  docs/evidence/a64-v2-final-make-check.log; scope/index in
  docs/evidence/a64-v2-final-verification.json. Archive integrity is not a
  positive scientific result, useful application, novelty or goal completion.

## M86 — Exact three-class coupling, positive minimax stopped-work theorem

- [x] T8600: A63 criteria/theoryee6f423 BEFORE solver. Unknown-P original
  payloads, three ALLOWED keys, literal first, universal marginals and known
  simultaneous cap-six atom optima. Bernstein/matching/LP are antecedents.
- [x] T8601: Initial source31c3961 BEFORE solve; rational primal/dual both
  386/81, exact gap0. Independent verifier checks729 tapes28 multisets/five
  laws and corruptions. Source/evidence already preserved in A63/v1.
- [x] T8602: Adjacent-cap contractcbe7c40/source5e2da7c BEFORE ALL four new
  solves. Caps4/5 cost31/9;6/7 cost386/81. Four independent exact verifiers
  pass81/243/729/2187 named tapes. Raw evidence4cc8864 in63/work/evidence/v3.
  Original parallel solve tool output was lost in context truncation, recovered
  from CERTIFIED files/no live process without re-solving. Its terminal exit
  codes were inferred, not observed; V4 metadata clarifies the V3 origin fields.
- [x] T8603: Operational contract14562a9/written minimaxe5f7331 precede
  sourced59e7ad AND execution. Deterministic44-row raw callback reference:
  all729 tapes28 multisets/15 independent matchings PASS, full ORDERED law
  matches, all degree-six work/stop coefficients exact. Formula maximized at
  U3 gives sharp MINIMAX386/81 for cap6/7;>=20.576% source-call saving versus
  always-six for EVERY key law. No all-P pointwise optimality. Evidence2b7544c
  and63/work/{minimax-cost-v4,operational-result-v4}.md.
- [x] T8604: Primary/control contractf8b590e BEFORE source922c50a/execution.
  Complete own classical lazy count-CDF adaptation passes5832 replays/729
  tapes28 multisets;1092 prepared states. U3 control2134/405 versus386/81:
  only9.559...% source-call saving, NOT20% over competent controls. All five
  original rational laws/statuses preserved, no released package timed.
  Evidence37ae39e,63/work/classical-result-v5.md. Original Goyal/Sigman draft
  all5 pages and exact Combinatorial/DiceEnterprise scopes read; no priority
  inferred from absent search terms. Missing antithetic originals remain gaps.
- [ ] T8605: Establish a sufficient OWN contribution/priority and useful real
  full-cost operation before article/native campaign. The source-call theorem
  is positive progress, not goal completion, general EPIC/iid superiority or
  total20% speed. Charge coordinator/shared preparation/pair consumption;
  informed/larger/score-aware methods remain legitimate practical controls.
  No A63 head/weight/forward/update/row-label/timing. No core modification;
  old345-test suite not rerun or credited to A63. Exact CLI audits are separate.
- [x] T8606: Preserve three further immutable source/evidence ZIP versions:
  v2-adjacent-caps, v3-operational-minimax, v4-classical-control. Exact source/
  evidence commits in catalog and docs/evidence/a63-v4-final-verification.json.
  Experimental Ruff+format6 PASS. Final make check directly observed exit0:
  upstream/lint/types and63 attempts247 versions186075 files preserved;
  full actual receipt docs/evidence/a63-v4-final-make-check.log. This is archive/
  software integrity, not new scientific validation, neural gain or priority.
- [x] T8607: V6 contract1d98530 BEFORE source1aa4fec/execution. BOTH complete
  random-anchor rank controls pass8748 replays/all28 full ordered laws against
  independent matching and frozen candidate. At U3 both2561/486, above V5 CDF;
  some other laws favor ranks. All five laws/evidence2f2e86b preserved; no model
  or timing. See63/work/rank-result-v6.md. Closed A44/A42 uses stay closed.
- [x] T8608: V7 written control/proof3a196ac BEFORE source076799a/execution.
  Greatest common-part construction is CLASSICAL, pointwise work-optimal only
  among methods preserving q_t on EVERY full tape.9477 exact replays/60 tickets/
  13 cells and three degree-six identities PASS. Cost polynomial plus q²>=3r
  proves gap>=7/18 and saving>=63/835=7.5449% for EVERY law, sharp at U3.
  Strongest U3 control835/162 replaces the9.56% headline, not the always-six
  source bound20.576%. Does not dominate ranks at all P or all other classical
  designs. Evidencec9730b8; result63/work/common-result-v7.md. No neural/timing.
- [x] T8609: V8 writes full-cost/score-regression objections without a new
  application run. Separate0b64ca1 addendum corrects broad setup wording in
  22863e2: shared per-pair work changes thresholds. No actual cost ratio or
  stored scalar readout. Original0907.4018v1 Sections2/3 count-coefficient
  construction read; no generic count compression/interval novelty claimed.
  Real competitive use/priority remain T8605 OPEN; no new neural phase.
- [x] T8610: Archive v5-rank-controls/v6-common-part/v7-full-cost-audit,
  preserving each source/evidence and separate cost correction. Experimental
  Ruff+format8 PASS; final make check directly observed exit0:63 attempts250
  versions188503 files. Actual full receipt docs/evidence/a63-v7-final-make-check.log
  and commit/scope index a63-v7-final-verification.json. No full345-test rerun
  or new scientific/model validation is credited to archive integrity.
- [x] T8611: V9 read-only real-operation lead audit: NRCSE original Sections3.3/
  3.4 identifies real two-phase ecological measurements; EPA intro/contents
  only. No raw data or exact three-key/retained-first consumer established;
  no field/model benefit or campaign. See63/work/application-leads-v9.md.
- [x] T8612: V10 prospective4f13271/source610c0a1 before ALL eight count LPs.
  All4..7 regressions pass BEFORE8..11. Independent rational primal/dual with
  exact gap0;88560 first0 named tails642210 steps/corruptions PASS. Costs at
  U3:4/5=31/9,6/7=386/81,8=4529/729,9=40663/6561,10=620/81,
  11=450262/59049. Same full ordered laws at8/9,10/11 but small strict odd
  mean-work gains0.24%/0.38%. Cap11 chosen policy costs23/3 at a point mass;
  no family minimax assertion. Original four full-history bounds unchanged.
  All direct terminal exits0; evidence6e31dc7, work/count-flow-result-v10.md.
  Count reduction is classical;3B/4 liminf is WRITTEN lower, upper conjecture.
- [x] T8613: V11 prospectivec2d42ed/sourcead7e82f before ALL Schur searches.
  Reuse old unrestricted V10 dual explicitly with new optimal-face primals.
  Four4..7 global certificates pass independent polynomial long division,
  1080 named tails4140 steps/five original laws. Caps8..11 numerical cone
  failures retained as INCONCLUSIVE, no independent audit of nonexistent
  primals or proof of true minimax impossibility. All statuses/raw data in
  evidence25f61f0; work/schur-result-v11.md. No new neural/timing evidence.
- [x] T8614: V12 scoped primary audit: original Aw/Rosenberg2018 Sections2.2/
  2.3 through Schur--Ostrowski Theorem2.3 read, full file hashed; not whole
  article/book. Hashemi2025 direct PDF still404 despite cached search text;
  2026 original has no link on author listings, Hall1989 remains abstract-only.
  Own priority/use not established. See work/primary-and-decision-v12.md.
- [ ] T8615: Resolve a substantive scientific/use consequence before further
  cap expansion, certificate engineering or neural campaign. V10/V11 are
  finite proof progress, not a useful real full-cost win or the user's goal.
- [x] T8616: Archive v8-count-flow-family/source610c0a1/evidence6e31dc7 and
  v9-global-certificates/sourcead7e82f/evidence25f61f0. Both creation checks
  compare original Git trees; all56 origin-file hashes independently checked.
  Experimental Ruff/format12 PASS, no maintained345-suite rerun. Full make
  check directly observed exit0:63 attempts252 versions190296 files; complete
  receipt docs/evidence/a63-v9-final-make-check.log and scope/producer index
  docs/evidence/a63-v9-final-verification.json. Integrity is not scientific
  utility/priority validation or goal completion.

## M85 — Native RLM numerical quantile audit; complete control matches bound

- [x] T8500: A62 criteria/theory/source scope3f0912d BEFORE producer. Different
  AR consumer: public code-metric RLM uses sample-median readout. Written
  frontier endpoints/quantile enclosure/model-risk bound and elementary
  black-box obstruction; not new generic branch-and-bound or dLLM inference.
- [x] T8501: Producer885c614 BEFORE execution validates six original hashes,
  six literal-arithmetic pairs/twelve finite corners. Two exact-decimal alias
  pairs differ by one native-arithmetic ULP; equal/zero controls pass. No vendor
  module executed, model prediction, weight/data row/forward/update/timing.
  Actual checkpointE2/M5/nine tokens/13 decoder IDs; top-p before numeric mask
  confirmed from official4.53.2 source. Maintained4.52.2 lacks t5gemma mapping;
  no environment installed. Ruff+format1 PASS, no new active tests/full-suite
  rerun. Metadata collector's initial system-Python mismatch is recorded.
  Full receipts62/work/evidence/v1, result62/work/result-v3.md.
  Archivev1 preserves source885c614/evidence9df5399. Final make check exit0:
  62 attempts/243 versions/183071 files; complete later integrity receipt
  docs/evidence/a62-v1-final-make-check.log, not scientific validation.
- [x] T8502: Original BEAVER Def2.2/4.1--4.3 and Yiu/Mamoulis/Tao2006 Section3/
  4.3 scopes read. Two shared-cache BEAVER upper bounds for complementary
  events reproduce EXACTLY the candidate's CDF bounds. Weighted endpoint
  inversion is classic; this is a complete written control, not code/timing.
  See62/work/control-and-decision-v2.md. No priority or own benefit established.
- [ ] T8503: A substantial own difference/practical consequence and specific
  novelty remain OPEN. Simple endpoint-solver/neural campaign NOT TRIGGERED
  solely by this derivation. A real consumer and source audit are insufficient
  to fulfill the positive goal; require a benefit surviving complete controls.

## M84 — Whole scientific-value score, correctness only; expansion declined

- [x] T8400: A61 eight criteria8d6b560 and theory9f08d0f BEFORE prototype.
  Category log/conditional-mantissa CRPS is a known scoring specialization;
  written strict propriety, decimal rescaling and source-logit bounds4/2,
  not new general kernel theory or native iterative likelihood. Full original
  IDs/aliases/zeros retained; exact score stores symbolic log ratio+rational
  offset. Polynomial compiler is WRITTEN, not the enumerating prototype.
- [x] T8401: Sourcef07a5d7 committed BEFORE execution. Four rational oracles
  PASS0.049s:44 source/label cases181 exact logit components, rare mass1e-30,
  five population identities; full345 PASS97.976s, Ruff/format3 files PASS.
  Logs/freezes61/work/evidence/v1. No new A61 head/forward/update/row-label or
  competitive timing. Passing tests does not confirm a useful own advantage.
  Archivev1 preserves sourcef07a5d7/evidence40f6017. Final make check exit0:
  61 attempts/242 versions/182362 files; complete later integrity receipt
  docs/evidence/a61-v1-final-make-check.log, not scientific validation.
- [x] T8402: V2 written boundary counterexample: near-correct forecast losslog4
  versus distant forecast<1, despite numerical error tending0. Propriety stays
  true. Complete semantic NLL/canonicalization/codec scores are strong controls;
  FINAL ICML GenRe2 has OPD absent from earlierV1. TabDLM/ICF-DLM scopes read.
  Pinned RegressLM source and public model/data cards audited read-only; no
  Parquet/weight/row downloaded. Aggregate label stats HAVE been read. Native
  IEEE raw exponent is not always semantic order; autoregressive law not a
  product-head law. Full decisions61/work/decision-v2.md and result-v3.md.
- [ ] T8403: Own substantial usefulness/specific priority remain OPEN. Simple
  score's neural expansion and article promotion NOT TRIGGERED by this rationale;
  no claim of empirical training failure. Need a surviving comparative benefit
  before a new implementation/campaign. Original positive user goal stays OPEN.

## M83 — Exact semantic numerical CDF/quantiles, minimal candidate only

- [x] T8300: Write A60 eight criteria/theorye107296 BEFORE code. Fixed positive
  band, original-token source, unambiguous bounded numerical relation and
  exact value-key/prefix statistics. Generic WFST and unranking are classical;
  restricted delayed-output bound does not exclude register/multipass controls.
  Addendum220c1e1 corrects numerator assumptions for the bit bound BEFORE code.
- [x] T8301: Minimal229-line[1,100) reference ONLY. Initial draftf8f9f57 passed
  four oracles0.707s but was committed AFTER execution: failed Ruff E501
  prevented intended freeze; logs/deviation retained. Final source4cf274f
  committed BEFORE final4-oracle PASS0.701s:48,880 numerals/28 regressions,
  260 tapes/five sources/34 original-ID coefficients/310 CDFs/71 quantiles.
  Later full337 PASS95.193s; Ruff3 files PASS. No A60 model/head/forward/update/
  semantic label or competitive timing. Full facts60/work/result-v4.md.
  Archivev1 preserves source4cf274f/evidence4134b20. Final make check exit0
  verifies60 attempts/239 versions/180174 files; complete later integrity
  receipt docs/evidence/a60-v1-final-make-check.log, not scientific validation.
- [x] T8302-audit: Written complete generic-WFST construction reproduces
  projected source/prefix masses and caching. No generic own inference-speed
  advantage follows. This is NOT an independently implemented/timed control.
  LLM Processes Section2/A.1/A.2/H.1, NTL Section2 and SMMD3.0--3.3 read;
  direct numerical readout/supervision are established antecedents.
- [ ] T8302-distinction: Specific bounded-normalizer priority and substantial
  own useful consequence remain OPEN. Need a real consumer of THIS head-local
  numerical law and fair complete cached/register/WFST controls. No claim of
  calibrated uncertainty, improved model accuracy or whole-decoder statistics.
- [ ] T8303: Full-V/EOT/PAD/native/model/training/cost campaign NOT TRIGGERED.
  More correctness checks alone do not justify it. Do not promote A60 as the
  article result or reopen A59's simple-core application from this prototype.
- [x] T8304: V5 f4c373d BEFORE code extends the written operation to ALL
  nonnegative scientific magnitudes/compact values, with polynomial source-cut
  construction and exponential bound for any universal ONE-WAY NFT of that
  relation (not all numerical algorithms). Classical rotation acknowledged.
  Eight criteria written first inwork; README link only after oracles, an
  explicitly retained location/indexing deviation. No priority/useful-win claim.
- [x] T8305: Initial321582c interrupted SIGINT130 during first compact-quantile
  test; full traceback/source preserved7a8992d, no four-test outcome claimed.
  V6 trimming note BEFOREee02f43; SAME four oracles PASS2.224s,35+76 main tapes,
  six original-ID coefficients,63 main quantiles/122 CDFs, plus84 tiny block
  tapes/nine quantile-CDF pairs. Extreme orders+/-10^20 and signed zeros pass
  without expanding enormous reals. Full341 PASS98.678s/Ruff+format4 files PASS.
  Prospectived7ade98 collector passes all1/2/4/8/16 block sizes;2^32-value
  constructed source37 states/raw index49017/trimmed60. No performance/model gate.
  Separate archivesv2-rotated-interrupted andv3-unrestricted-order preserve
  source321582c/evidence7a8992d and sourced7ade98/evidence1e6139c respectively.
  Final make check exit0:60 attempts/241 versions/181651 files; complete later
  integrity receipt docs/evidence/a60-v3-final-make-check.log, not validation
  of mathematical priority/usefulness or completion of the scientific goal.
- [x] T8306: Written COMPLETE localization controlae454bd gives strict-CDF
  comparison O((S+E)L^2), O(L)order search then selected-order compilation;
  quantile O((S+E)L^3), no global cut factor B. Not implemented/timed or a
  published-priority finding. This removes the generic all-method capacity
  justification while leaving V5's restricted NFT theorem intact. T8302's
  own useful difference remains OPEN; no native/full-V/cost expansion triggered.

## M82 — Complete scientific-notation interval infilling, bounded compiler

- [x] T8200: Write A59 eight criteria/theory1aac564 BEFORE prototype. Exact
  decimal semantics, not binary64 rounding. Written non-CFL [1,2) language,
  positive O_I(L)-state/edge unambiguous bounded-complete construction and
  Omega(L) NFA lower bound; classical tools acknowledged. Pinned primary
  llguidance/XGrammar range functions restrict numeral forms. Priority and
  substantive own distinction are OPEN; no performance claim against them.
- [x] T8201: Minimal [1,2) compiler ONLY. Initial3a94c76 fails on10e1
  (value100 accepted); full3-pass/1-fail log preserved97f01f8 BEFORE repair.
  Corrected439f4b1 passes4 oracles0.737s:48,880 exact numerals/10 malformed,
  900 fooling pairs,3 rational-token scenarios/15 original-ID marginal checks,
  aliases/fixed holes/zero mass and literal sign regressions. No model read,
  new head/forward/update or competitive timing. Later full330 tests
  PASS94.438s and focused Ruff/format5 files PASS. See59/work/result-v2.md.
  Independent initial-sign-bug/v1 archives preserve3a94c76/439f4b1 and their
  distinct failed/passed evidence. Final make check exit0 verifies59 attempts/
  237 versions/178730 files. Complete later integrity log:
  docs/evidence/a59-v1-final-make-check.log; not a new scientific measurement.
- [x] T8202-control: V3 note5cbadc5 BEFORE independent register/digit-DP
  control1599588. Three oracles PASS0.575s:48,880 exact numbers,1147 reached
  finite-product configurations/293632 ALL-byte transitions at L8/16/32/64,
  five rational-token cases/13 original-ID coefficients. Complete language
  matches at these L; control also has O(L) states/edges. No own asymptotic/
  capacity separation from this complete classic construction is established.
- [x] T8203-fit: Pinned bulk conformance audit e940c71 reads ALL11306 files/
  143978678 bytes,37011 instances;5165 bounded schema nodes/16081 direct
  aligned numeric fields. No errors. Four supplied-valid scientific fields
  repeat two parameters in one schema with only minimum0; regular constraint.
  Two valid long-fraction fields in[0,1] occur in other schemas. No invented
  prefix, native capture/timing or model campaign; generated conformance data
  are NOT production infilling logs. All hashes/observations preserved. See
  59/work/decision-v4.md. Later333 tests PASS94.695s/Ruff11 files PASS.
  Archivev2-control-fit preserves sourcee940c71/evidence0e32a78; final make
  check exit0 verifies59 attempts/238 versions/179461 files. Complete later
  integrity log docs/evidence/a59-v2-final-make-check.log; not a scientific win.
- [ ] T8202-distinction: Specific numeral-theorem priority and a substantial
  own useful difference remain OPEN. Generic suffix/register mechanism is
  classical; restricted frontend support alone does not meet the goal.
  V4 declines main-paper promotion and extensive simple-core generalization.
- [ ] T8204: General intervals/EOT/PAD/native integration/model campaign are
  NOT TRIGGERED. Before expansion, establish a concrete additional own useful
  operation/difference and real consumer against complete controls; do not
  manufacture scientific prefixes or replace that evidence with more tests.

## M81 — Streamed grammar-loss training head, resource gate CLOSED negative

- [x] T8100: Write A58 eight criteria/theoryc271080 BEFORE prototype; primary
  controlsdfcb112 explicitly give CCE its direct LSE adjoint/filter_eps=None.
  Six CPU oracles PASS0.873s:252 exact dual derivatives,252 combined loss/
  mass/full-gradient coefficients, four panel widths, variable EOS, fixed
  future IDs/aliases/zeros, occupancy/filtering counterexamples. Full321
  PASS88.353s. CPU zero-class NaN at6ef8f37 is preserved and fixed separately.
- [x] T8101: Freeze GPU protocolde762b0 BEFORE kernels; initial8fea71f has24
  candidate/dense/checkpoint PASS and8 CCE import ERROR, overall ERROR.
  Separate before-replay addendumd883e12 pins packaging25.0; producerfc224fa
  replays ALL32/32 PASS,380752 comparisons/4 refusals. All8 input NPZs are
  literally identical; RNG/precision/threads restored. Current pinned CCE
  3de376c/filtering OFF included. Full H/W/bias gradients, SYNTHETIC FP32
  matrices ONLY: zero model reads/forwards/updates/labels or competitive
  timing/memory evidence. See58/work/result-v4.md; no main-paper promotion.
  Archivev1 preserves exact replay sourcefc224fa/evidencee2ef6e7; completed
  make check exit0 verifies58 attempts/234 versions/176429 files. Final log:
  docs/evidence/a58-v1-final-make-check.log. It is a later preservation check,
  not attributed to the original replay. API2's original-note endpoint also
  returns HTTP403; full MonoidReduce retrieval remains unfulfilled.
- [x] T8102-controls: Prospective notes70157a7/76275ee/2618e03/321a56d precede
  sorted/tied/optimizer controls, four tiles, bucketed merge and native CCE
  output-buffer adaptation. Strong replayd5131bd128/128 PASS1,523,008 checks;
  tiles/buckets each32/32 PASS380752. All old sources/packets retained.
  Initial V9 incorrect CLI input path fails before fixture evaluation and is
  preserved. Guarded measured sourcebb6ced4 pins native heuristic mode.
- [x] T8103: Frozen synthetic full-HEAD resource screenf177be0+V8/V9 addenda,
  producerbb6ced4209a2f27ad2518308cdb4955417ed4fca, completes680/680 records:
  96 correctness PASS,288 preparation,288 warm,8 common validations; no errors.
  ALL8 candidates0/8 gates against ALL4 completed first-stage controls.
  Predeclared negative-only shortcut rejects the full gate; other10 controls
  NOT measured, no native/model/independent campaign triggered. Full50258 IDs/
  194 classes,D768,N16--2048; H/W/b synthetic. Zero model read/forward/update.
  AFTER-data audit supplies both rejection witnesses for ALL64 pairs. Later
  full326 tests PASS93.764s and focused Ruff32 files PASS, after timings. See
  58/work/result-v10.md and evidence/resource-v7-initial. Simple family CLOSED.
  Archivev2 preserves sourcebb6ced4/evidencec241fde; final make check exit0
  verifies58 attempts/235 versions/177329 files. Complete later integrity log:
  docs/evidence/a58-v2-final-make-check.log, not attributed to timed source.
- [ ] T8102-priority: Complete MonoidReduce original/source is NOT retrieved;
  indexed excerpts already subsume generic arbitrary-adjoint streaming. No
  sufficient own systems distinction/real full-training benefit is established.
  The bounded synthetic screen above only rejected a necessary condition;
  it is not a model campaign, priority check or achieved positive goal.
- [ ] T8104: Establish a substantive new useful operation/difference before
  another extensive implementation. Do not expand the failed simple A58 family
  by relaxing its frozen gate, selecting favorable N or renaming its timings.

## M80 — Conditional policy-ratio moments, classical diagnostic retained

- [x] T8000: Write A57 eight criteria/theoryf5833c2 BEFORE independent reference.
  Four rational oracles PASS: ALL173 actions/1038 second moments for six
  controls, variable EOS/future fixed IDs/aliases/zeros, ALL87 visible/459
  augmented adaptive paths, unchanged policies and hard-preimage failure.
  Full315 PASS88.281s; focused Ruff passes. No head readout, forward, decoder/
  auxiliary draw, label, fitting or update. A52 V18's failed gradient gate
  stays CLOSED; this is a different finite-update operation, not its revival.
- [x] T8001: Read ORIGINAL final Atlas2021 main-text Theorems3.5/4.1/proof
  and matched-support explanation, alongside MIPS§3.1/B.4 and DiFFPO§§2--3.2.
  Powers/products/integration already give the generic moment mechanism.
  Keep as diagnostic/control; no substantive own separation or new head
  campaign triggered. See57/work/primary-decision-v2.md. Goal remains OPEN.
  Archivev1 preserves source/evidence97f5bab; completed make check exit0
  verifies57 attempts/233 versions/175674 files. Final post-archive log is
  docs/evidence/a57-v1-final-make-check.log, not attributed to earlier snapshot.
  Reading-only PepTune§§2.2/2.5/4.4/4.5 adds actual peptide-filter/MCTS/Pareto
  contract; no inferred cost ratio or molecular campaign. Exact scope:
  docs/research/consumer-reading-2026-10-16.md.
- [ ] T8002: Establish an own useful operation/difference and real consumer
  before expanding this diagnostic or starting another extensive prototype.
  Conditional hidden variance alone is not visible overlap/ESS/quality gain.

## M79 — Static-rounding GPU numerical preflight, no new theory claim

- [x] T7900: Write A56 eight criteria/theorem7fb3daf BEFORE arithmetic code,
  GPU protocolb1f88d6 BEFORE kernels. Four independent rational oracles PASS:
  1793 grid roundings,3024 enclosures,1024 prefix cells and wrong DAG-height
  counterexample. Full311 PASS88.119s. GPU opt-in passes185 exact masses,
  336 literal replays,4096 prefixes/16 events and14 PTX modules, no FTZ.
  Keep exact-zero/subnormal guards, original IDs and unchanged prefix fallback.
  First wrong-environment import failure and exact source are preserved.
  ZERO new neural/model heads/forwards, external inputs or competitive timings.
  Separate guard supplement fulfills all eight explicit invalid-support/input/
  zero-mass cases; no zero-mass word returned. Initial counts unchanged,
  17 UNIQUE new-frontend PTX modules across both packets. V1 archive stays
  literal; boundary supplement is a separate later version.
  Final make check exit0 verifies56 attempts/232 versions/174981 files;
  complete log docs/evidence/a56-v2-final-make-check.log. No partial log credited.
- [x] T7901: Read full ORIGINAL ADZ1997 report16 pages after successful HAL
  retrieval, SHA9eb5910791f1; Lemma3.1 visually checked, §§3--5 supply direct
  static-error/retained-refinement antecedent. Reject a NEW generic mechanism
  claim. Keep guarded GPU source as control/correctness artifact. No sufficient
  own systems advantage, publication promotion or achieved goal. See56/work/
  primary-decision-v2.md; Higham/PepTune/SparseMAP reading scopes explicit.
- [ ] T7902: Before expanding a numerical systems direction, establish a
  substantive own architecture/operation beyond the classical ADZ template
  and a plausible real complete-cost benefit. Any measurement needs a separate
  frozen protocol with equally optimized ADZ/directed/approximate controls.
  Correct toy kernels alone do not trigger a broad neural campaign.

## M78 — Transient-cycle assignment proposals, written before prototype

- [x] T7803: A45 V3 writtene970ffe/1a39f02 BEFORE checks resolves arbitrary
  finite-class covariance safety for B6/7 by an exact square certificate.
  Endpoint addendum9a1aae9 proves0<=t<=1/15; upper remainder and even B>=8
  remain OPEN. Five exact oracles PASS1.452s:35 conditional rows/12412 RNG
  leaves,192 population entries/115 matrix directions/334 verifiers,
  508 endpoint checks and4096 raw alias/failure tapes. Optional SymPy1.14
  verifies ten identities. No new head/timing/use/priority or goal claim;
  original negative A44 consumer stays closed. Full307 tests PASS88.256s;
  completed exit0 logs in work/evidence/six-safety-v3. Focused Ruff passes.

- [x] T7804: Written01f84be BEFORE the rare-class obstruction oracle proves
  constrained/unconstrained equivalence for arbitrary finite class counts and
  necessary t<=1/12. Exact fixture1026 classes/75 occupancy profiles at4/45
  has positive covariance and Boolean-verifier pass@2 BELOW iid2. Ninety exact
  binary identity checks pass; no Monte Carlo, new head/timing or model claim.
  V3's positive interval remains valid;(1/15,1/12] remains OPEN. Independent
  raw outputs in45/work/evidence/dust-obstruction-v4; useful own contribution
  and user goal still OPEN. This does not reopen the closed A44 consumer.
  V3/V4 archived independently; final make check exit0 verifies55 attempts/
  230 versions/173467 preserved files. Complete check log:
  docs/evidence/a45-v4-final-make-check.log. No partial-running log credited.

- [x] T7802: Separate A45 mathematical audit, f50008a written before its
  oracle: whole-matrix odd/even degree-elevation identity for all label counts;
  B2/3 iid and B4/5 existing A38 control, conditional-SRS shortcut false.
  Finite2872 profiles/77616 entries and125 control profiles PASS. General
  safety remains OPEN for even B>=6, L>=4; no new population/neural campaign,
  priority or useful application. Original A44 negative consumer stays closed.
  See45/work/proof-audit-v2.md; primary PPS2026/Neal scopes explicit.

- [x] T7800: Write A55's eight criteria/target/algorithm/cost/counterexamples
  BEFORE code or new matrix samples. Loop-soup/permanental/Poisson-exclusion,
  Ewens and Boltzmann are classical; own operational distinction remains OPEN.
  See55/work/theory-v1.md and primary-reading-v1.md. New law explicitly differs
  from native DiffuRank greedy decoding. No new head/timing/benefit or achieved
  goal. Mandatory strong controls include cycle perfect simulation and current
  nesting rejection, not only independent rows.
- [x] T7801: Audit the derivation against primary sources and independent
  finite rational oracles. Passing correctness alone does not trigger a neural
  campaign. A real consumer needing this law and meaningful comparative benefit
  must be justified before extensive implementation or promotion.
  Eight rational oracles PASS0.248s; full301 PASS85.439s BEFORE the eighth
  classical-control oracle. Lawler2017 ordered loops match law/certificate/
  favorable complexity without NB/Ewens. Negative originality audit in
  ordered-control-v2.md; no real-matrix/head/timing campaign, no simple-candidate
  expansion. Raw/code/logs preserved, goal OPEN. External nesting source
  cloned read-only97e704255b3d; NO instance weights/statistics evaluated.
  Final full302 PASS85.791s includes the eighth oracle; focused8/Ruff pass.

## M77 — Coupled policy comparison/replay, limited classical investigation

- [x] T7700: Write eight criteria/coupling scope before code f61bbcc/07c255e.
  Six rational oracles pass including128 co-adapted binary transport vertices,
  unrestricted-MEXIT and semantic-variance counterexamples. Proper T and A
  density controls pass independent enumeration. Full294 PASS87.118s; final
  synthetic full-V/FAKE70 IO and focused Ruff pass. No actual native coupler,
  new head or useful sufficient novelty confirmed.
- [x] T7701: Freeze V3 source/runtime/ALL70 old inputs before real readouts/
  local L1 cache-loss coefficients. Include proper length/anchor mixtures,
  class/word/full controls; local20% is NOT total latency and cannot trigger
  new neural work. Producer fe5dd29 completes70/70 readouts. None of25
  directions passes; best local ratio.98416 vs proper T. AFTER-data4125 scalar
  audit passes2.665e-15; no large neural expansion. See work/result-v3.md.
  Goal remains OPEN.

## M76 — Observable terminal stopping, before real-path screen

- [x] T7600: Write A53 eight criteria/theorem before code53d9e72. Seven
  finite-language/coupling/compiler/prefix oracles PASS; synthetic full-V and
  FAKE16-path86-state pipeline pass. Preserve mistaken synthetic expectation.
  Strong prefix control now includes whitespace-sealed number; generic flat
  DAG yields SAME classical certificate. No useful own novelty/neural claim.
- [x] T7601: Freeze sources/runtime/ALL16 OLD paths before any A53 actual
  state certificate/count; compare unique heads including sharing/warmup.
  20% beyond strongest cheap/raw controls and two questions is necessity only;
  no new neural/head/labels/auxiliaries/updates. Producer d807143 completes
  86 states;50 candidate vs52 strong-prefix vs63 original unique heads+warmup,
  only one extra question: NEGATIVE, no new neural campaign. Count audit passes.
  See work/result-v2.md; sufficient novelty/usefulness goal remains OPEN.

## M75 — Observed confidence-selected action likelihood, before prototype

- [x] T7500: Read native Mosaic LLaDA2 threshold/fallback and primary DUEL,
  MAPG, d2, EGSPO, CoDD and Di4C within explicitly recorded scopes. Reject
  generic mixtures/PC priors/distillation as new central mechanisms. Write
  A52's eight criteria, unary-preimage proof, local regularity condition,
  covariance identity and connected checksum comparison BEFORE code.
  No new head/update/timing or sufficiently original contribution is claimed.
- [x] T7501: Minimal independent rational oracles: complete observed action
  law against enumeration, threshold equality/fallback/ties, original aliases,
  fixed IDs/EOT/PAD, conditional token-count score, impossible/zero mass and
  connected-family covariance INCLUDING best scalar-baseline full control.
  Passing is correctness, not priority or practical usefulness.
  Six oracles PASS0.980s;108 complete laws1372 actions15092 coordinate scores,
  2x2 covariance identities, four connected sizes, and a retained-only gradient
  counterexample(-21/100 versus0; naive masses sum17/10). Full211 tests
  PASS72.391s; make check/focused Ruff PASS. No new head/update/timing.
- [ ] T7502: Reassess originality and an actual training/audit consumer versus
  classical compiled evidence inference, enumeration and optimized full-score
  baselines. Only after a plausible real benefit, freeze external-state
  complete-cost protocol BEFORE neural heads/updates/timings. No large training
  implementation is authorized by this checklist alone without that foundation.
  V2 writes a SEPARATE smooth joint word/token-dependent Bernoulli policy,
  conditioned nonempty by a positive two-state OR compiler. Word marginals
  change explicitly; bit-only retries are wrong for that target. dUltra and
  Learning Unmasking Policies already use Bernoulli planners. All eight criteria
  are reassessed BEFORE code; only an independent small joint/action-law oracle
  is next. No new head/update/timing, useful effect or sufficient originality.
  After651b8dd, five V2 oracles PASS:8 joint laws256 actions4096 score
  coordinates,31 FAKE-head states52 observed paths88 auxiliary paths; original
  confidence chain rule and wrong bit-only-retry counterexample. Combined11
  oracles PASS1.224s; full216 PASS73.155s and make check/Ruff PASS. MD4§6
  already gives token-value-dependent schedules; no novelty credit for that.
  Runtime/model metadata only read, no weights or new neural forward/update.
  V3 writes an auxiliary anchor chosen independently of X: it forces progress
  while preserving CURRENT proposal P. Integrating it yields a retained-only
  scalar times one unary-filtered grammar partition; score/chain/count proofs
  and all eight criteria precede V3 code. Standard forcing/mixture/WMC/RB are
  credited. Only a minimal independent oracle is next; fixed-anchor and
  position-only analytic controls must remain equally competent/cheap.
  After da3bd39, four V3 oracles PASS:8 triple laws256 actions4864 score
  coordinates and5 FAKE-head states12 observed paths24 full paths, including
  confidence chain rule and both collapses/analytic controls. Combined15
  PASS1.374s; full220 PASS73.333s; make check/Ruff PASS. No real head/update/
  timing. Tiny-A2D head has151936 logits but token IDs only0..151669; a future
  consumer must declare the remaining IDs' semantics before data capture.
- [x] T7503: Implement ONLY the bounded V4 consumer/resource preflight after its
  written eight criteria and independent question-only copy:8 KNOWN development
  inputs, pinned Tiny-A2D,32 slots, max9 real forwards, four samples/head, no
  labels/updates or timing claim. Check ALL151936 IDs including266 tokenizer-empty
  outputs, true numeric JSON EOT PAD*, original identity/class reductions,
  gate/confidence chain and CPU/GPU small rational references. Freeze runner and
  exact runtime/source BEFORE heads. Preserve all failures, original BF16 logit
  bits, configurations and statuses. Six correct cases permits only considering
  a separate cost/variance protocol; it cannot establish useful gain/novelty.
  Initial prerequisites:18 focused tests PASS1.532s;22608 small original words
  versus independent JSON parser/class sums; official tokenizer151936 singles+
  4096 triples zero errors; all266 empty IDs retained. Whole-V38 classes/22
  states/92 state-class arcs preserve all IDs. Initial48 NumPy/Torch CPU/CUDA
  records match rational action/score oracles, max log error1.78e-15. New isolated
  Transformers4.57.1/tokenizers0.22.1 shares unchanged Torch2.8 runtime; custom
  module import passes without a model instance. Runner/head capture pending.
  Final runner/protocol prepared BEFORE pretrained heads:19 focused oracles,
  full224 PASS74.209s, make check/Ruff PASS. Three synthetic full-V32-slot
  actions fit421728768 bytes, refined48 toy score records pass, five RANDOM
  architecture forwards verify cropping/bidirectionality/padding plus explicit
  local BF16 loading. Final/original sources and raw checks are separate in
  work/evidence/consumer-preflight-v4-before-heads. ZERO pretrained calls yet;
  the bounded first capture is next, not a variance/quality/publication claim.
  Frozen854a733 then completes8/8 real resource cases,9/9 pretrained calls
  including warmup,32 valid original-ID JSON proposals/actions, zero refusal/
  error. Maximum CPU/GPU log discrepancy3.553e-14; sampler peak<=422932672B.
  ALL BF16 heads/IDs/seeds/statuses/checks/scores are preserved in
  docs/artifacts/raw/a52_consumer_resource_v4_initial. No labels/update/variance
  or competitive timing. Passing only permits a separate scientific/cost
  reassessment before any next campaign; the user's goal remains open.
- [x] T7504: V5 WRITTEN two-stage real-return screen/eight criteria and
  cheap reverse-anchor control BEFORE code/heads. Integrating A needs no
  filtered query and already matches candidate anchor score. Compact class
  derivatives are classical. First minimal independent reverse/compact oracles;
  only after runner/source/runtime freeze, at most641 pretrained calls on ALL8
  known states,16pilot+64eval each, golds after capture. Strong fitted/zero/RLOO
  controls/negative decision are fixed. No training/timing/novelty triggered.
  After4b2fb1f, compact/reverse, clamped-ID/numeric and RLOO group oracles
  pass; full229 PASS74.834s, make check/Ruff PASS. Two RANDOM BF16 head calls
  verify indexed cropping literally. V5 actual runner/analyzer/runtime/protocol
  freeze before its first pretrained head; V4's nine stay separately counted.
  Frozen e01739d completes640/640 trajectories/629 new forwards (one warmup),
  zero error/refusal; ALL fixed IDs/JSONs correct. Golds after capture yield
  ZERO correct rewards, independently confirmed by Decimal; variation0/8,
  no variance ratios/gains credited. Complete-cost/training/independent
  branches NOT triggered. All raw heads/scores/labels/checks preserved in
  docs/artifacts/raw/a52_two_stage_v5_{initial,analysis_initial}. This
  application is closed negative; general theory not refuted. Inspecting
  padding/stopping semantics is a separate written-first diagnostic, never
  relabeling this gate. Scientific novelty/use/goal remain OPEN.
- [x] T7505: V6 stopping-law diagnostic WRITTEN before code: separate old
  JSON EOT PAD* full-word target and stopped-prefix law integrating ALL suffix
  IDs. Classical length mixture/TV identity/stochastic ordering, not novelty.
  Minimal rational JSON/original-ID oracles, then freeze an ALL8 OLD-head
  mass/length audit, ZERO new forwards/labels/updates. A future iterative
  consumer needs explicit active bits (MASK may be a latent suffix ID) and
  its own written protocol. Do not reinterpret/reopen V5's negative gate.
  After6335f52, two rational oracles pass full prefix laws/TV/length ordering,
  original suffix MASK/EOT/fixed IDs/zero PAD mass; full231 PASS74.457s,
  make check/Ruff PASS. Freeze consumer-protocol-v6.json/runner before ALL8
  archived-head computations; no new forward/sample/label/update.
  Producerd38b843 completes ALL8/8 old heads. Length-TV0.869119--0.999971;
  E_padT-E_stopT6.475331--18.191402 original slots,8/8 interest gates. Three
  partition/archive checks max1.422e-13 log error. ALL mass vectors/effects/
  statuses/source preserved in docs/artifacts/raw/a52_stopping_audit_v6_initial.
  ZERO new forwards/samples/labels/updates. This is contract diagnosis, not
  semantic cause/gain or scientific novelty. New stopped consumer must be
  written separately; V5 remains closed negative and the goal OPEN.
- [x] T7506: V7 prefix-aware anchor WRITTEN before code: eligible active
  positions depend on proposed first EOT, all fixed IDs remain in output,
  terminal potential accounts for anchor normalizer. Classical action/score/
  progress identities; mandatory cheap anchor/length/class/combined controls.
  Only minimal independent rational oracle next, no head/label/update/timing.
  Own meaningful distinction/use and real-consumer protocol remain open.
  After1ecf413/e686287, five independent rational oracles PASS5.089s:
  five joint laws2701 triples484 actions31790 coordinates, exact dual head/
  gate/anchor chain, fixed-stop V3 equality, strict proof-object alpha/anchor
  trace beyond combined cheap controls and35 FAKE-head states/path means.
  Full236 PASS84.581s, make check/Ruff PASS. No new head/update/production
  sampler/practical advantage/novelty. Written stopped resource design next.
- [x] T7507: V8 written root-budget/stopped-resource contract/eight criteria
  BEFORE implementation/heads. ALL8 known old roots, two trajectories each,
  fixed root-only count feature, explicit active bits, proper prefix stopping,
  at most497 new forwards including warmup. First rational expectation and
  compact/manual/autodiff checks, then freeze actual runner/runtime before
  heads. Known-data resource/signal conditions do NOT trigger training/quality
  or novelty claims; V5 remains closed and the scientific goal OPEN.
  Five new CPU oracles,111 rational NumPy/Torch CPU/CUDA records and three
  synthetic full-V actions PASS, including every stronger partial control,
  root expectation, variable occupancy and explicit original fixed IDs.
  Full241 PASS79.352s/make check/Ruff PASS. Initial/final producer bytes are
  separately preserved; actual runner/protocol/runtime freeze before heads.
  ZERO new V8 pretrained calls/updates so far; real resource capture next.
  During the wait for an unrelated GPU study, additional ORIGINAL PAPL
  Sections3.1--3.4/A.4.1 explicitly establish discarded-proposal and subset
  transition marginalization as prior; do NOT claim that principle. Adaptive
  Order Policies2.2--2.3/AppendixC adds supervised frozen-policy adaptation as
  an obligatory future control. Exact scopes/hashes in primary-addendum-v8.md;
  no change to the frozen resource protocol or claim of adequate originality.
  path-control-clarification-v8.md verifies the classical conditional-vector
  property needed for full collapse versus the combined control with a COMMON
  baseline, including finite visible paths. It does not order arbitrary fitted
  baselines or hidden-cost rewards, prove a runtime gain or implement training.
  Capture b6c7bb8 closes16/16 valid trajectories/113 transitions,98 NEW
  forwards including warmup, zero score/ID error. Candidate0/16 and paired
  one-shot0/16 correct; signal0/8 fails required2/8, independently confirmed by
  tokenizer/json/Decimal. Close THIS initialization; no training/new seeds/
  cost-variance/independent branch. NVML finds six foreign GPU polls during
  CPU preparation, none during new forwards: whole-capture isolation violated.
  Preserve the original runner resource8/8 report without crediting a full
  protocol pass or competitive latency. All outputs/heads/costs/draft assertion
  and audited decision in a52_stopped_resource_v8_{initial,analysis_initial}.
  See stopped-result-v8.md. Scientific usefulness/originality/goal remain OPEN.
- [x] T7508: V9 WRITTEN supervised visible-transition bound/eight criteria
  BEFORE its prototype. PAPL/Jensen/random-time teacher forcing are prior.
  Only a minimal independent rational path/bound/gradient oracle is next;
  no new pretrained forward or parameter update. Explicitly retain variational
  gap, fixed-reference requirement, absorbing zeros, target serialization and
  supervised/grammar-CE/native/SFT controls. Not a rescue of V5/V8 Tiny-A2D.
  Five rational oracles PASS0.668s:7 count laws247 actions,30 full target
  laws330 reference paths,30 strict variational gaps/gradient-time identities,
  32 occupancy states. Twelve fixed-EOS position-only counterexamples have
  bound gradient0 but true target gradient nonzero (e.g.9/112). This limits
  useful-order claims; token-dependent general case not refuted. Full246
  PASS81.280s/make check/Ruff PASS. ZERO new pretrained forward/update.
  V9 is only a supervised CONTROL, not a training campaign or protagonist;
  real reward-gradient consumer still needs a separate written foundation.
- [x] T7509: V10 LLaDA stopped numeric-continuation RESOURCE/SIGNAL design
  WRITTEN before code/heads, all eight criteria. Pinned original V126464,
 115 tokenizer-undefined IDs pending official audit, EOS=PAD126081, MASK126336,
 64 response slots and externally supplied literal JSON prefix. Full native
  projection including prompt rows is charged; actual NF4/BF16 law declared.
  Eight KNOWN questions/two trajectories, max1017 new forwards, no updates;
  resource/signal only. Small suffix/alias/manual/autodiff and full-V checks
  plus actual runtime/source freeze precede any new neural head. Native20/32
  is a different decoder/protocol, not evidence for this candidate or novelty.
  Flushed occupancy monitor/call guards must preserve any foreign GPU work.
  Preflight:126464 official singles/4096 triples,115 empty IDs, all six
  original weight hashes PASS. Five CPU suffix/alias/occupancy-monitor oracles,
  60 rational NumPy/CPU/CUDA comparisons and three full-V64-slot checks PASS;
  GPU peak546382336B, max log discrepancy1.706e-13. Full251 PASS80.108s,
  make check/Ruff PASS. Frozen prompt lengths89--127, prefix IDs[12657,31113,2275].
  Actual runner/runtime/protocol/evidence freeze before model instance/heads;
  zero V10 pretrained calls/updates and no useful-effect claim yet.
  Producer e6ef83b completes16/16 valid trajectories/70 transitions and63
  NEW forwards (warmup1/roots8/following54), zero score/ID error. Resource8/8
  and known signal4/8 pass;6/16 candidate and2/16 one-shot correct. This is
  NOT semantic superiority/variance/latency/independent confirmation. All536
  flushed occupancy observations exclude foreign PIDs; post-capture official
  tokenizer/Decimal verifies32 answers and all63 original BF16 heads. See
  llada-result-v10.md and a52_llada_stopped_resource_v10_{initial,analysis_initial}.
  All data/costs/statuses preserved; zero updates. Only consider a NEW frozen
  strong-control full-cost variance protocol, not automatic training.
- [x] T7510: V11 proposal-dependent control/eight criteria WRITTEN before
  code. Frozen denoiser/proposal independent of policy is essential. Full
  b(X)*score has zero mean; after collapse use grad J_proxy(a)/K(a), not
  posterior-proxy probability times score alone. Weighted grammar queries
  and control variates are classical. All partial methods get the same exact
  projected proxy; include strong state/horizon/greedy/proposal/RLOO controls
  with independent fitting/costs. First only small rational joint/action/path
  oracle, bias counterexamples/aliases/zero events; no new head/update or
  competitive benefit claim. New full-cost protocol remains to be defined.
  After17a689a five oracles pass4 laws821 triples193 actions/122 zero proxy
  actions,39 FAKE-head states168 paths. Both naive collapses are biased
  (359/18080 and1/50); exact projection/zero means/PSD covariance/true adaptive
  derivative pass. Initial unreachable-state DFA error preserved separately.
  Full256 PASS83.064s/make check/Ruff; zero new head/update. See
  proposal-control-result-v11.md. Only separately frozen functionality replay
  of ALL70 old transitions is next; no useful effect/novelty established.

- [x] T7511: V12 written ALL70-old-transition proxy functionality contract
  and regular-subset proof BEFORE prototype. Zero new head/trajectory/update/
  labels; original IDs, fixed EOS, zero-support versus underflow retained.
  Only small independent regex/Decimal/rational/Torch checks first, then
  freeze exact replay source/runtime/input hashes. No useful variance/cost or
  training/priority follows from passing; all strong controls remain required.
  Preflight after724118b passes1260 byte regex/Decimal cases,137 rational/
  floating original-ID queries with35 structural zeros and12 independent
  Torch CPU checks. Full259 PASS83.760s/make check/Ruff; later positive-factor
  underflow guards pass final focused/CPU rerun. Producer copies/logs in
  evidence/proxy-foundation-v12-before-replay. Freeze57 source hashes/runtime/
  old-input manifests before ALL70 queries; no actual-head proxy replay yet.

  GPU startup dc906e1 refused BEFORE ANY query:70 NOT_RUN, foreign PID monitor
  retained in a52_proxy_functionality_v12_initial. Do not relabel as a pass.
- [x] T7512: Separate V13 CPU correctness replay written BEFORE adaptation:
  same ALL70 inputs/tolerances/proof, four CPU threads/no CUDA/no model, peak
  process RSS<=2GiB and original1200s/60s caps. V12 GPU refusal stays intact;
  CPU functionality cannot claim GPU isolation/competitive timing or useful
  variance. Freeze adapter/source/runtime/input hashes before old-head queries.
  After0381620 CPU replay70/70 PASS:33 positive,10 zero action/27 zero prior,
  all preserved. Max independent error1.043e-14, peak whole-process RSS
  1,692,696,576B;70 official tokenizer/json/Decimal audit checks24 correct
  proposals/no proxy miss on these. Zero new forward/sample/update/label.
  See proxy-result-v13.md and a52_proxy_cpu_functionality_v13_initial. This
  is computability only; shared-host diagnostic115.480s is not competitive time.
- [ ] T7513: V14 strengthens the written comparison before variance code:
  raw semantic-proposal full/anchor controls have zero mean and are available
  to EVERY estimator, along with exact regular proxy/state/horizon/RLOO.
  Same9-parameter actor chain rule for all, no chosen score units after data.
  Independently fitted coefficients and complete costs remain required.
  Define a separate necessity/complete-cost protocol before further sampling.
  V15 writes BEFORE code a diagnostic on ALL16 OLD paths/70 states only:
  fixed V14 actor, seven scores/four state baselines/27 zero-mean control
  combinations, all756 configurations retained. Two-path uncertainty explicit;
  RLOO group variance is null, no false iid estimate or favorable gate. No
  new forward/sample/update/label. Actual source freeze follows small checks.
  Three new oracles PASS0.294s:243 original joint-law/9-coordinate dual checks,
  paired trace identity and RLOO group-variance counterexample(1/6 versus
  invalid1/9). Initial accidental-equality fixture retained. Full262
  PASS88.756s/make check/Ruff. ALL756 real-path configurations not computed
  yet; exact runtime/source/input protocol freezes before that diagnostic.
  Producer f106532 completes ALL756 configurations/16 OLD paths/70 states.
  Exploratory same-data minima favor class control0.00369058 over visible
  0.00485158; all seven minima select no regular proxy in the fixed grid.
  Not independent/population/refutation evidence; RLOO variance null, all data
  retained. Posthoc scalar audit recomputes all configurations. See
  old-path-result-v15.md. No large campaign justified by collapse/proxy alone;
  a distinct semantic-baseline-preserving refinement needs proof first.
- [x] T7514: V16 semantic-baseline-preserving conditional auxiliary reuse
  WRITTEN before code. Unary posterior q_B/(H_T Q_B), retained-only anchor
  posterior, original draw reusable as replica1; standard conditional Monte
  Carlo covariance identity. Classical correlated strata/partial enumeration,
  exact semantic projection and strong cheap controls are mandatory. Only
  minimal rational law/moment oracle next; no new real auxiliary draws/head/
  update/timing or usefulness/priority claim. V15 remains unfavorable/exploratory.
  Afterb7f9ad8 four rational oracles PASS0.211s:4 laws821 triples193 actions,
  full semantic baseline/independent posterior moments for1/2/4 replicas and
  192 correlated-strata checks. Exact enumeration remains a stronger control.
  Full266 PASS90.701s/make check/Ruff; zero real auxiliary draws/heads/updates.
  See conditional-prefix-result-v16.md. Only separately written full-V
  functionality/numerical/cost contract may follow, no useful benefit yet.
- [x] T7515: V17 full-V conditional sampler/functionality WRITTEN before code:
  CPU old70 states, four iid+four prefix-history-correlated words each=560
  AUXILIARIES, zero new neural/decoder trajectories/updates/labels. Exact
  categorical tickets preserve tiny IDs but floating outer backwards is NOT
  a native exact-posterior certificate. Only minimal independent laws/rare-ID/
  correlated-prefix oracles before source/runtime/input freeze and real draws.
  Full costs/refusals preserved; no competitive timing/variance/novelty claim.
  Before real draws:83 complete numerical laws match Fraction at L1<=6.317e-16,
  18 dyadic-strata laws retain the smallest binary64 ID, three exact pair
  kernels/20-leaf PSD checks cover ALL scores. Numeric verifier396 Decimal
  checks plus5000-digit exponents pass. Full273 PASS109.220s/check/Ruff.
  Synthetic full-V24 words peak769,871,872B; FAKE driver560 words including256
  legal Decimal-unrepresentable words pass, globals unchanged. Final four-
  thread producer/runtime/input pins freeze BEFORE any real old-head word.
  Producer577a3e5 completes560/560 real-head-derived AUXILIARIES on ALL70 old
  states, four iid/four prefix-stratified each; zero new neural/decoder paths/
  labels/updates. Peak RSS797462528B/globals unchanged. AFTER-data audit560
  tokenizer/Decimal answers and154560 independent score/actor coordinates
  passes8.882e-16. All raw words/statuses/costs preserved. Diagnostic44.049s
  is not competitive speed or total variance. See conditional-full-v-result-v17.md;
  useful benefit/novelty and the scientific goal remain open.
- [ ] T7516: V18 conditional-variance necessity probe WRITTEN before code/data:
  ALL16 known old paths/70 states,64iid+64prefix-stratified auxiliaries each
  (8960), no new head/decoder path/update/labels. Same actor7x4x27 controls,
  common pre-state semantic tail certificate, unbiased cross-half paired-mean
  estimator with negatives preserved; stratified variance uses independent
  batches. Zero-extra-cost20% development screen only, not population/full-cost/
  RLOO confirmation. Small moment/certificate oracles first, then source freeze.

## M74 — Audited executed GPU proposal, hypothesis before implementation

- [x] T7400: Write independent A51 README/eight criteria and executed finite-ticket
  density/max-ratio/scalar-correction proof BEFORE prototype. Recognize OS*,
  Lemire, EBUS, validated rejection and recursive interval samplers. Real
  Mosaic LLaDA2 default model-confidence consumer does not require marginals.
  No sufficiently original theorem or practical benefit is established.
- [x] T7401: Minimal independent rational oracles for finite ticket preimages,
  full accepted original-word law, max-ratio audit, aliases/fixed IDs/EOT/PAD,
  malformed support and finite-budget FAIL. Re-evaluate against the stronger
  classical interval control BEFORE substantial GPU implementation/timings.
  Five tests PASS0.277s;2910 categorical tables/279068 finite source words and
  9986 exact category probabilities, complete small JSON laws and merged suffixes.
  No neural forward/timing. V2 writes the strong retained-uniform interval control
  and corrects the too-broad primary-reading scope. These are classical mechanisms;
  own systems distinction/benefit and the user's goal remain open.
- [x] T7402a: Opt-in explicit PTX .rm/.rp float32/64 add/mul/div/conversion and
  uint64 multiply-high pass18734 independent Fraction/integer checks on3080Ti,
  Torch2.13/CUDA13/Triton3.7.1. Includes1888 positive subnormal uppers2030
  infinite uppers; infinite upper means REFUSE in a finite certificate, not
  silently saturated probability. No timing/model work. Full198 tests PASS
  77.017s; make check/Ruff PASS. Hardware tests do not verify all inputs/compiler
  or the complete sampler. Evidence:51/work/evidence/gpu-primitives-v1.
- [x] T7402b: Shared directed interval DAG/class frontend with exact common
  rescaling passes21 tiny queries/593 Fraction suffix+class enclosures and two
  malformed-support refusals. Independent complete original-word enumeration,
  aliases/EOT/PAD/fixed IDs, subnormals, nonaccepting leaves and multi-block
  reductions; no speed claim. V3 proof precedes code. Evidence:51/work/evidence/
  interval-v1; executed preflight source retained before style-only list change.
- [x] T7402c: Directed GPU inverse-CDF decisions pass4848 exact prefix checks,
  4247 certified601 ambiguous and36 complete category laws with retained-prefix
  fallback. Rational regression gives an explicit redraw-bias counterexample;
  six focused tests PASS0.292s. Initial missing-import draft/log preserved.
  V4 writes full three-phase control/fallback before implementation. No timing,
  new head, sampler-level practical advantage or sufficient novelty yet.
- [x] T7402d: Complete classical interval GPU control replays768 original JSON
  words literally against exact retained-prefix CPU, including147 exact fallbacks
  across deliberately coarse2/8/32-bit screens. ALL4096 fair-bit prefixes of a
  small dyadic merged/alias graph recover all16 target-word masses exactly.
  First compile-failure draft/vector-scalar reuse and log preserved; corrected
  control passes, no new neural forward or speed/novelty claim. Sources and
  data:51/work/interval_sampler.py and evidence/control-sampler-v2.
- [x] T7402e: Frozen source3e6b84c finishesALL15 old-head resource records,
  240 GPU-certified original words/240 literal exact CPU replays,30 independent
  exact terminated-mass checks,zero fallback/refusal/error. This is feasibility,
  NOT timings, new heads or confirmed own contribution. All data preserved in
  51/work/evidence/known-resource-v5. Strong control uses the same full support,
  initial fixed IDs, true EOT/PAD and immutable A24 V11 compiler verified by SHA.
  V6 writes a CLASSICAL telescoping count-factor envelope before implementation
  to avoid an additional max-product audit; no benefit/priority assumed.
- [x] T7402f: V6 rational oracle passes36 JSON/grid combinations and arbitrary
  positive potential/refusal checks: global count envelope dominates EVERY W/Q,
  accepted laws equal the original target, and V1 max-product is never looser.
  Two tests PASS0.098s; not GPU performance or own mathematical novelty. No
  proposed corrected GPU sampler has been measured yet; strong control remains.
- [x] T7402g: Materialize the opt-in integer-ticket candidate underV7/V8 proof.
  Initial count-cap refusal from artificial nonzero potential at certified-zero
  suffix is preserved with source/log. V8 retains PROVEN zero uppers, never
  arbitrary approximate zeros; the first zero-aware checker draft/log also
  remains. Extended checks PASS980 count premises181 full-word max-ratios832
  literal CPU/GPU finite-proposal packets192 accepted JSONs, plus nonaccepting
  terminal rejection and tiny-positive refusal where interval control succeeds.
  Count guard audit142 rows/1088 exact inequalities/six refusals passes. Two
  scalar extreme/packet regressions pass; full203 tests PASS75.441s. None is
  timing, new head, novel mathematical principle or sufficient publication.
  make check/Ruff PASS; source/guard/refusal artifacts and extended evidence
  are frozen before any performance run.
- [x] T7402: Freeze bounded first90 NEGATIVE-only full-query protocol before
  timing, with identical CUDA I/O/model-confidence commit, ALL15 known heads,
  three rotations, complete fresh numeric work, compile/JIT setup separated,
  projected old model cost and a mandatory exact interval control. No positive
  result can follow from only this subset; complete controls and independent
  real neural full cost remain obligations. Eight full-V complete-API checks
  pass, as do two negative-decision oracles. Formatting logs stays outside
  timers; numeric certificate/correction remains charged. Before measurement,
  ticket code reuses the ALREADY computed upper factor and the admitted fixed
  failure bound; identical980/181/832/192 full oracle audit passes unchanged.
  Full205 tests PASS71.777s before timings; full-V8 API checks and frozen timer
  import/cancellation-boundary smoke pass. Runner/protocol/auditor are committed
  together before the first measured record.
- [x] T7403: Execute frozen first90, preserve ALL records/errors/refusals and
  apply the unchanged necessary gate. Only consider remaining exact/native/
  approximate controls if enough states survive; never claim goal fulfilled
  or new theorem priority from a development query comparison.
  Producerb18c5b4 finishes90/90 records/180 correct operations,zero errors/refusals.
  Ticket candidate0/15 against the exact interval control; no remaining controls
  or independent heads triggered. All cases, costs, first-query/JIT setup and
  refusals-before-this-campaign are retained in51/work/evidence/development-v9-first90.
  A zero-decoder-CPU arithmetic floor cannot attain the unchanged20% total CPU
  gate in14/15 states; this diagnostic does not relax the gate or rescue V9.
  No other tests/installations/model work overlapped timings.
- [ ] T7404: Only if a concrete useful systems distinction survives, freeze
  complete-cost protocol/strong controls before implementation/campaign.
  Exactness alone, a tiny FP64 discrepancy or a reference implementation
  cannot satisfy the user's real-benefit/publication goal.

## M72 — Existing Mosaic consumer, stronger GPU controls and termination

M73 below is complete with a NEGATIVE operational gate. Strong cached CPU/CFG
and sparse/layered GPU controls invalidate this extension; no independent
neural campaign is triggered.

- [x] T7200: Read the published Mosaic consumer/compiler/tokenizer/samplers,
  pin36945e4b3c64913e23962e0924a8b40a84c58807 (MIT), write V3's eight criteria
  and full-descriptor adapter proof BEFORE code/heads/timings. Fixed depth3
  for arbitrary JSON sub-schemas is a real operational boundary, not proof
  that our certificate is novel. Equal compile/cache/minimization is required.
  Expected numerical confidence is also a known readout (SECL/digit expectation);
  do not start a new implementation merely by naming Rao–Blackwell/Jensen.
- [x] T7201: Minimal opt-in adapter leaves native kernels unchanged, verifies
  all imported files against pinned Git objects and restores import precision.
  Give the control classical Hopcroft minimization over original-token classes.
  EOS-ABSENT small preflight passes5576 byte-language checks,21220 marginal
  checks and8640 valid samples across CPU/CUDA/native fp32/product64/fp64.
  Max observed absolute marginal/confidence error4.76837158203125e-7; not a
  global rounded-law guarantee. Actual environment Torch2.8/CUDA12.8 differs
  from upstream's full Torch2.13 serving environment. Two failed all-fixed
  fixture drafts are preserved independently. Two offline regressions PASS0.016s.
  Sources/data:24/work/consumer_v3 and evidence/consumer-v3-preflight-v1.
- [x] T7202: Implement the separately WRITTEN variable EOT/PAD proof, validate
  true bounded mass versus independent word enumeration; never use surrogate
  shallow mass in the conditioning denominator. All original special IDs and
  real termination probabilities count. First resource screen uses known old
  data, with no positive timing or independent-confirmation claim.
  The implementation/oracles are now complete:8284 minimized-language checks,
  28 exact mass/tail checks,3720 native marginal checks and1200 valid samples
  in CPU/CUDA. Three new rational offline tests cover variable boundary joint
  law, original aliases, true mass versus surrogate and fixed-canvas reuse.
  Five focused tests PASS0.045s; data:consumer-v3-termination-v1. The full-V
  resource screen is still pending, with no real new head or speed claim.
  Before measuring, symbolic classes now precede minimization so the native
  control avoids raw-V expansion. The same8284/28/3720/1200 checks pass in
  consumer-v3-symbolic-termination-v1. Full suite185 PASS73.863s, check/Ruff
  PASS. Frozen source4c80a59 completesALL45 full-V resource rows:42 nonzero
  and3 zero shallow masses;190 native configurations complete/correct,20
  conservative allocation guards,0 errors/warnings. Thirty bounds checked
  against exact FULL terminated masses. Resource gate14/15, not speed or new
  heads. The tail of this diagnostic screen overlapped isolated Torch2.13
  dependency setup; no timing finding is made. Data/report:consumer-v3-resource-v1.
  Before performance work, V4's written cache proof requires a symbolic CPU
  control without Hopcroft/V expansion, fresh numeric caches per changed head,
  and compatible-canvas reweighting. Those optimizations are classical and
  not evidence of new novelty. Implementation/full-cost protocol still pending.
- [ ] T7203: Only if the resource/cost screen is plausible, freeze a new actual
  consumer protocol and independently selected external inputs before heads.
  Pay compilation, cache/reweighting, ALL forwards, exact certificate, native
  GPU controls, confidence policy and output. Require substantial operational
  benefit and identifiable originality; an adapter/oracle is not the goal.

## M73 — Strong cached controls before an operational benefit claim

- [x] T7300: Write compatible-canvas, symbolic CPU, common-ranking and direct
  compact CFG proofs BEFORE adapters. Preserve the original A24/CFG sources
  and a separate module namespace for the lexical DONE/EOT/PAD hook. Both
  block and legacy samplers retain ORIGINAL IDs. Fresh heads rebuild numeric
  caches; changed/released initial fixed IDs are rejected. First ranking
  draft confused selection-set equality with tuple order; source/failure
  preserved, canonical physical order fixes the common map.
- [x] T7301: Independent rational mass/ALL-marginal/finite-ticket law checks
  for direct symbolic CPU, new heads/fixed aliases, cached first overflow and
  handoff, ranking ambiguity/refinement, and ALL THREE direct compact CFG
  controls. Eleven focused tests PASS0.184s; suite191 PASS73.521s, Ruff PASS.
  Sources/data:24/work/consumer_v3, consumer-v4-*-proof.md and
  evidence/consumer-v4-strong-controls-oracles-v1.
- [x] T7302: Isolated optional Torch2.13.0+cu130 native-kernel environment is
  installed without changing .venv-live. Both CPU/CUDA stages pass the same
  5576/21220/8640 original and8284/28/3720/1200 terminated oracle checks.
  This matches upstream sampler Torch, not the full HF/serving stack. Pins
  and pip-freeze/source evidence are preserved. No new neural head or timing
  win follows from compatibility.
- [x] T7303: Freeze complete-cost known-development protocol with compiled
  caches and direct full CPU/CFG controls; include native GPU and competent
  quotient/sparse FA alternatives when applicable. Do not attribute dense
  E×V or N×E storage to all FA inference. Require credible substantial benefit
  before selecting an independent application/corpus and running new heads.
  The user goal, A24-specific originality and publication remain open.
  Before timings, the independent sparse-FA quotient/HMM control is now
  implemented:2184 numerical marginal checks88 valid samples CPU/CUDA pass
  in Torch2.13, including changed weights/fixations; no dense E*V/N*E/N*N
  buffers. Sparse CSR beta warning is retained. Proof precedes code; this is
  a CLASSICAL control, not a new contribution. Development protocol now fixes
  ALL15 known states,17 methods/configs,three rotations and a negative-only
  first315-row futility audit; complete positive gate needs all765 rows.
  The stronger fixed-canvas layered GPU control was added BEFORE timings;
  it also passes2184/88 checks and avoids repeating merged states at every
  position. Earlier675-row protocol is preserved UNEXECUTED. The complete
  CUDA-output API passes14 cold/warm checks against60 independently enumerated
  original words; sampling TV remains charged at the ORIGINAL draw depth.
  Two offline decision oracles pass; syntax-error draft/full-suite failure
  are preserved. Corrected maintained suite193 PASS75.536s, Ruff PASS.
  Protocol/runner/source frozen0c75b91 BEFORE measuring. ALL315 first-stage
  records complete/correct cold AND warm;135 exact ranking checks135 literal
  CPU cache matches. Both candidates fail the mandatory paired projected
  wall/CPU comparison inALL15 states. The450 remaining rows are NOT executed;
  they cannot reverse the necessary failures. No new forward or independent
  campaign. Decision/rows/report:consumer-v4-development-first-v1. Sparse and
  layered GPU methods are CLASSICAL controls, not a new positive contribution.
  Preserve the old scoped query result with its original comparators; the
  user's novelty/usefulness/publication goal remains open.

## M71 — A24 consumer refinement, useful full-operation benefit required

- [x] T7100: Write query-consumer V2's eight criteria, operation-equivalence
  argument and ALL15-state development protocol BEFORE implementation/timings.
  Existing external states are now known development, not new confirmation.
  FactorDLM/class disintegration, A28 exact numerical summaries and sparse
  outside are antecedents. Dense outside alone is capped by historical costs;
  no large benefit/publication/mestrado acceptance is promised.
- [x] T7101: Implement minimal exact NumPy boundary plus sampled-token confidence
  cursor; give equivalent summaries/queries to closed, handoff, grammar-hit,
  suffix-hit and exact stack. Validate against independent original-word laws,
  full sparse outside, aliases, fixed IDs and threshold equality/refinement.
  Six independent oracles PASS0.011s; new CI wrapper preserves original suite.
  Initial law fixture had only one valid word and failed its branch-count
  assertion; adding whitespace BEFORE timings exercises the full RNG law.
  Maintained suite176 PASS71.746s; make check/Ruff PASS. This is correctness,
  not a useful-performance, originality or academic-acceptance gate.
- [x] T7102: Freeze producera5219c5, run ALL15 states/three rotated repeats with complete
  costs and all outcomes. Old dense API is only an ablation. Require surviving
  advantage against best sparse controls before triggering new neural work;
  compact controls remain required for a broad complete-decoder claim.
  ALL540/540 COMPLETE, zero errors/refusals; every completed same-kernel sparse
  pair preserves sample/commits/queried intervals literally. Closed/handoff
  variants all pass4/15 against six matched stack/overflow/suffix interfaces.
  Selected handoff/cursor by frozen tie order; three states have factor2 paid
  wall AND CPU against best completed control. Dense API ablation medians:
  wall ratio0.201/CPU0.301, not novelty or a strong-control victory by itself.
  These are OLD known heads, no new neural-independent confirmation.
- [x] T7102-CFG: Frozen supplementary ALL15x4x3=180 fresh operations give all
  three immutable compact CFG controls the same vectorized boundary, block
  recovery and sparse confidence. Eight small original-word/finite-law tests
  PASS0.038s after adaptation; compiler source is unchanged. Resource refusals
  are capacity only at3GiB/120s, never general latency impossibility.
  Producer8541f4f completes180/180:144 complete/36 resource refusals,
  99 full exact-mass checks with zero divergence; all four prior states
  survive the scoped comparison. Data/decision:24/work/evidence/consumer-v2-compact.
- [x] T7103: Only after positive development, define and execute a NEW iterative
  full-cost application pilot with complete controls and paid resources. Assess
  usefulness/originality of A24 itself; no acceptance claim follows from code.
  Preflight freezes270 trajectories (ALL15 known states x9 methods x2 seeds),
  full parent+child process CPU and actual new forward/IPC/I/O cost, sparse
  controls and dense ablation; capacity separated from latency. Ten focused
  oracles PASS0.271s including actual service CPU clock/refinement and alarm
  cancellation. No new model heads in this preflight. Protocol/source:
 24/work/consumer-v2-neural-protocol.json and consumer_v2/{neural,service,analyze_neural}.py.
  Producer451de419 completes270/270:246 complete/24 explicit resource refusals,
  zero errors;1345 new forwards plus one warmup. Selected candidate30/30 valid;
  30 literal cursor/full-sparse trajectory matches,1321 valid original samples,
  735 exact-mass certificate checks. Frozen scoped warm gate2/15 (149c0c8c-16,
  c87bca6a-16), with all three compact controls refusing at3GiB in both states;
  strict timing gate with all six controls complete0/15. No independent corpus
  or semantic confirmation. Report:24/work/evidence/consumer-v2-neural-v1/decision.md.
  Full3,430,582,208-byte head cache remains local, explicitly not a complete
  offline published packet; all raw trajectory/cost journals and initial
  contexts/vocabulary are committed. Before reporting, all38 measured source
  hashes and270 first-head identities checked; demo is offline functional only.
- [ ] T7104: Close the real external-consumer and A24-specific originality
  objections before a larger application/confirmation campaign. The completed
  two-seed pilot gives scoped warm-cost benefit, not broad practical utility,
  independent latency confirmation or publication. Primary refresh credits
  Denkinger bounded/weighted abstractions, Sakharov counters and Dang/Ermon
  constrained-marginal commits. No threshold relaxation or new scientific
  novelty is assigned to the classical numeric/query interface.

## M70 — Exact grammar residual operation, mathematical and prior gates first

- [x] T7000: Before another direction, implement A49 V30's CLASSICAL exact
  range-sum root optimization opt-in. Producerba76910 passes74,593 signed
  product queries plus300 original-word checks/108 undefined cases; old/new
  fields agree literally. It is not scientific novelty or measured speed.
- [x] T7001: Start independent A50 with eight criteria and a written
  relative one-sided mass/bit/zero-support proof BEFORE code (c1c1668).
  Keep ORIGINAL root normalizers under evidence. Unvalidated producer7f0fbdd
  did not check invalid draft membership; correction5f07ea7 is explicit.
  Oracle source8661645 refuses a fixed-slot low-mass fixture after19 rows;
  preserve failure, do not turn it into a successful sampler test.
- [x] T7002: Correct only the fixture and freeze source9ca1f54 BEFORE its
  successful V3 run:482,657 tail checks/6,480 merges,700 word densities,
  4,560 prefix bounds,15 complete proposal/coupling laws,240 valid samples.
  Undefined count0 in V3 is NOT zero-mass coverage. No latency or priority.
- [x] T7003: Write V4 marked-edge outside proof BEFORE code. Sourcea6d2378
  passes the above checks plus51,340 ALL original-ID marginal enclosures and
  11 actual undefined-posterior refusals. Shared profiles avoid q full analyses
  per position; they do not prove superiority against all shared algorithms.
- [x] T7004: Write V5 upper-tail/pathwise-envelope/provenance/singular-channel
  proof BEFORE code (afca26a). Source4184183's175-line reference pays ONE
  preparation, O(H*M^2) provenance and exact correction. Its complete oracle
  passes475,041 upper-tail checks/6,480 merges,1,780 word cases,18 full accepted
  laws,6 singular laws,432 valid samples and12 undefined refusals. Twelve
  original grammatical words actually increase their representative ratio.
  Evidence:50/work/evidence/oracle-v5; written bound is <2 conditional attempts,
  not wall-time, a deterministic deadline, native EPIC or semantic improvement.
- [x] T7005: Read relevant primary originals, including Dyer2003 §2.1 FULL
  preparation/rejection argument and Gawrychowski/Markin/Weimann2018 ENTIRE§2.
  Credit their exact-sampling principle and sum/convolution calculus; do not
  claim those as inventions. primary-comparison-v5.md/primary-v5.json retain
  actual readings/hashes and unavailable2019 full sampling section. Maintained
  170-test suite passes72.873s during this development; research law oracles
  are separate and do not establish publication or a faster generator.
- [ ] T7006: Close the strongest known-construction objection, actual grammar
  admission/bit/runtime proof, and operational utility after ALL preparation,
  provenance/head/output costs. No large implementation or favorable model
  campaign substitutes for this. Novelty/human review/publication remain OPEN.
- [x] T7007: Obtain the actual2019 journal PDF through its public repository
  API and read the full sampling Section4, proof and costs; V6 preserves its
  hash and removes the earlier missing-original objection. V7 closes random-
  bit costs and specifies a law-preserving iterative consumer, subject to
  value-independent commit positions. No decoder/head reduction is measured.
- [x] T7008: Strengthen the control BEFORE timing: exact scalar common measure
  and subtraction-free difference channels. Source2dba8da passes1,780 word
  cases,90 complete channel laws,18 residual laws,432 valid outputs and12
  undefined cases. Feng/Guo/Jerrum/Wang2023 §3 already supplies the product
  proposal and identical acceptance estimator; its rejection use is immediate.
- [x] T7009: Write bounded-bit integer CDFs BEFORE code (a53a4fd). Preserve
  V9 grid2's unavailable zero-mass channel assertion failure. V10 source8f3f72f
  fixes that contract and repeats ALL grids:1,780 words/90 channel/18 residual
  laws each, adaptive432 valid outputs with no bound loss; fixed2/4/256 have
  six cost-bound losses and292/237/185 bounded FAILs. Correct law is separate
  from efficient termination. No neural or performance claim follows.
- [x] T7010: Read2024 original Section4 and full deferred coupling proofs;
  its proposal, rejection interpretation and2n bound account for V8's principle.
  known-reduction-v11.md explicitly downgrades the scalar novelty argument.
  Read the2026 linear randomized product estimator's actual proofs; no weak
  prior estimator is used as the strongest current control. Sourceac3adf1.
- [x] T7011: Write marginal-free grid precision BEFORE code (120cffb).
  Source291cde5 passes1,780 words/90 channel/18 residual laws/30 equality
  and range queries/432 valid outputs/12 undefined cases;131 trial passes
  count. Refactored marginal-grid control also passes fully. This is compact
  engineering of a classical construction, not original theorem or speed.
- [x] T7012: Complete ALL30 prospective initial admission rows (15 actual
  old heads, full/top16 frozen supports), then all admitted next-canvas
  actual neural captures and four exact correction variants. Source8cb69bf
  is frozen first; retain all zero masses/refusals/errors and actual paid
  resources. Functional development only; no latency/semantic/EPIC victory.
  Initial:15 full-support preprocessing refusals/nine top16 zero masses/six
  admissions. Capture4680ff2:seven actual forwards including warmup, six
  complete literal softmax replays. All24 corrections:23 valid JSONs/one
  profile wall refusal; four cached states retained/two residual branches.
- [x] T7013: Preserve ALL numerical sources in optional joined115,619,971-byte
  replay packet, split four Git-safe parts; whole/member/part hashes included.
  V14 explicitly audits wall-time censoring: successful timed outputs are
  not proven to have P; unlimited kernel law and bounded FAIL/subprobability
  contract are distinct. No proof, costs or priority claim is silently upgraded.

## M69 — Rational drift certificate, proof before application

- [x] T6900: Write49's eight criteria and planar rational normalization/
  aggregation proof BEFORE the finite oracle. Original Fu2609.24235v1
  Definition3.6/Theorem3.8 already supplies the general admissible-gate
  FPTAS; generic unambiguous-derivation specialization is a corollary.
  Candidate bit-cost/planar/word-faithful distinction remains OPEN. No heads.
- [x] T6901: Independently attack all-query norm containment with integer
  breakpoints, exhaustive sign domains, zero rank and near-collinearity.
  Then prove the packed-word reduction and complete integer bit costs.
  V1 producer8f19b2f passes3,100 cases/57,769 exact norm queries and1,004
  exhaustive sign-domain queries;2,799 cases actually shorten. V2 writes
  the polynomial bit theorem for an ADMITTED scoped event forest, explicitly
  separating original-source preparation and compiler verification. The
  producer51245fc's compiled-forest oracle passes all75 cases (48 certificates,
  27 undefined-zero-mass refusals). All original-ID expected answers are
  independently enumerated. V3 writes BEFORE code a classical-projection,
  integer-endpoint refinement with O(sqrt(d/epsilon)) stored core rows and
  explicit comparative/bit bounds. Priority and full source admission open.
  V3 producer2e3b4a7 passes2,480 cases/40,035 exact norm-breakpoint queries
  and all75 original-token cases under BOTH compressors (150 checks).
  V8 producer45903f3 passes1,860 geometry cases/30,846 norm breakpoints,
  117,376 independent exhaustive projection queries and75 original-ID forests.
  V7 writes classical polynomial source admission; V10 explicitly trims
  unreachable/unproductive symbols. Theorem is written, not Lean/compiler
  verification. V8 query proof sharpens product precision exponent to1/2.
  Finite checks do not establish novelty, speed or publication acceptance.
- [x] T6902: Materialize the smallest real operation under the frozen V4
  all-format/all-tolerance numerical-audit protocol. V4 fixed-slot fixture
  failure, V5 FULL-input refusal and interrupted V6 (1/6 rows) are preserved.
  V9 producerbb1be02 completes ALL6 unchanged cases on50,258 original IDs,
  independently checks both masses, counts109,026,321,152 valid assignments.
  FP16 epsilon0.1 upper4.095231914338327e-5 versus certified Hellinger
  upper0.0027838314673018887. Controls are cheaper. This is certificate
  precision, not neural quantization, a competitive timing gate or EPIC win.
- [x] T6903: Read the ENTIRE ICML2024 section4 reduction/proof; credit a
  competent derivation encoding rather than claim first CFG approximability.
  Primary-comparison-v10 isolates the sharper deterministic upper bound and
  polynomial integer arithmetic. Producer476ace7's direct product recurrence
  passes ALL1,167 prospective cases/six zero-mass and eight invalid refusals.
- [x] T6904: Write complete mathematical draft with3 theorems, product
  corollary, complete costs, original-word application and ALL6 generated
  audit rows. Source:49/work/manuscript-v10.tex; seven-page PDF:
  output/pdf/grammatical-drift-v10.pdf. Layout/source QA is not peer review.
  This is a candidate article; the preserved main A24 article is unchanged.
- [ ] T6905: Continue adversarial full-proof/nearest-prior checking and
  consolidate the quantitative contribution only on that basis. Exhaustive
  priority, independent human judgement and editorial acceptance are NOT
  confirmed. Do not manufacture a generation benchmark or call deterministic
  upper-bound improvement universal physical/semantic superiority.
- [x] T6906: Prove the small exact-input shortcut BEFORE code, preserve V10
  unchanged. Source3a9416b passes ALL1,860 geometry cases/30,741 norm queries,
  117,376 independent projections and75 original-ID forests; ALL1,167
  original products plus389 extreme-precision products and six signed checks.
  V11 has O(m log(m+2)) core compression work, same guarantee. Three small
  independent regressions are included in existing offline CI (`tests/test_integer_tv.py`)
  and pass at67b5f92. The complete167-test suite passes70.530s. Matoušek1996
  and Reis/Rothvoss2026 scopes are recorded in geometric-priors-v11, not
  full-paper review or a new geometric/bit-computability claim.
- [x] T6907: V12 freezes a strengthened O(m)-work rational angular control,
  matched budgets and all18 public functional rows BEFORE new code/timings.
  Same operation, all original IDs and complete costs; no independent timing
  gate or synthetic performance family. The sharper precision exponent must
  remain distinct from geometric antecedents; faster controls stay reported.
  Producer5a72f1b passes5,580 geometry/80,898 norm checks,225 forests and
  3,501 products. Producer81c6c5b preservesALL18 public rows:12 certificates,
  six angular materialization refusals, no errors. Refusal by a table cap
  is NOT a victory; V13 must stream the competent control's products.
- [x] T6908: Producer9111102 removes that cap with classical three-scan
  streaming. ALL18 public rows conclude, no refusals/errors; every original
  case/control remains. ALL5,580 geometry/83,054 queries,225 forests,
  3,501 products and300 Cartesian checks pass before observations. Single
  developmental timings are NOT independent/statistical/general superiority.
- [x] T6909: Write a strict positive-probability stored-core separation before
  code: Omega(1/epsilon) streamed uniform buckets vs O(1/sqrt(epsilon)) endpoint
  rows, SAME all-query guarantee. Producer8cae148 passesALLfive formula cases,
  no timings/forwards. Explicitly credit the exact one-position scalar control;
  this is NOT a TV complexity lower bound or favorable generation benchmark.
- [x] T6910: V15 proves/verifies exact all-direction a posteriori certification
  for adaptive angular aggregation; every method gets exact unary/diagonal
  passthrough. Producer748fc16 passesALL5,580 geometry/80,016 queries,
  225 forests,3,501 products and300 Cartesian checks. Producer9d7aab9 finishes
  ALL18 public rows. Adaptive wins BF16/epsilon0.5 core against BOTH candidates;
  retain this loss. No universal/independent/statistical timing success claim.
- [x] T6911: V16 strengthens inexpensive bounds via common-support coupling,
  Hellinger/both chi-square directions/range. Producerb969c64 fails on the first
  general forest: imported bridge scalar helper assumed node-ID topological
  ordering. Zero new bound cases certified; public run NOT triggered. Preserve
  failure, then V17 must evaluate explicitly in CfgSampler.order and repeat
  ALL75 oracles before ALL18 unchanged functional comparisons.
  V17 producer87a3b52 passes75 cases/27 undefined and ALL18 public rows,
  no refusals/errors. Strengthened FP16 upper0.0007602747856462345, not the
  old Hellinger0.0027838. Chi-square absolute precision can still be loose
  under denominator imbalance; V18 must use scale-aware atom precision.
- [x] T6912: V18 proves relative64-bit atom precision for BOTH chi-square
  directions without large rational LCMs. Producerd8b87c4 passesALL75 cases/
  27 undefined and ALL18 public rows, no errors/refusals. Strongest cheap
  FP16 bound remains0.0007602747856462345 vs endpoint4.0946010443571345e-5
  at0.1; report approximately18.57x, not67.98x against this strengthened set.
  Adaptive BF16/0.5 core loss and full costs remain; no independent speed gate.
  Maintained checks after V18: `make check` passes upstream/lint/format/types
  and49 attempts/172 immutable versions; `make test` passesALL167 in71.665s.
  No Rust/Lean/main-posterior implementation changed; no new neural execution.
- [ ] T6913: V19 writes BEFORE code an ordered integer-core/sweep recurrence
  with product bound O(n*q*sqrt(n/epsilon)*log(q+2)), same guarantees and full
  bit/input costs. Classical geometry/merge are credited. Repeat all geometry,
  exhaustive outside projections,1,167 products and389 extreme-precision
  cases before a real application; nearest-prior/publication judgement open.
  Producerb0c678a FAILS at the first nonempty ordered-image case: reversed
  minimum-angle comparison rotates the largest angle first. Only three empty
  cases complete; zero product/forest/public claims. PreserveV19 unchanged,
  correct inV20 and repeat the entire frozen gate; no weakened checks.
  V20 producera4bf58d passesALL1,860 geometry/33,747 queries,117,376 exhaustive
  projections/1,860 image checks,1,167 products/389 extremes and75 original-ID
  forests. No public run. Next consolidate the corrected ordered proof with
  strongerV18 controls and inspect additional primary product-TV frameworks.
- [ ] T6914: V21 freezes all24 functional rows including ordered endpoints,
  strongest adaptive/scalar controls, complete costs and ALL original formats.
  COLT2025 sections2/3 checked; polynomial-bit computability and generic
  geometry/inference are antecedents. Consolidate a NEW mathematical draft;
  preserveV10, no independent/publication/EPIC superiority assertion.
  Producer3702503 completesALL24 rows, no errors/refusals. Ordered forest
  timing is not uniformly better; retain FP32 losses/BF16 adaptive win.
  No new capture. Evidence:49/work/evidence/public-v21 and origin-v21.json.
- [x] T6915: Consolidate a NEW ten-page mathematical manuscriptV22 and generated
  ALL24-row table, with complete ordered/product/bit/word proofs and stronger
  controls. V10 PDF remains immutable. Budgeted-use-v22 gives the standard
  coupling application, not a deployed/measured new iterative decoder.
  Four focused regressions pass; they exercise both engines and the realV19
  failure. Final10 PDF pages rendered/visually reviewed; no LaTeX warnings.
  MainA24 paper, Rust, Lean and neural model remain unchanged. Publication
  priority/significance/human-review goalT6905 remains OPEN; no absolute claim.
  Maintained source2f406e3: `make check` passes (175 archived versions at run),
  `make test` passesALL168 in70.403s; focused four-test regressions and their
  lint/format checks pass. Evidence:49/work/evidence/checks-v22.json.
- [ ] T6916: V23 freezes a broader audit BEFORE forwards: ALL5 pinned original-
  byte documents x4/8/16 masks x3formats x2tolerances x4engines (360 rows).
  FIRST doc is seen regression; remaining FOUR unseen byA49 TV development,
  not unseen byA24/model training. Strongest controls/costs/refusals preserved.
  Newcapture/producer/evidence and functional precision gate still PENDING.
- [x] T6917: V24 writes BEFORE code a stronger classical sampler-overlap scalar
  control on full/common support, with certified dyadic lower recurrence.
  ALL75 oracle cases and ALL24 old functional rows must repeat before the
  independent-document capture. V23 source/protocol archived with ZERO new
  forwards/TV observations; no metric-driven threshold or case change.
  Producer56ba17a passesALL105 independent word checks (33 undefined) and
  ALL24 public rows, no errors/refusals/forwards. Classical full/common overlap
  removes the prior18.57x FP16 gap: only1.05476x remains; FP32 control is tighter
  than the candidate upper. HistoricalV22 PDF remains unchanged; it must NOT
  be presented as current comparison against this stronger control. All evidence
  is preserved in49/work/evidence/{overlap,public}-v24. Independent audit must
  add BOTH overlap controls without changing the still-unobserved2x gate.
- [x] T6918: V25 incorporates BOTH classical overlap bounds in the unchanged
  ALL360-row external protocol BEFORE new forwards/independent observations.
  Validate process/deadline/memory orchestration on ALL24 old packet cases;
  only then capture ALL15 actual heads and run the full unseen-document gate.
  Preserve every shared refusal/loss and account child CPU/process management.
  Producer8192f2f passesALL24 guarded development rows, matching V24 intervals/
  masses/counts/scalar controls exactly. Capture producerc2029ca executesALL15
  actual heads plusONE warmup; verifierde95c29 confirms bit-exact full Torch
  softmax and original bytes for all5 docs, no added forwards. ALL360-row audit
  completes256 certificates/104 refusals, no missing rows,3750.830s wall and
  3749.986s CPU. The frozen2x gate FAILS in ALL36 primary pairs; no refusal
  receives credit. Additional ideal-control checks pass75 original-word
  oracle cases but confirm zero robust wins. All45 pairs/360 raw records and
  origin hashes are in49/work/evidence/external-v25 and decision-v25.md.
  Sourcee6cef06's maintained suite
  passesALL169 in71.697s; the new macro/alias oracle covers non-ID-topological
  order. Raw head/probability arrays remain local; their hashes are published.
- [x] T6919: BEFORE implementation, V26 writes the classical streamed known-
  root query and exact rational loss propagation, given to ALL four engines.
  Producer8216ee0 passesALL300 old word/engine checks, then completesALL360
  development rows:256 certificates104 refusals, no missing rows/new forward.
  One of45 development pairs passes the old2x diagnostic (2.02282896x), also
  robust to ideal control rounding. It is NOT independent confirmation or a
  speed claim; V25 remains FAILED0/36. All360 records/45 pairs preserved in
  work/evidence/external-v26 and decision-v26.md; complete costs charged.
- [ ] T6920: V27 writes two-sided fidelity decisions AFTER V25's failure;
  do not relabel that upper-precision gate. Classical marginal, Hellinger and
  moment lower controls are proved before prototype. Sourcec9f839f's unchanged
  105-case oracle passes (33 undefined-zero-mass). V28 materializes all-budget
  decisions (T6923); an actual deployment benefit remains unconfirmed.
  Full-arithmetic-scaling-v27 closes GCD/output accounting on paper; measured
  reference still uses LCM/Fraction. Chart-error-count-v27 gives d<=3B-2 only
  for admitted CNF, with wide unions charged. Source-error-count-v27 avoids
  any unverified CNF conversion: generalized LL(1) chart d<=2(h+1)(2B-1),
  h acyclic same-span height, empty subtrees exact. This is written source
  admission, not verification/implementation of the actual stack compiler.
  Markov-corollary-v27 states O(nq^2 sqrt(n/epsilon) log(q+2)), using ONE
  multiplier per whole transition layer, not per previous state. Publication
  novelty/significance, independent proof review and the application stay OPEN.
- [x] T6921: Scalar-gap-v27 is proved BEFORE finite arithmetic verification:
  a positive rational JSON proof family gives Omega(sqrt(n)) upper/TV for
  ALL named ideal cheap controls. Sourcef039265 passes all six cases using
  a competent EXACT O(n) binomial counter. This is a guarantee separation,
  not a benchmark/model observation, exclusive capability or repaired gate.
  Evidence: work/evidence/scalar-gap-v27. Maintained source28aa611 passesALL170
  tests in70.627s, including the new shared known-root original-ID regression.

- [x] T6922: Write a NEW mathematical manuscriptV27, preservingV22. Eleven
  pages include ordered product/Markov bounds, complete scaling/bit/source
  chain costs, the scalar-gap proof and BOTH external inventories. All45
  ordered pairs per campaign and macros derive from verified records; clean
  source22a0aeb reproduces all report products byte-identically. The PDF has
  zero LaTeX warnings; all11 final rendered pages are pixel-identical to the
  visually reviewed images. Artifact QA is not human mathematical review.
  Source22a0aeb passes `make check`, including180 immutable snapshots. The
  novelty/utility/publication goalT6905 stays OPEN; no new model experiment.

- [x] T6923: Consolidate A49 following the user's feedback; no attempt50 or
  new neural campaign. Freeze work/consolidation-v28.md BEFORE implementation.
  Sourcecaf5721's grammar-tight classical moment controls pass105 independent
  word checks (33 zero-mass undefined). Its complete decision replay covers
  ALL45 old pairs/ALL120 illustrative precision policies:33 classical
  intervals,12 historical shared refusals,22 extra accept/31 extra reject
  budget regions, ONE extra accept/EIGHT extra reject grid decisions, ZERO
  narrower word-width choices. All costs preserved; lower/range passes alone
  total108.784s wall/108.761s CPU. No new forward/core, gate or independent
  confirmation. Reports independently reconstruct528 decisions; exhaustive
  small interval/equality audit checks1295 outcomes. Evidence/provenance:
  work/evidence/{decisions-v28,tight-oracle-v28,origin-decisions-v28.json};
  decision-v28.md and claim-audit-v28.md retain the unsolved novelty/actual-use
  gaps and the unimplemented generalized chart/Markov corollary. This does
  not close T6905 or imply a more efficient dJev.
  Maintained source98e7dce passesALL170 tests in71.121s and `make check`
  (upstream, Ruff, types and181 snapshot-integrity checks). No extra tests
  or new model measurement is credited as proof of novelty.

- [x] T6924: Close the direct-composition objection BEFORE more rounding
  audits or another implementation. Read Chan2006 author-original Sections
  2.1/2.3/2.4, complete Theorem2.1/Corollary2.2/Theorem2.6 proofs, and AHV2004
  Lemma3.6/3.7. Work/direct-composition-v29.md derives a symmetric width
  kernel, original-vertex parity, exact nearest-vertex envelope scans, Fu's
  induction and the SAME O(nq sqrt(n/epsilon) log(q+2)) full leading bound.
  Generic forest/Markov and polynomial-bit consequences are available to
  this competent composition too. No new code/test/forward/timing; no claim
  that an older TV paper printed the combined formula. Downgrade the alleged
  separating precision/integer advantage to a specialization, retaining
  chronological-priority/publication questions and T6905 OPEN. V25/V28 stay
  negative for their declared applications; A24 stays separate. Primary
  source versions/hashes/scopes recorded in work/evidence/primary-v29.json.

## M65–M68 — Eliminate false novelty before another implementation

- [x] T6500: Freeze A45's eight criteria and adverse-only population screen
  before observations (producer1d68d3a). All6,230 cases/238 ticket profiles
  complete, no eigenvalue>1e-9. This is NOT the missing universal proof.
  ALL outputs/hashes preserved in45/work/evidence/screen-v1; decision-v1
  connects B6 to the already OPEN A42 anonymous family (lambda2).
- [ ] T6501: Prove/refute arbitrary-class, arbitrary-budget covariance safety;
  find an actual useful cheap dLLM/CFG source before a model application.
  Known HST/systematic/ranked resampling and stronger RSS/CV stay controls.
- [x] T6600: A46 reads original bounded-ambiguity correction2001 and #CFG
  FPRAS SODA2026, plus weighted-counting reductions2015/2024. Generic1/d and
  rational-to-unweighted lifting are OLD; closed before code. Arbitrary
  ambiguity remains a capability investigation, not a new contribution.
- [x] T6700: A47 audits exact interval/random-bit sampling BEFORE code.
  Duchon2011 section6 and Brassard/Devroye/Gravel2019 sections2/4 already
  give adaptive certified comparison and expected precision. Generic forest
  specialization is closed as novelty; huge-logit complete bit-cost oracle
  remains unwritten. No ideal-softmax solver or numerical win is claimed.
- [x] T6800: A48 reads CFD UAI2004 original and re-reads FactorDLM3.1--3.3.
  Generic PCFG versus wide natural-MRF separation/context-specific circuits
  are OLD. Constant gated branches require a conditioning control. No graph
  compiler, constructed performance benchmark or new forward was run.
- [ ] T6801: Continue the original useful-publication goal. These audits,
  preserved screens and mathematical outlines do not fulfill it. Main article
  remains A24 with qualified evidence; no new protagonist has passed the gate.

## M64 — Three-class finite-budget arbitrary-vector safety

- [x] T6400: BEFORE code or model measurements write44's independent eight
  criteria and candidate analytic proof: empirical atom-optimal three-label
  coupling, binomial diagonal deficit, square-root concavity, Heron/minor PSD,
  all-target covariance, balanced cap-B minimax and exponential repeat bound.
  Classic transports/RSS/Bernstein bounds credited. No novelty/model win.
- [ ] T6401: Independently enumerate original payloads/aliases and random
  sampler choices; verify rational minors, all-budget polynomials and preserve
  adverse C4/nonuniform comparisons. Audit primary ranked/systematic sampling
  before calling the specific all-vector theorem a contribution.
  Producer090c357 passes12,844 rational matrix laws,eight independent source
  product families,360 exhaustive RNG tapes and14 polynomial identities.
  The adverse C4 comparison is preserved exactly. Primary scopes/reductions
  in44/work/primary-reading-v1.md; specific priority/use still OPEN.
- [ ] T6402: Only if proof and priority/use survive, preregister full-cost
  dLLM/CFG application with RSS/CV/count/inverse and seed controls. No revived
  root-known source or favorable case selection; old negative evidence stands.
  Minimal V3 falsification, protocol/source e0d918d frozen before observations:
  ALL six old public docs,192 new FULL-parameter forward/backward evaluations,
  zero updates. All169,627,218 parameters and independent bias checks; three
  bookkeeping source-product families pass. Candidate screen0/6 even at zero
  overhead against continuous RSS AND oracle-CV. Close this classifier/use,
  do not trigger competitive timing/heldout/training. Decision/evidence in44.
  V2 balanced RSS corollary has354 exact checks; failed expected best-order
  constant preserved, corrected producer3ca3914. Priority/theory use open.

## M63 — Adaptive original-source excursions

- [x] T6300: BEFORE code/model outputs write43's independent README/eight
  criteria and pure candidate proof. Operation: two expensive original loss/
  gradient evaluations, fixed binary proxy, retained first source; adaptive
  first-return/barrier walk, no path-dependent deadline fallback. Classical
  ruin/factory/information principles credited; Huber2016 section3.1/4 read.
- [ ] T6301: Independently verify full original-source law, aliases, vector
  covariance, exact E[N]=M for all class masses, tail and balanced sharp
  expected-query bound. Inspect sequential-estimation primary predecessors.
  V1:423 rational chain laws/3952 terminating tapes and15 balanced moment
  checks PASS under producer6dcd88e; all aliases/residuals and vector entries
  checked. Pure KL proof avoids unstated stopped differentiation. Specific
  frontier priority and useful complete-cost application remain OPEN; no new
  forwards. A candidate theorem/finite oracle is not real-model utility.
  V2 prospective contract implements saved last-same-source cutoff: producer
  d0b6936,1,540 rational original-payload laws,10,220 tapes and12 balanced
  query/repetition examples PASS. Finite draw cap preserves both marginals
  and all-vector variance safety; no arbitrary wall-clock fallback claim.
- [ ] T6302: Only if distinction/use survives, freeze a competent full-cost
  dLLM/CFG application. A42 root boundary is too late and may not be reused
  as a cheap informative source; A41 negative stronger controls stand.
  Adverse primary reduction in43/work/primary-reduction-v3.md identifies the
  scalar statistic as a classical conditional-first-indicator estimator.
  Retained original-payload frontier question remains open; not article-ready.
  Internal V4 audit finds the SAME full retained/capped law and stronger
  noninteger/pointwise bound already in34. A43 is closed as an independent
  novelty candidate; oracles are revalidation. No new native campaign.

## M62 — Safe empirical resampling at every source budget

- [x] T6200: BEFORE prototype/outputs write42's eight criteria and explicit
  conditional known rejective law versus UNPROVED random-pool covariance.
  Preserve41's576 neural observations/stronger controls and B8 counterexample.
  No new model campaign justified; max-entropy/rejective mechanism is classical.
- [ ] T6201: Minimum adversarial population oracle and closest primary sources.
  Prove or refute the unconditional all-score step before implementing a
  sampler or starting another neural run. Exact/bit calibration cost charged.
  V1 numerical search16824 M<=20/count-budget cases with<=5 classes has no
  eigenvalue>1e-9; not proof. Primary SSP/two-phase/CP scopes in42/work/primary-v1.md.
  Registered producer3914311; frozen rerun and exploratory outputs retained.
  V2 conditional matching theorem for arbitrary even pool size is written via
  classical stable operators;38 independent matching enumerations/2213 finite
  spectral checks pass. Frozen producer57fc6e2. UNCONDITIONAL step remains OPEN.
  V3 exact B=6 joint formula has2658 rational checks. V4 closes the B=6
  unconditional theorem with analytic reduction plus explicitly computer-assisted
  38-family/104-minor and289 finite rational certificates; independent verifier
  checks two identities and all14,723 boundary population partitions. Producer
  5925eec; commands/hashes in42/work/evidence/origin-v4.json. All-B extension and
  scientific priority remain OPEN; not a model-use/publication gate.
  V5 ALL40 exact pool partitions: six laws differ from classic pivotal (one
  at B6), same atom frontier. ALL6 OLD banks: pivotal6 almost identical and
  lower bias variance in5/6; retained RSS wins all scalar scores. Registered
  producer9af03e0, zero new forwards. decision-v5 rejects campaign/promotion
  of this proxy; theory/priority/CFG application still OPEN.
  V6 explicitly switches to six IID original proposals WITH replacement.
  A PURE written square proof closes all-vector unconditional covariance for
  arbitrary class masses. Two symbolic identities/8256 weighted raw tapes
  pass; frozen producer a300a2e, origin-v6.json. Balanced six-query worst-
  direction frontier is sharp and shared by pivotal6; lower bound is for
  score-oblivious universal opaque-IID couplings, not mass-aware/CV policies.
  Chauvet/Ruiz-Gazen2016 and multivariate RSS were examined; priority is still
  OPEN, and the unavailable2026 antithetic manuscript cannot be ruled out.
  This is not a practical promotion/full-gradient/generation/EPIC gate.
  V7 exact C6/C4 obstruction preserved. A locally certified H6 correction
  dominates C4 but has a small multiclass gain; local-maximality proof bounds
  ALL such conditional PSD refinements. Prospective1/L blend fails:626
  numerical search cases followed by a negative EXACT rational minor/score.
  Frozen search125d017; no model calls, no promotion/benchmark victory.
  V8 anonymous six-pool family is REFUTED as uniformly safe:3842 numerical
  checks lead to an exact five-class verifier obstruction at t=1/6. The
  rare-class limit gives necessary t<=4/45. V9 screen37200 endpoints has no
  obstruction but is NOT proof. family-algebra-v9 reduces sufficiency to an
  explicit two-moment quadratic form with a centering constraint; OPEN.
  Frozen producers b7ee9e0/847cea3. Zero new neural calls/publication gate.
  V10 uses a DIFFERENT construction: explicit C4 conditional diagonals plus
  a min-capacity Laplacian correction. Pure proof gives all-vector domination
  of C4 for every B>=4, monotonicity in B, and a balanced optimal asymptotic
  contrast limit.145 independent pool laws,1053 weighted original tapes,
  five exact sampler laws and28 balanced sums pass; producer a5d2445.
  Fixed declared label count is required. Generic Dirichlet/U-statistic tools
  are classical; priority and meaningful complete-cost CFG use remain OPEN.
  At four balanced classes even its ideal limit improves C4's class-mean
  variance by only7/39; not a20% practical gate or dominance of pivotal/RSS.
- [ ] T6202: Only after theory/prior survives, select a useful operation and
  competent complete-cost controls. No publication or practical gate yet.
  V11 native source-boundary audit COMPLETE on ALL four OLD hash-ranked
  SVAMP inputs:32 sources,8 requested full continuations,343 NEW LLaDA/NF4
  forwards. All first-yield roots pending; reaching the root needs7--12
  additional forwards.6/8 full outputs valid executable JSON,2 incomplete
  retained. Diagnostic8-source/two-full ratios2.73--3.84 wall,2.87--3.84 CPU.
  Root feature is too late for the proposed cheap-source use; no coupling,
  semantic gold, independent confirmation or statistical speed win. Serial
  audit does NOT account a live pool's tensor memory/replay. Native source
  e631443, analysis5f515d7, evidence/origin-v11.json. Do NOT expand root proxy.

## M61 — Cheap structured noising and whole-gradient covariance order

- [x] T6100: BEFORE implementation/models specify41's eight criteria and
  score/gradient-source operation, full matrix covariance, stop-gradient
  adaptive-key condition, fixed-preconditioner and one-quadratic-step result.
  Scalar-to-matrix lift/conditional expectation are KNOWN; protagonist query
  frontier remains priority-open. Read actual MIRROR/P-POTS v2 closest sources.
  Same-example noise guarantee is NOT better than two different data examples.
- [ ] T6101: Adversarial reductions/proof/original noising-law audit; minimum
  independent masks/gradient counterexample oracle before a neural prototype.
  Do not apply A39 opacity bounds when class masses/inverses are cheap.
  V2: own dependencies/proof,67-partition complete matrix oracle and10-line
  exactly-two-evaluation adapter. Written ReLU/softmax MIRROR counterexample
  includes cheaper analytic zero-variance control; autodiff is a constructed
  CPU/CUDA toy, NOT an external model benchmark. Ranked-set sampling adds
  a direct classical imperfect-ranking objection. V3: full original-source
  law EQUALS class-first pivotal; ranked-set also has generic matrix guarantee.
  Separate raw/label model has written sharp FOUR-POOL lookup cost4-4c2+2c3,
  allowing unclassified outputs; NOT every-source-sampler lower bound.
  Three new oracles check67 partitions/joint laws/query counts/early-return
  completions, six own tests PASS. Isolated Lean checks finite obstruction
  only, kernel decide with no sorry/project axiom; whole written theorem,
  scientific priority and real-model cost benefit remain OPEN.
  V4: written all-source-budget atom frontier/Catalan increments,5556 exact
  triples checked. Preserve B=8 positive-covariance union: atom balance is
  NOT arbitrary-verifier/gradient safety. Eight own tests including v2/v3;
  LLaDA1.5/VRPO current v2 is a direct score-operation precedent. Time-independent
  count/Rao-Blackwell baseline must enter when admitted by the model. No real
  heads/noising/training/publication benefit confirmed.
  V5 prospective information contract/code uses strong known count-NELBO,
  ALL six OLD external documents,32 fit+64 new iid noise observations each,
  full OUTPUT-BIAS gradient only. Own pin/hash copies; cheap proxy fixed
  before evaluation. Known64-source-bank geometry is NOT an opaque-source
  competitive gate. No new external model outputs yet; preserve setup costs.
  V6: BEFORE first neural observation replace the finite seed map by a standard
  exact rational count/subset source with original aliases, connecting to the
  original time-independent normalized NELBO. Independent mask enumeration
  checks n=1..7 and n=64 boundary/alias cases. No source enumeration in use;
  polynomial bit cost is charged. Transparent count/alias controls admitted;
  opacity minima are not lower bounds on all mask-specific algorithms.
- [ ] T6102: Only if difference/cost plausibility survives, freeze real JSON/DSL
  noising-score protocol with competent MIRROR/time/importance/analytic/extra-iid
  controls and all costs. No experiments or improved training claimed yet.
- [x] T6103: Execute the prospective v6 MINIMUM information capture, ALL6 old
  documents,576 actual forwards,32 fit+64 fresh corruptions each. Preserve
  every row and full-bias Gram data, original source hashes, cost and scope.
  Independent offline pivotal enumeration reconstructs all covariances;
  source addresses and fixed proxy labels match. Retained-anchor RSS is a
  legitimate same-budget control, written in retained-rss-v7.md. Known-bank
  score RSS beats C4 in6/6; same-proxy CV beats C4 in5/6 and loses1/6.
  C4 bias trace reduction is only2.00--4.33% vs iid2, with32 paid setup
  forwards per document. NOT a practical or population gate; no training.
  T6102 is not justified by these limited signals; no larger campaign now.

## M60 — Independent retained anchor and cached native observations

- [x] T6000: BEFORE prototype/outputs specify40's eight criteria and written
  conditional three-output/terminal-verifier/variance/neural-work corollary.
  Fixed root/left-choice frontier, immutable paid anchor trace, strong dynamic
  cache and three-source-without-replacement controls mandatory. Conditioning
  and cache are KNOWN; A39 no-free-label minimax does NOT cover anchor information.
- [x] T6001: Minimal independent implementation; verify unchanged native
  generator/private RNG/model heads and stop before every uncached helper call.
  All old inputs/four predefined sources, original-ID regressions; no quality
  or performance gate from this information audit. Freeze source before outputs.
  V2 minimal isolated trace/key plus opt-in adapter; CPU/CUDA multi-step
  original-ID/status/RNG/head-clone and guarded-miss checks PASS (no neural model).
  Information audit is32 requests/8 old anchors,16 full regressions; first helper
  deliberately repeats anchor, so NOT a pass3/coupling experiment. No output yet.
  V3 capture complete32/32 OK,16 full-ID/status helper matches, eight anchors,
 120 new forwards, zero helper misses/forwards. Excluding anchor replay, only
  one of four inputs has varied key; traces642--894MiB and prefix cost0.103--3.128s.
  NOT a coupling/quality/competitive gate; decision/information-audit-v3 preserved.
- [ ] T6002: Specific prior/reduction audit, useful complete-cost consequence
  against competent dynamic-cache/native controls, independent proof and heldout
  evaluation if the development observation is informative. Goal remains open.

## M59 — Known source addresses, opaque labels and complete native costs

- [x] T5900: BEFORE prototype/forwards write39/README's eight criteria and
  finite-source theory/native-work corollary. Source indices/size are known;
  controls may choose them adaptively and clone first. Robust cap4 atom
  optimum is hypergeometric, cap3 cannot improve uniform seed derangement,
  and worst-placement lookup cost is sharp4-2c2+c3. NOT pointwise optimum
  for each map or infinite-domain minimax. Full-score covariance includes
  within-class WITHOUT-replacement correction; no incorrect iid Wald use.
  First native yield plus a common immutable head would give equal expected
  neural forwards and pass2 never worse than iid EPIC2, with ALL auxiliary
  sampling/parsing/copies/memory still charged. No native adapter/result yet.
- [ ] T5901: Independently check finite population joint laws, marginal seed
  preservation, all verifier scores, interpolation obligations, weighted
  prefix-omission/coarsening and strongest reductions. Include seed
  derangement counterexamples; preserve38 native losses. Specific priority
  and useful full-cost magnitude remain OPEN.
- [x] T5902: V2 minimal independent kernel/source with origin hash and five
  exact oracles:270 finite-source partitions, every Boolean raw verifier,
  arbitrary-score covariance, hypergeometric coefficient grid and60 sound
  coarsenings. Preserve seed-derangement, weighted-work and real-variance
  counterexamples. `39/work/evidence/law-v2.json`;164 full tests PASS70.995s,
  `make check` PASS. No native output/forward/timing or novelty confirmation.
- [x] T5903: BEFORE adapter/forwards freeze new first-yield native pilot:
  all input-ranked SVAMP5--8, two tapes, nine competent controls,72 rows;
  zero extra helper-forward assertion, private original continuations,
  seed-derangement/half/iid3/biased novelty and all cold/physical/memory costs.
  Golds only after closed capture. Fixed leftmost original commit key, no
  root-delay/filter/replay. `39/work/native-protocol-v3.md` and JSON/inputs.
- [x] T5904: Implement minimal native adapter after protocol freeze; validate
  suspension/one-scope completion/private randomness and unchanged first.
  Freeze producer before actual new outputs. Pilot is development, not
  independent statistical confirmation or publication novelty evidence.
  V4 live CPU/CUDA toy audit PASS with zero model forwards, first/final
  snapshots/private tapes/common-head clone/key boundaries checked; explicit
  Ruff PASS. Original task/controls copied by immutable35f4ea6 hash, no mutable
  A38 imports. `39/work/evidence/native-adapter-v4.json`. Runtime will count
  all helper queries, full selected continuations and allocated/reserved memory.
- [x] T5905: After complete producer/archive freeze run ALL72 fresh original
  native records under v3. Require zero-helper-forward and literal first
  full-ID invariants, preserve every failure/partial record. Golds only after
  closed capture; publish strongest-controls full-cost losses as well as gains.
  Producer52df9a1/archivec0b2fd6;1595 new forwards (incl4 initial heads),
 117 complete35 incomplete selected,0 errors. Literal first and every prefix's
  zero-helper-forward verified; original EOS-to-PAD suffix74 occurrences
  documented, not a false invariant of immutable intermediate tokens.
  Adaptive25 queries vs full32, pass2=3/8 vs iid2=4/8; medians5.155 vs5.041s,
  memory8.303 vs7.542GiB. Functional pilot only, no useful/general victory.
  `39/work/native-audit-v5.md`, generated JSON and usefulness-decision-v5.md.
- [x] T5906: Investigate whether the complete FIRST neural step has informative
  nonterminal observations before any new forward; fix a source/observation
  contract and compare competent controls BEFORE another capture. Current
  first-yield results remain unaltered; no answer-conditioned selection.
  V6 written contract3ce6789/archive98d835c BEFORE code/output. V7 minimal
  READ-ONLY frame boundary prototype; real CPU/CUDA no-grad-wrapper fast,
  fallback and immediate-failure toy cases pass with one simulated head,
  unchanged first/final IDs and private RNG. No actual model output yet.
  `39/work/evidence/stage-adapter-v7.json`. Fixed old-input/ALL-source
  functional/information audit is frozen before new native calls; its seed
  bank is development and is not an unbiased population-frequency estimate.
  Actual v7 audit FAILS at FIRST source: one extra forward, observer crosses
  i=0 because upstream resets loop variable j to batch-row0. Preserve error
  and metadata, `39/work/first-step-erratum-v8.md`; toy omitted that clobber.
  Correct proposal counts pinned successful-fallback yield sites, not j;
  requires new regression/producer freeze before another model call. Neither
  informative classes nor zero first-step-helper forwards are confirmed.
  V9 counts six pinned yield sites (AST/read-only native frame), successful
  fallback transfers, failure/terminal stop; no j use. Actual no-grad-wrapper
  CPU/CUDA regression includes j clobber and partial fast batch, PASS without
  model inference (`stage-adapter-v9.json`). Refuses changed native hash/sites;
  common-head setup/error costs preserved before frame completion. Requires
  new immutable producer and new evidence filename before native repeat.
  V10: corrected51/51 OK, zero helper forwards, eight full original-ID/status
  matches,88 new forwards including four common heads. Fixed key constant
  in ALL four inputs; 1/2/2/2 full-stage patterns. INFORMATION GATE NEGATIVE,
  not a latency/semantic test. Producer749e2eb; phase-info-v9 raw/metadatas
  and phase-info-audit-v10/first-step-decision-v10 preserved. Goal remains open.

## M58 — Empirical categorical coupling and pointwise cost optimum

- [x] T5800: Eight criteria, full-payload operation, explicit law/covariance,
  simultaneous cap4 atom optimality and stronger pointwise expected-cost
  theorem WRITTEN BEFORE code. `38/work/theory-v1.md` and
  `optimal-cost-v2.md`: v1 costs4-c; v2 has SAME joint law and reaches
  minimum4-2c+s3 among ALL p-blind universal cap4 atom maximizers with at
  least three ALLOWED keys. Known binary alphabets have cheaper controls.
  This is oracle work, NOT full decoder speed or unrestricted known-logit
  optimality. Half mixture guarantees D_opt/8 with mean3-c+s3/2<=3;
  stronger worst guarantee than37, not pointwise dominance.37 is preserved
  with a new pool-control objection, not retrospectively changed results.
- [ ] T5801: Independently audit the law, polynomial lower-bound obligations
  and strongest direct reductions. Neal1995 original4.1--4.2/conclusion,
  Andrieu2020 Example4/Remark6, Craiu bootstrap1--3/conclusion, Casarinv2
  Section1/Definitions1.1--1.3 and STMC2020 original1--3 ACTUALLY read.
  Hashes/scopes38/work/primary-comparison-v1.md. Rank/pool coupling and
  unnecessary-auxiliary skipping are known. Hall1989 is still ABSTRACT-only.
  Specific priority and useful magnitude remain open; no model campaign,
  human review, article promotion or publication confirmation.
- [x] T5802:29-line isolated reference and five independent exact oracles
  PASS0.056s, AFTER preimplementation freeze7ce0ff6/archive37ef646. Actual
  raw aliases/failures, complete marginals/cost, all32 raw verifiers and
  nonmonotone scores; a classical grouped-rank control has EXACTLY SAME
  joint law. Informed uniform derangement beats it on all verifiers without
  auxiliaries. Source-hashed38/work/evidence/law-v2.json;152-test full suite
  PASS68.353s, make check passes and explicit Ruff passes. No model data.
  `decoder-corollary-v2.md` connects ONE full accepted native transition to
  the final-answer guarantee with adaptive logits, retaining all hidden
  state/RNG. This is WRITTEN, not a new verified EPIC adapter or measured
  quality/latency win. `primary-comparison-v2.md` credits actual Dice
  Enterprise readings and informed all-score controls. Priority remains OPEN.
- [x] T5803: BEFORE budgeted code/model campaign, write the NEW minimax
  frontier `38/work/minimax-frontier-v3.md` and re-answer all eight criteria.
  Candidate theorem: mean budget b in[2,4], hardcap4, universal unknown law,
  literal first and full marginal preservation imply optimal uniform
  canonical-diversity fraction(b-2)/8. Includes adaptive stops and FIRST
  clones, not merely v2's nonfirst-index atom-maximizers. Countably unbounded
  allowed keys; explicit finite-M bound, no exact fixed-vocabulary claim.
  No new prototype, native adapter, model forwards, timings or priority
  confirmation yet. Proof distributions are NOT favorable neural benchmarks.
- [ ] T5804: Audit v3 stopping-time/symmetrization/Bernstein obligations,
  investigate the closest original lower bounds, then validate the minimal
  half-mixture law independently. Only after a plausible scientific/use gate
  freeze a full-cost native protocol; do not inherit closed A32/A34 losses.
- [x] T5805: After v3 source/archive, implement ONLY11 lines for the
  independent budget3 coin. Seven rational checks PASS0.091s with raw
  aliases/failures/all32 verifiers and EVERY conditional virtual-multiset
  marginal; `law-v4.json` hashes exact sources.154 full tests PASS69.932s;
  make check/explicit Ruff PASS (`checks-v4.json`). Full-cost corollary uses
  STANDARD finite Wald with payload-correlated costs; charges all original
  calls/statuses/copies and same pair continuation. Strict complete-work
  saving versus the known full/early pools, NOT measured physical speed.
  Huber2013/2015 lower-bound sections and Dice3.3--3.5.2 READ with original
  hashes/scopes in `primary-comparison-v3.md`. Specific priority and useful
  native application still open; no new model campaign or article promotion.
- [x] T5806: BEFORE native code/forwards freeze finite-domain corollary
  (gap<=11/(8M)), eight revised criteria and `native-protocol-v5.md/json`.
  Four FIRST input-only hashes of ALL1000 SVAMP at78e7276, frozen source,
  separate postcapture-only golds/license. Two seeds x seven competent
  methods=56 records; real COMPLETE calls, common head/preparation charged,
  iid2/biased novelty3/seed-half retained. Functional/cost PILOT only, no
  statistical primary gate, no model capture yet. No closed A32/A34 gate
  reopened or relative timing credited to a replay bank.
- [x] T5807: Minimal isolated native implementation, validate same-law
  controls and original RNG/IDs, freeze producer before running ALL56 pilot
  records. Report full costs/losses and decide application honestly before
  any larger campaign/article promotion.
  Preflight v6 NOW passes: nine rational controls/key checks0.121s,
  full156-test suite68.012s, check/Ruff and live CLI import. CPU/CUDA/Python/
  NumPy private-RNG oracle PASS without model forwards; immutable helper
  copies verified. `native-preflight-v6.md`, `law-v6.json`, `checks-v6.json`
  and `native-rng-cuda-v6.json`. Producer is to be frozen before ALL56 real
  records; no neural results/publication or broad EPIC win yet.
  COMPLETED after producer76f4bc1/archive0ce0347: ALL56 records,169 actual
  complete native calls,1885 new forwards, no ERROR, literal first IDs
  preserved.134 COMPLETE/35 INCOMPLETE calls all retained. Postcapture-only
  audit `native-audit-v7.md/json`: adaptive28 calls versus pool32/early30;
  all those methods and iid2 have observed pass2=2/8, seed_half3/8. Iid2
  is cheaper. This is NOT useful general superiority or statistical gate.
  Actual command/source/data hashes retained; golds read only after capture.
- [x] T5808: BEFORE refinement code/timings write `semantic-coarsening-v7.md`
  and eight criteria. For ANY original law, sound observer coarsening saves
  complete oracle calls and never reduces coverage for any observable Boolean
  verifier or best-score distribution. Preserves original raw marginals;
  counterexample blocks an all-real-score variance monotonicity claim.
  Need identical raw-text budgets for sound AST-to-observation factoring.
- [ ] T5809: Independently audit coarsening algebra and budget soundness,
  strongest predecessors and practical full-cost alternatives. No v6 timing
  relabelled, no artificial verifier cost, no independent/publication claim.
  V8 now supplies21-line observers and THREE exhaustive finite checks:
  all15 four-class partitions/all observable Boolean verifiers, original
  marginals/work, best-score thresholds, real-score counterexample and
  concrete raw-text/typed-AST/error boundaries.12 focused checks PASS0.279s;
  full159 PASS68.211s, make check/Ruff PASS. `law-v8.json` source hashes.
  Primary20-page Luo2025 slides READ, NOT the linked2026 manuscript;
  `primary-comparison-v8.md` keeps unavailable sources explicit. No new
  native timing, priority confirmation or full-use victory.

## M57 — Complete-output canonical coupling: written application gate

- [x] T5700: Eight criteria, complete-oracle operation and bound BEFORE code.
  Random balanced differences plus the barrier-three law give at least1/13
  of maximum preserved-marginal pass@2 gain for ANY single correct canonical
  outcome. Cap12 conservatively gives1023/13312. Sharpness is for THIS
  construction, not all couplers. `37/work/theory-v1.md`. FULL auxiliary
  generations are charged; iid3 ALWAYS has higher unique-event coverage at
  the same expected generation count. No quality/generation-budget victory.
  At success mass1/2 the ideal unbiased-evaluation cost bound requires v>5c
  before coordination; this ratio is not measured. Canonical duplicate labels
  must not be charged repeatedly. These objections are not waived by the proof.
- [ ] T5701: Independent small law/hash checks and strongest direct reductions.
  CARMS original3--3.2.2, authored RSS original1--4, diffusion-antithetic
  original1--3.2, GLIDE original2--4.4 and MCTS originalA.1--A.4 read.
  `37/work/primary-comparison-v1.md` records exact sources/hashes. Hashing,
  ruin, marginal preservation and expensive-label evaluation are known;
  specific novelty and useful full-cost consumer remain OPEN. No human
  review, neural campaign, article promotion or publication confirmation.
- [x] T5702: Minimal independent full-payload reference and four rational
  oracles PASS0.064s: aliases/failures, literal first, hash balance/lazy bits,
  full marginals, all verifiers, count-cap fallback and actual classical
  quantile control. `tests/test_canonical_outcome_coupling.py` and37/work/couple.py.
  Full147-test suite PASS67.788s before the last diversity assertion; the
  focused current tests pass after it. Ruff passes. New written corollary
  gives1/13 of maximum collision reduction for EVERY canonical distribution,
  not only a singled-out correct outcome; `diversity-corollary-v2.md`.
  Geometric2018 original1--2.3/cost passage, PAWS2013 original2--3.1,
  Craiu/Meng2005 original1--2.2/Theorems1/5--7 ACTUALLY read; sources/hashes
  in primary-comparison-v2.md. No model campaign or publication confirmation.
  `make check` PASS upstream/lint/types/integrity; source-hashed current
  oracle capture37/work/evidence/law-v2.json has four PASS0.062s, including
  cap12 fallback. This timestamp/source record is correctness, not a speed
  comparison or mathematical novelty certificate.

## M56 — Grammar-guided sparse output projection: prior gate

- [x] T5600: Preserve eight criteria and source comparison BEFORE any code.
  GPIO-LLM commit6b084650 (2026-09-19) already computes only grammar-allowed
  head rows; actual forward.c276--291/decode.c130--161 and original docs read.
  Conditional-product normalizers cancel for sampling, but remain necessary
  for original valid mass/native confidences. Reject simple mechanism as new
  protagonist, without a model/timing campaign. Sources36/README.md and
  work/primary-comparison-v1.md. No novelty, speed or EPIC victory asserted.

## M55 — Accepted-commit law versus a tractable LL(1) posterior

- [x] T5500: Eight criteria and explicit written #DNF reduction BEFORE code.
  Original-ID aliases enforce confidence ordering; greedy/MWPC accepted-tag
  probability counts a union, while the witnessed product posterior sums
  distinct words in polynomial work. This is a companion specialization,
  not a new model-counting principle or claimed native finite-CUDA theorem.
  Source35/work/theory-v1.md. Miklos Sections4.2.1/4.2.2 and Hazan/Jaakkola
  Sections3--5/7--8 originals read; exact union/perturbation precedents credited
  in35/work/primary-comparison-v1.md. Original Kannan/Ghosh still unread.
- [x] T5501: Attack confidence gaps, aliases, overlap/duplicate terms and the
  language/policy difference with a tiny independent enumeration. No timing
  or neural campaign on this proof family. The meaningful accepted-transition
  application and A34 specific priority remain separate open obligations.
  `tests/test_commitment_law_counting.py`: one small test PASS0.083s, five
  LL(1) grammars,528 flag-ranking transcripts,440 ALL-primary-optimum
  comparisons and five exact CORE posterior recomputations. Source-language
  expansion is independent of project normalization; expected unions are
  independently expanded from clauses. No model/timing/novelty evidence.
  Explicit Ruff check/format pass; entire suite140 tests PASS70.001s AFTER
  A32 timings and before any A34 native campaign (`make test`).

## M54 — Expected-work/diversity frontier (written candidate)

- [x] T5410: Written pointwise extension BEFORE code: bounded output and
  E_p0N finite suffice for differentiability AT p0; halted-leaf KL identity
  and Hellinger control the derivative of the tail, without E_tN nearby.
  A34 lower bound therefore needs only the fair-point budget, not uniform
  expected work. Sources34/work/pointwise-score-v12.md and
  primary-reading-v12.md. Nacu--Peres original Props22/23/Question3,
  HNP original Theorems8/13/Section7, Paes Leme authored2022 Section1.3 and
  Flegal--Herbei original Section3.1 read. This does NOT establish priority,
  solve their full moment/sufficiency questions, or validate a native use.
  No software/head/timing change; closed negative quality gates unchanged.
  Addendum34/work/uniform-curvature-v12.md bounds finite-approximation
  second derivatives by2C E_pN/[p(1-p)] and yields local C^{1,1} under the
  uniform budget. C1 alone is insufficient; no C2/general-moment/priority
  assertion. This obstruction is not the requested useful final product.
- [x] T5400: Eight criteria BEFORE implementation. Independent written proof
  of the lattice-refined minimax fraction of Fréchet improvement under a
  worst expected TOTAL oracle budget. The comparator class is ALL p-blind
  regular factories, not selected implementations. Classical ruin/score
  arguments credited; source:34/work/theory-v1.md. No code/neural result.
- [ ] T5401: Check nearest sequential-estimation and Bernoulli-factory primary
  results, particularly Wasan1964/Ghosh1987; resolve specific priority and
  relevance before expanding. DeGroot ORIGINAL Sections1--8 and key printed
  formulas84/91 are now read; score/variance principles explicitly precede us.
  Wasan ORIGINAL13 pages now read; Section2.1 already gives s_b via randomized
  adjacent fixed sample sizes. Frontier SHARPNESS for the restricted pair
  output, not that formula/mixing, is the candidate distinction. An apparent
  erroneous strictness clause is separately audited, not a publication claim.
  Wu/Wasan1991 original and Ghosh/Purkayastha2010 authored review read; original
  Ghosh1987 remains unavailable.34/work/primary-reading-v3.md.
  Absence from search is not proof of novelty. Four independent law tests pass.
- [ ] T5402: Establish a cheap useful native structured transition application,
  compare probability-aware coupling and more-output iid with COMPLETE costs.
  Do not promote a restricted-oracle theorem alone as fulfilled publication goal.
  Written34/work/full-cost-v3.md proves a same-EXPECTED-budget comparison with
  ALL nonadaptive iid output counts, and preserves contrary complete-oracle
  and adaptive verified-retry cases. Class signal and cheap-prefix conditions
  are NOT asserted as measured model properties.
- [x] T5403: Written deterministic-count cap preserves the original second
  payload on truncation, with a uniform spectral loss certificate. Tiny
  sampler and four independent tests PASS0.159s AFTER A32 timings completed.
  Entire139-test suite passes67.511s (`make test`); Ruff passes. `34/work/bounded-runtime-v2.md`, `ruin.py`
  and `tests/test_oracle_diversity_frontier.py`. Wasan1964's original abstract
  adds a close noninteger sequential-budget predecessor; full text pending.
- [ ] T5404: Minimal native FIRST-EVENT payload prototype, before any neural
  campaign. Eight criteria34/work/native-contract-v4.md. Initial FAKE draft
  refuses cpu/seed0/T0/rejection-budget1 because it compared wall timestamps
  as decisions; IDs/rejected positions/status agree. Source/failure preserved
  in34/work/evidence/native-draft-failure-v4.json and native-draft-audit-v4.md.
  Audit actual wall limits and separate diagnostic times BEFORE refining.
  Correction projects only diagnostic elapsed times away from comparison,
  retaining actual upstream timestamps in the original payload.36/36 CPU/
  CUDA FAKE first full decision trajectories and all caller streams PASS,
  54 fake head forwards.34/work/evidence/native-fake-v5.json; source draft
  remains independent in v4. No regular-cover SUCCESS-path coverage yet
  (fixture transfers one token per step); no neural benefit claimed.
  Stronger144-case replay also passes decisions, but COVERAGE gate refuses:
  one-digit grammar cannot accept min-batch2. All rows/observer/source hashes
  are preserved in34/work/evidence/native-cover-fixture-refusal-v6.json.
  Extend ONLY the independent fake grammar to exercise a genuine positive
  batch. Do not simulate that branch or call a flag activation coverage.
- [x] T5405: Written exact r3 finite-cap law/cost and parity dominance BEFORE
  its added oracle. n12 guarantees341/1024 of maximal binary improvement,
 1023/1024 of the expected-budget3 frontier, expected draws<=3. Odd cap has
  identical full output law but higher call count. Not hardware/quality/novelty
  evidence.34/work/barrier-three-cap-v6.md; added16,380 input transcripts and
 102 rational polynomial determinations PASS; all five A34 tests0.183s/Ruff.
- [x] T5406: Shared native grammar preparation workaround, vendor UNCHANGED.
  Two-digit batch fixture revealed nested OnceCell initialization deadlock;
  source/trace preserved BEFORE fixing. Calling to_normal_form twice primes
  the same flag in ALL methods.144/144 CPU/CUDA first-path decision and RNG
  replays pass,132 genuine batch-helper successes/289 calls,198 FAKE forwards.
  `34/work/evidence/native-fake-v8.json`; v7 preserves hanging draft. No
  neural/timing claim. Arithmetic interpreter exact rationals/untrusted-number
  budgets have one meaningful focused test; whole142 suite PASS68.228s.
- [x] T5407: Frozen eight-input/32-prefix resource diagnostic before A34 heads.
  `34/work/arithmetic-protocol-v7.md/json`, independent input-only question
  copies and native suspended-prefix producer. No gold/accuracy evaluation;
  grammar accepts unrestricted recursive arithmetic JSON programs. Root
  boundary may require multiple charged forwards. Common initial-head cache
  is not a competitive full-cache baseline. Positive resource screen only
  licenses quality development; does not fulfill utility/publication goal.
  EXECUTED source fe3fa65:8/8 rows,256 native prefixes,1.845 NEW forwards,
  zero producer errors,6/8 first tails executable.0/8 resource screens pass:
  cheap classes degenerate; nontrivial ones late. Raw/metadata/decision/hashes
  in34/work/evidence/arithmetic-root-diagnostic-v7. Larger ROOT-operator
  quality branch is NOT triggered; no gold/EPIC win/novelty claim.
- [x] T5408: Freeze and execute FIRST-NEW-NUMBER resource diagnostic on ALL
  same eight input-only questions,32 new seeds, unchanged resource gate.
  `34/work/arithmetic-protocol-v8.md/json`, pure original-ID checkpoint helper.
  One additional independent test covers fixed/old slots, aliases, special
  IDs and ASCII-only digit semantics. Seven A34/application tests PASS0.178s;
  this is correction evidence, not semantic benefit. V9 preserves complete
  negative root source fe3fa65/evidence1449ca6 before modifying the producer.
  No golds/new heads V8 before this freeze; parity could have zero useful signal.
  EXECUTED f7114ac:8/8 rows,256 native prefixes,2.330 new forwards; zero
  producer errors,5/8 first tails executable.1/8 resource screens versus
  preregistered minimum2; quality branch NOT triggered. Raw/metadata/decision/
  hashes in34/work/evidence/arithmetic-number-diagnostic-v8. No golds/quality/
  independent confirmation. Jafari Jozani/Perron2011 original Sections1--4
  now read: cheap ranking/expensive measurement are already the prior use.
  Their fixed-four-pool law is z²; competent early-stop control costs3-z,
  less than R3's3. Specific frontier/application obligations remain open.
- [x] T5409: Written score extension BEFORE more implementation: bounded
  terminal outputs plus locally UNIFORM expected N suffice, without an
  exponential moment or second moment of N. Finite-transcript approximations
  have uniform errors C*b_I/m and C*b_I/sqrt(m*p*q). This broadens the same
  A34 frontier to ALL p-blind uniformly budgeted factories. Written equality
  characterization shows retained-first integer-optimal r>=3 has the unique
  ruin stopping law and unbounded support; no finite hard cap attains that
  frontier. Sources34/work/uniform-budget-score-v11.md and
  optimal-stopping-uniqueness-v11.md; not Lean/software/human review. Mendo
  original Theorem3/Section7.5 fastness restriction read; Simons original
  abstract read, institutional full text blocked/unread. Regularity may be a
  known consequence; specific priority/application remain OPEN. V10 preserves
  negative number source f7114ac/evidence284610d. No new model capture here.
  Validation AFTER the two timing campaigns: `git diff --check` PASS,
  `make check` PASS upstream/lint/format/types58 files and35 attempts/99
  versions; `make test` PASS143 tests68.254s. These checks do not verify
  the new analytic proof, originality, publication or native benefit.

## M53 — Categorical race repair: reduction gate before implementation

- [x] T5300: Eight criteria and independent written law/cost/path proof.
  Exact reduction found BEFORE implementation: A29 stationary collision
  transform plus classical Barker two-coin race. Do not expand as protagonist
  or start neural campaign; preserve33 as a written competent comparator.
- [x] T5301: Correct historical A29 rare-event comparison separately. Fréchet
  bounds ANY preserved-marginal pair's rare-event gain by epsilon², not just
  collision repair; the claimed direct epsilon(1-epsilon) advantage was
  impossible. A29 MH obtains1-epsilon of the optimum in that binary case.
  Original frozen proof preserved;29/work/erratum-2026-10-11.md and explicit
  addenda prevent reusing the wrong objection. No publication claim follows.

## M52 — Native sampler oracle coupling: sharp bounded information gate

- [x] T5200: Eight criteria BEFORE reference. Written sharp B_n(p) bound
  for p-blind class-bit access with first bit retained, n<=3 cannot improve,
  n=4 adaptive operation attains it. Unknown native finite-law probabilities
  are not replaced by ideal PL. Bernstein/Barker/Dirichlet are antecedents;
  specific priority and publication adequacy remain OPEN.
- [x] T5201: Four independent small-law/class/event/score and729 adaptive
  kernel-sequence oracles pass0.766s. Native FAKE probe216/216 literal first
  trajectories and CPU/CUDA RNG isolation,156 shared nodes128 auxiliary row
  draws978 fake calls. Source/producer hashes:32/work/evidence/native-fake-v1.
  Implicit CUDA device-index draft failure preserved independently, not
  relabeled. No new neural forward or competitive timing for32.
  Whole offline suite127 tests passes65.861s; explicit new-file Ruff passes.
- [ ] T5202: Resolve nearest oracle/antithetic antecedents, independently
  review proof obligations and freeze competent full-cost external protocol
  BEFORE neural heads. Include known-probability alternatives with exactness
  delimitations, iid4 and root/history controls, every status/case.
- [ ] T5203: Real complete-neural development and only passing independent
  confirmation; meaningful quality/cost advantage and defensible originality.
  Do not equate a sharp restricted-oracle theorem or fake replay to this gate.
- [x] T5204: V2 bounded streaming generalization and competent compact pool;
  six independent oracles1.650s,133-test suite67.804s.432/432 FAKE first-path
  replays,312 shared nodes1024 auxiliary draws1956 fake calls. Adverse local
  coupling/terminal-coverage example blocks global monotonicity. All evidence
  under32/work/evidence; no neural or competitive result.
- [x] T5205: Primary Nacu–Peres2005 Section6/Proposition24 is an EXACT
  construction antecedent (B_n=Q_n-p); do not claim walk/Bernstein invention.
  Written v3 strengthens to minimax expected work d=floor(n/2)+1 among ALL
  adaptive p-blind n-bounded factories attaining B_n for all p. Priority still
  OPEN.54 finite stopping-tree optimizations,36 exact dual certificates,
 18 inconclusive rational reconstructions, zero numerical counterexamples.
  `uv run --no-project --python 3.11 --with scipy==1.16.3 --with numpy==2.4.6
  python -m attempts.32-native-oracle-antithetics.work.stopping_tree_lp
  --output .cache/a32-stopping-tree-v3/results.json --max-budget 10`.
  No claim of pointwise expected optimality for arbitrary n/p or publication.
- [x] T5206: V4 external numerical JSON operation and8 criteria before heads.
  Official GSM8K questions selected by input-only hash:32 train/64 test,
  unrestricted number grammar. Frozen16-method complete-EPIC protocol includes
  iid4, mixed/deterministic, raw finite-ticket controls, compact AND batched
  same-law pools and approximate-known-p maximum coupling.864 FAKE first-path
  /RNG checks pass,588 meetings4916 extra draws3900 fake calls.32 full-wrapper
  configurations/68 FAKE responses pass.135-test offline suite68.297s.
  At that freeze, no real A32 forward or semantic gain yet. Source8fc0999
  and push preceded train gold evaluation; archivev3/abdf242 is independent.
- [x] T5207: Frozen pilot COMPLETE1056/1056 records,2208 valid JSON outputs,
  32,716 NEW forwards, zero errors/refusals/first-trajectory mismatches.
  Producer8fc0999736724b7b28159653503693f95b272c4a; no heavy parallel timings.
  Independent exact verifier and output I/O costs included by post-analysis.
  ALL8 candidate configs cover20/32, TIE iid2 and cost MORE; mixed21/32 costs
  less, iid4 covers23/32 at0.5. Frozen negative resource screen triggers: no
  remaining development seeds or test labels opened. This one seed is not
  statistical refutation. ALL rows/IO/metadata/gold subset/audit/source hashes
  preserved in32/work/evidence/external-pilot-v4. No utility/novelty confirmed.
- [x] T5208: Separate written v5 cost objection during v4 measurements.
  Fixed-target minimax extends beyond bounded stopping, but an ordinary race
  beats n6 walk's class flow at the same worst expected4 draws. Not a new
  v4 method or relabeling; before ANY positive claim include the stronger
  comparator in a dated follow-up. No useful advantage confirmed by the note.

## M51 — Sufficient-state coupling: comparative theorem before neural work

- [x] T5100: Eight criteria and primary antithetic/Markov/stratification sources;
  written finite-state covariance identity, all-K mean variance<=history,
  K=2 coverage>=history, coverage>=iid and exact retry-verification corollary.
  No pass@K>=history claim for K>2, no new-classical-principle claim.
- [x] T5101: Four independent exhaustive RNG oracles pass; all binary kernels,
  nonmonotone three-state laws, auxiliaries, all small terminal properties,
  exact meeting energies, asynchronous pair projectivity and unsafe canvas
  counterexample. Whole suite118 pass65.916s; explicit Ruff check/format pass.
- [x] T5102: Audited native state includes per-label query ordinal, canvas,
  phase, agenda, generated words/EOS, rejection COUNT and immutable policy.
  Historical rejected positions remain diagnostics outside final-score scope.
  Three modes:216 literal fake-head replays equal,60 complete156 incomplete,
 648 fake calls. No neural forwards or competitive timing. Producer:
 31/work/probe_native.py; JSON+SHA under work/evidence/native-correctness-v1.json.
  Pre-ordinal code+216 rows independently preserved, not relabeled.
- [x] T5103: V1 frozen at064532f/archive51c17bd. Conditional anchoring v2
  has exact finite lifting proof; three independent oracles pass0.044s and
  whole suite121 pass64.878s.216/216 first native trajectories at K=2 are
  literal matches (fake heads),978 total calls,168/432 complete candidates,
 156 shared nodes. Sources/SHAs:work/evidence/native-anchor-v2.json.
  Conditional resampling is cited as antecedent, not invented.
- [x] T5104: Freeze external schema-only structured-argument protocol before
  new neural forwards: competent root-only/history/native iid controls, all
  statuses, first output preservation, full cost/cache, independent holdout.
  Input/protocol commit4038857; native runner0a27a24. All658 inputs audited
  before gold retrieval;16 development/64 independent inputs selected by hash.
- [ ] T5105: Execute development and only a passing candidate confirmation;
  assess genuine incremental novelty and practical magnitude, not weak
  dominance alone. No publication suitability or EPIC victory yet.
  One-seed pilot COMPLETE272 records/528 trajectories/11,615 NEW LLaDA forwards.
 528 valid JSONs;192 literal first-trajectory comparisons have no mismatch
  in IDs/output/status/rejections/recovery/query counts.20 extra meetings.
  All four configurations TIE iid/root/history in pass@2:15/16 at0.5 and
 16/16 at1. Deterministic15/16. Full four-seed development and independent
  confirmation NOT executed, NOT refuted by this one seed. Diagnostic timing
  overlaps make check briefly; not clean latency evidence. Raw rows/producer
  hashes/audit under31/work/evidence/external-pilot-v3. Whole offline suite123
  passes66.444s. A distinct black-box class repair is being investigated
  before spending further neural compute.

## M50 — Lazy native stratification: mathematical and integration gates

- [x] T5000: Eight criteria, written fixed-K partial-subset/Maclaurin and
  full-history trajectory proofs; source audit of STMC/Array-RQMC, arithmetic,
  DAST and dependent rounding. No classical negative-dependence novelty claim.
- [x] T5001: Isolated sparse deferred-permutation ledger; five independent
  exact-RNG oracles pass15.980s, including asynchronous changed kernels, all
  small verifiers, IEEE grid transforms and parity shortcut counterexample.
  Whole offline suite114 tests pass56.494s (`make test`).
- [x] T5002: Native hook reads full control checkpoints; model inputs alone
  miss cumulative resampling budget.72/72 literal native replays pass, CPU/
  CUDA, first/entropy coordinates, temperatures0/0.5/1, max_resamples1/8,
  EOS and original aliases0/3.20 complete,52 native incomplete; all72 exercise
  rejection.216 FAKE-head calls total, zero neural forwards/timing claims.
  Producer `work.probe_native --output work/evidence/native-correctness-v1.json`.
  Source hashes/profile are explicit; native/vendor files unchanged.
- [ ] T5003: Before neural runs, freeze external semantic structured-generation
  protocol with literal complete EPIC iid, deterministic/native alternatives,
  equivalent caching/budgets, all statuses and total cost. Core criterion:
  useful semantic coverage and cost, not a toy event or merely weak dominance.
  Include the competent ROOT-ONLY native stratum control; examine sufficient
  Markov-state coalescence as a separate preserved contract before more runs.
- [ ] T5004: Execute development, then only a passing preregistered candidate
  gets fresh independent confirmation. Novelty/publication adequacy still open.

## M49 — Stationary collision coupling: theory-first adverse audit

- [x] T4900: Delimit eight criteria, confer primary antithetic/Neal/CARMS,
  arithmetic/STMC/No-Free-Lunch antecedents. Written stationary collision law
  preserves heterogeneous P/Q, dominates iid pass@2 for every verifier;
  normalizer-free MH reference requires at most one extra P proposal.
  Classical Dirichlet/MH principles are not claimed as discoveries.
- [x] T4901: Five independent all-ticket oracles pass0.553s;361 paired
  distributions,2888 verifiers,9747 rational scores; original JSON aliases,
  bad-weight/lazy behavior, wrong naive reroll and different-future counterexample.
  Tiny reference is isolated; no new model forward or timing experiment.
  Whole offline suite:109 tests pass39.529s; `make check` passes75 archives.
- [x] T4902: Derive an upper bound for EVERY collision-only stationary repair:
  gain<=min(d(E),D-d(E)). Rare binary outcome epsilon gives at most epsilon²,
  for ANY pair of the same marginals (historical claimed linear comparator
  corrected by T5301; frozen original preserved). Do not enlarge
  this branch or report publication success from its iid dominance alone.
  Novelty and a sufficiently useful main contribution remain open.

## M48 — Streamed neural/grammar boundary: a new bounded research gate

- [x] T4800: A28 has eight criteria, written original-ID joint law and bit-memory
  analysis; FlashSampling/STATIC/grouped sampling explicitly credited. Simple
  sparse-head novelty rejected before implementation; latent-gradient direction
  meets LUBAC/conditional-diffusion priors and an unresolved Jacobian cost.
- [x] T4801: Minimal independent class ledger retains masses/reservoir winners,
  not original weight rows. Three oracles pass0.012s, including every random
  decision for uniform and nonuniform original-event laws, independent JSON
  class constancy/mass, aliases/macros/partial strings/fixed slots and refusals.
  Single-use summary enforced; no numerical GPU exactness or speed claim.
  Full current suite:101 tests pass38.917s; explicit new-file Ruff passes.
  `make check` passes (27/72 frozen archives; A28 not archived yet).
- [x] T4802: Freeze source then execute declared same-public-head replay:
  all50258 IDs, eight NEW ledgers, full mass recomputation, independent JSON
  and fixed IDs. Input probabilities already materialized; no memory benchmark.
  Producer5ebb2ec:8/8 valid JSONs/fixed IDs,29488 exact class checks, full
  recomputed valid mass agrees. Evidence:28/work/evidence/public-head-v1.json.
- [ ] T4803: Before a GPU implementation/campaign, delimit the added benefit
  beyond generic grouping and frozen streaming controls. Full pipeline cost,
  original finite numeric law and direct strong controls are required.
  Sufficient publication novelty remains unconfirmed.
  V2 addendum predates kernels; NumPy/PyTorch integer controls included.
  Two CPU sum oracles plus full block sampler law pass. GPU correctness
  audit is frozen before execution; competitive timings still prohibited
  until a separate all-cost protocol is defined.
  Producer564e68b:52/52 GPU checks pass (40 positive/12 refused),39924
  block comparisons against independent Fraction. Entire104-test suite
  passes39.501s. Evidence:28/work/evidence/gpu-correctness-v2.json.
- [x] T4804: Freeze then execute SAME public head through all THREE block
  interfaces (NumPy/Triton/PyTorch), eight fresh posterior samples per method,
  full class probability and mass comparison, original/fixed IDs and JSON.
  No timing, new head or independent confirmation implied.
  Producer32b46b2:24/24 valid;2328 exact class checks/full mass; all eight
  paired original-ID outputs identical. GPU transfer53040 versus1608256
  bytes full weights, not a timing or additional gain over GPU Torch.
- [x] T4805: Freeze protocol-v3 then measure ALL486 numeric-interface rows,
  common full JSON structural plan, strong NumPy/Torch controls/all block sizes,
  frame/setup/JIT/retrieval costs. Preserve losses. FactorDLM Proposition2
  explicitly rules out quotient law novelty; SIMPLE/SPAA/ExBLAS are priors.
  Before any timing, protocol strengthened to NEW paired CUDA forwards/GPU
  softmax, same represented weights for all methods, actual additive step
  cost. Full traces local/hash pinned; no whole-trajectory/independent claim.
  Producer1b1773f:486/486,351 complete135 shared refusals0 errors,53 NEW
  forwards (52 contextual/1 warmup). All candidates0/18 primary gates.
  Triton1024 has13/18 boundary and4/18 prepared-query gains;5126/18 boundary,
  no total victory. Source/config/results/audit preserved; independent phase
  NOT triggered. This does not fulfill scientific publication goal.

## M47 — Finite-dimensional closure: research gate, not a publication claim

- [x] T4700: Read current EPIC v2, FactorDLM and Twister formulations and
  inspect the retained native EPIC batch code. Ordinary cache/batch splitting,
  weighted inference and trajectory correction are prior art. Ambiguity-based
  multiplicity rejection was reduced to a2001 antecedent before implementation.
  Sources and decisions are in A27/work/antecedents-v1.md.
- [x] T4701: A27 has eight questions and written original-ID residue/potential
  closure bounds, with normalization, macro-token peak, costs and limitations.
  Four independent tiny JSON oracles pass0.025s, including exact fixture bounds,
  aliases, invalid prefixes, partial strings, fixed slots and zero budget.
  These are consequences of classical abstractions, not confirmed priority.
  `make check` passes and the complete98-test suite passes38.918s. No Rust,
  maintained solver, historical scientific result or formal source changed.
- [x] T4702-v1: Freeze the diagnostic source before running the declared public
  full-V replay at ALL depths/moduli/potentials. No new forwards or timing gate.
  Producer61e7b11 completes40 sound bounds. Depth0 has zero shallow mass;
  depths1/2/4 already have an empty deep frontier, and ALL controls give zero.
  Preserve this non-use result; it establishes no preparation advantage.
- [x] T4702-v2: Frozen addendum uses ALL18 previously measured development
  states, all six A24 diagnostic depths and all ten finite variants:1080
  outcomes expected. Check against archived full mass when available, retain
  every refusal and zero lower mass. All1080 retained:730 complete,320 zero
  lower mass,30 preparation refusals;1050 archived exact-mass checks pass.
  Residue16 needs the SAME minimum depth as handoff in18/18; potential grid
  same17/18, worse1/18. No tighter bounds in73 shared conclusive pairs.
  Reproducer/audit in A27/work; no timings or independent capture.
- [ ] T4703: Only after a distinctive benefit argument, freeze an equivalent-
  operation comparison including compact CFG, counter+CARS and finite regular
  controls. A25 losses remain intact. Do not execute another large campaign
  merely to obtain favorable evidence; novelty/significance remain unresolved.
  A27 is not promoted: close antecedents and direct derivation currently
  prevent a defensible originality claim. This conditional campaign is not
  automatically required while its distinct-benefit gate remains unsatisfied.

## M46 — General batch dominance, keeping individual decoder laws

- [x] T4600: A26 has eight criteria and a written finite-horizon proof:
  identical-history proportional stratification preserves each trajectory,
  dominates iid pass@K for every verifier and reduces all-score mean variance.
  `attempts/26-stratified-decoder-batches/work/theory.md` includes bit costs,
  caching/latency boundaries and systematic/coordinate-wise counterexamples.
  Classical stratification, arithmetic sampling, STMC/SMG and weighted CFG
  unranking are credited in `work/antecedents.md`; no priority/publication claim.
  Prefix-ticket events attain min(1,Kp), optimal among all batches preserving
  these individual marginals, strictly above iid for K>1 and0<p<1; not every
  semantic event or the archived source-ID event satisfies the prefix premise.
- [x] T4601: Seven focused oracles pass:90 small ticket maps/batch configurations,
  36 adaptive two-step kernels, every terminal verifier and PSD covariance
  differences, independent JSON/alias/fixed/prefix/macro-token unranking,
  full-V stack bridge and complete public-head recomputation/source-event mass.
  `make check-formal LAKE=/home/jota/.elan/bin/lake` passes five additional
  ticket/two-stratum specifications. Whole-trajectory/all-K proofs remain
  written, not mechanized Python or neural implementation verification.
- [x] T4602-v1: First public archived MDLM head on top16 ordinary tokens
  has zero valid mass. Preserved in `work/evidence/replay-v1.json`; no hidden
  support expansion or source-ID insertion. This is a replay, not new forwards.
- [x] T4602-v2: Source6a69638 frozen before replay-full-v2.json. Same public
  head,50258 original IDs,64/64 valid replay candidates and fixed IDs preserved.
  Frozen classical stack reference bridged without pruning:44 retained states,
  53 edges,441-bit root. The source-ID event has strictly better exact pass@K
  for2/8/32; K=2 improvement is only0.010407 percentage points. No new forwards,
  semantic/latency benchmark or independent capture. Top16 failure retained.
- [x] T4603: Predeclared replay source6a69638 and consolidation49504ea
  preserve producer hashes, all outcomes and verification-v2 logs. Full project
  gate passed with93 tests, then the final entire94-test suite passed after
  adding real-head recomputation. Rust, lint/types, formal gate and unchanged
  3683-file scientific inventory pass. Article appendix compiles at15 pages,
  all-page/changed-page visual review done. Two independent A26 snapshots;
  original negative v1 unchanged. Regular upstream pushes; no force/history
  rewrite. Novelty/publication significance, industrial semantic evaluation
  and iterative neural A26 remain explicitly unconfirmed, not completed tasks.

## M42 — Full original-vocabulary posterior, without discarded topK mass

- [x] T4200: Define attempt22 independently, eight scientific criteria,
  original-token law and written inside/outside/sampling proof. Explicitly
  credit known lexical/semiring/quotient principles; no priority claim.
  Four offline original-token enumeration/law/reuse tests pass; sparse fixed
  deltas, aliases, partial UTF8, overlapping incoming states and remasking.
- [x] T4201-v3: Original full-vocabulary development completed270/270 records,
  208 complete/62 refusals,6/18 strong gains (5 speed,1 capacity), no sampling
  advantage against rejection. Original refinement completed540/540 records,
  387 complete/153 refusals,7/36 strong gains and6 sampling benefits. All exact
  outputs agree; new audit verifies288 additional full-matrix equalities.
  These are preliminary controls, not final adoption/novelty confirmation.
- [x] T4202-v4-partial: Preserve the entire fresh50/810 campaign interrupted
  to strengthen controls with lexical coaccessibility from the right suffix.
  Six documents have already received forwards: never call them unmodeled again.
  Data in work/evidence/{heldout-v4,fresh-v4-partial}; producing ee84ca2.
- [x] T4203-v5: Verify common bidirectional trimming and effective per-position
  quotient, then freeze code/protocol before all development timings.
  All original raw/global/position/local variants remain; all four trimmed
  variants receive the same structural pass. Ten methods including predictive-stack inference and rejection.
  Select local or bidir_local ONLY on development strong-win count against all
  seven controls (six partitions and independent predictive stacks); tie prefers bidir_local. Zero wins rejects both.
  Same20% median total wall AND CPU/sign-every-repeat,3GiB virtual/120s internal
  whole operation/150s hard guard. Hard-supervisor-only failures do not prove
  inference capacity. Tiny independent product/law/reuse oracles pass for8
  variants before timing; strengthened full-vocabulary oracle passes192 exact agreements over24
  single-hole frames and1,206,192 independently recognized original candidates.
  This is correctness evidence, not a performance/novelty claim.
- [ ] T4204-v5: If strengthened development passes, freeze selected method
  before independent forwards. Recompute all18 reused refinement documents and
  all5 eligible positive JSONTestSuite documents at pinned1ef36fa,16..96 GPT2
  tokens, original bytes, objects/arrays; no case excluded by outcome. Nine
  independent rotations; retained losing candidate is an ablation. Original
  fresh6 are now refinements. No training/semantic/native EPIC/world priority
  claim. Optional small full-head packet chosen as first independent case
 149c0c8c-4 BEFORE performance/model observations.


## M44 — Certified depth approximation (mathematical candidate)

- [x] T4400: Independent attempt24, eight criteria before any implementation.
  Written exact conditioning-TV identity, deterministic lexer-counter upper
  tail and dominance over hit-only bound, cost in physical tokens/bits, and
  common-policy trajectory coupling. Credit classical regular approximation,
  weighted storage/semiring and kernel perturbation principles. Denkinger2017
  and Diffinity2026 inspected; originality/utility not confirmed.
- [x] T4401: Minimal independent counter and bounded-depth reference, exhaustive
  original-event oracle including intra-token depth and normalized rare validity.
  Seek counterexamples BEFORE further implementation/performance. No new
  independent forward until adequate proof/protocol/development gate.
  Six original-ID tests pass; make test71 passed36.154s. Frozen diagnostic7ff7be9
  completed108/108 development queries (76 positive lower masses,32 zero),
  closed bound certifies <=0.001 for all18 configurations at some declared d.
  This is NOT a timing/novelty result. Preserve work/evidence/feasibility-v1.
- [x] T4402: Implement grammar-valid first-overflow and weighted counter
  continuation; written dominance/strictness with original-token partition.
  Fixed-tokenizer JSON theorem separates constant-depth certification from
  first-passage depth linear in n, including bit costs and precise boundaries
  versus compact CFG algorithms. Nine tiny independent tests pass;168 full-V
  comparisons over24 one-hole frames and1,206,192 original choices pass.
  Handoff feasibility producer f8ad7b9 completes108/108 queries; certifies
  smaller depth in7/18 versus grammar-hit,6/18 versus closed counter. This is
  NOT a competitive timing result. No independent model capture yet.
  `make test`74 passed36.310s; `make check` passes upstream/lint/types and
  integrity24 attempts/59 versions; protected scientific files3683 unchanged.
- [x] T4403: Freeze adaptive source and protocol before9-method development
  campaign486 records. All six mandatory controls, including compact full
  CFG kernels and strong first-overflow, must pass the unchanged20% paired
  total wall AND CPU/sign-every-repeat gate. Preserve every refusal/error/loss;
  select handoff or closed ONLY here, tie handoff; zero wins rejects the gate.
  Audit L<=Z<=L+U and actual TV whenever exact controls finish, and full matrices
  across exact controls. Cold cost and rejection first-sample cost separate.
  COMPLETE486/486,445 complete41 localized refusals,216 certificate checks,
  producer b2dcd2e. Both candidates pass3/18 strong cases and all three retain
  cold benefit. Select handoff by frozen tie rule BEFORE independent capture.
  Sampling benefit2/18 only; NO handoff>=20% refinement gain versus closed.
  All rows/decisions/provenance/matrix inventory in24/work/evidence/development-v1.
- [x] T4404: After development gate, freeze selection and capture ALL five
  unmodeled JSONTestSuite positive documents at pinned1ef36fa, original bytes,
  with4/8/16 masks and nine rotated repetitions. No result-based filtering.
  COMPLETE1215/1215 records,1071 complete144 resource refusals,540 checks
  against full exact mass; producer510d807. Handoff and closed each pass3/15
  query cases (8d5fc991-16,c87bca6a-16,d829cdbc-16). The gate uses paired
  median wall AND CPU reduction>=20%, favorable sign in every completed
  repetition and all six mandatory controls; NOT20% on every repetition.
  Approximate first-sample benefit2/15; no whole-generation speed claim.
  All rows, original external files/license, captures, matrix inventory and
  decisions retained in24/work/evidence/independent-v1. Optional public
  first-full-head-v2 packet permits bit-equal CPU-softmax reproduction without
  model weights; all other large heads/matrices remain local, hashes published.
- [x] T4405: Real dLLM trajectory with common commit policy and declared local/
  global TV budgets, full costs and all outcomes. Operation timings do not
  establish this; compare competent complete decoders for overlapping claims.
  Protocol/source and small real CPU-service boundary oracle prepared:
 30 cases, fresh MDLM forward after commitments, same conditional-confidence
  policy, per-step tolerance0.001/initial masks, <=4 commits and interval
  refinement/exact fallback for threshold ambiguity. COMPLETE30/30 executions,
  all syntax-valid/fixed IDs preserved,184 real new forwards, no errors/refusals
  or unresolved confidence decisions. Each method uses92 forwards; one seed
  is functional evidence, not statistical decoder superiority. Frozen producer
  d0f25fd, all traces/metadata/head hashes in24/work/evidence/generation-v1.
 33-frame amplification audit complete: every frame has a strict mass-increase
  certificate, independently bounded by full exact marginals. Minimum guaranteed
  ratio ranges1.0087..4.0000 at factor4. Explicitly changes q; no semantic or
  total-speed claim. All33 outcomes in24/work/evidence/amplification-v1.
- [x] T4406: Consolidate useful confirmed result, proofs, reviewed literature
  and actual application in project/article; formalize selected sensitive
  statements only with explicit implementation/Lean boundaries. Human review
  and publication remain external, never claimed.
  Main article rewritten around closure certificates/query advantage, preserving
  earlier papers/sources in snapshots. Deterministic generator reanalyzes ALL
 1701 query records and702 separate-sampling records; verifies30 application
  transition sequences against original fixed IDs and tokenizer bytes. Public
  full-head offline demo produces valid JSON and certificate without a model.
  `make test`:87 passed36.838s; `make check`, Rust/Clippy and full selected Lean
  proofs/axiom audit pass. `make paper`:13 pages, no overflow or unresolved refs,
  all-page rendering reviewed. New timer regressions preserve honest resource
  statuses without changing historical results. Evidence and portable commands
  are retained with producer commits/source hashes; code/article are committed
  and synchronized with upstream before reporting completion.
  Prior CI exposed missing NumPy in dev extras (not solver error). Declare
  already-pinned numpy2.4.6, reproduce with a fresh dev-only environment and
  verify the actual GitHub run; do not rely on preinstalled local packages.
  Fresh dev-only `make check-project` PASS,87 tests37.158s, no Torch/model
  installed; public demo numerical/token output identical except timings.
  GitHub Actions38035436841 on e180f49 PASS (build/artifacts AND Lean).
  Verification in24/work/evidence/consolidation-v1; previous failed CI retained
  as a diagnosed undeclared dev dependency, not a retroactive success.

## M45 — Exact original-token sampling from a certified grammar/counter envelope

- [x] T4500: Independent attempt25 with eight criteria before code. Written
  disjoint event envelope, exact accepted law INCLUDING finite fixed proposal
  budget, guaranteed acceptance and polynomial/exponential comparison against
  specified published CARS updates. Additional counter-only separation is a
  mathematical corollary, NOT a performance benchmark. Classical rejection,
  weighted grammar abstraction and Twister trajectory distinction credited.
- [x] T4501: Tiny implementation, six independent original-ID/actual RNG-law
  oracles pass, including aliases, fixed IDs, UTF8 split, intra-token depth,
  deep solutions despite zero shallow mass, finite refusal and CARS bulk
  adaptive pruning. No native CARS/model-training claim. Prototype stays
  isolated; core and original A24 measured operation are preserved.
  Seventh oracle verifies zero shallow mass skips only an uninformative
  certification tail, not all deep solutions. Static v2 refinement is AFTER
  shared A24 captures but BEFORE any A25 timing; addendum and v1 preserved.
- [x] T4502: Before timings, freeze full-cost exact sampling protocol including
  raw rejection, counter-only, grammar-hit, CARS guarded/perfect, counter+CARS
  and compact exact CFG controls. Do NOT use A24 query timings as wins for
  this different operation. Continue A24 independent gate first.
  Prepared13-worker first-output/batch32 protocol and complete analyzer;
  selection only in702 development records, then1755 shared-head independent
  records if the gate passes. Source/protocol frozen in25/v2 atb831a2d;
  frozen BEFORE any A25 timing. Tiny13-worker
  oracle also prevents batch-only refusal from giving first-output credit.
  New Lean count specifications check finite-budget local law/refusal and
  amplification algebra; full make check-formal passes, verification in
 25/work/evidence/formal-v2. These are not proofs of Python or native MDLM.
- [x] T4503: Complete the same-task development usefulness decision with full
  original probabilities/costs before conditional independent/application work.
  COMPLETE702/702 rows,648 complete53 resource_refusal1 worker_error,
 162 certificate checks; frozen producerb54101c. BOTH variants0/18 primary
  first-sample wins and1/18 secondary batch32 win. The latter is not independent
  confirmation; the primary gate rejects speed adoption and does NOT trigger
  the1755-row conditional independent phase/iterative sampler demonstration.
  All rows/decision/provenance in25/work/evidence/development-v2. A timeout
  arrived during timer cancellation; unchanged raw error is not capacity credit.
  All36 candidate/state pairs fail against another completed error-free control,
  so the primary rejection does not depend on resolving that race. Minimal
  timer boundaries corrected in25 worker/24 service; two new error regressions
  plus actual service/all-worker checks pass (4 tests,0.224s). No sampler/policy,
  seed, input or measured outcome altered. Full focused suite now87 tests.
  A24 remains independently useful; no general priority/human review/publication.

## M43 — Canonical epsilon inference with original slot provenance

- [x] T4300: Create independent attempt23, answer eight scientific criteria,
  cite Mohri2002/Opedal2023 and write canonical epsilon-block bijection,
  mass/derivative/sampling/reuse proof with full-cost limitations. Three
  representations are ablations of ONE compiler, not three inventions. Six
  tiny independent product/law/reuse checks pass across12 exact kernels.
  Full original-V oracle also passes288 comparisons (24 clamped frames,
  1,206,192 independently recognized choices); correctness only.
  A new no-slot oracle found a predictive-stack backward-trimming bug: the
  retained initial zero-mass state was incorrectly made accepting at n=0.
  Fix that state in22 AND23; all timed frames have n>=16, so prior results
  and their frozen producers remain unchanged. No useful gain claim.
- [x] T4301: Freeze23 source/protocol before all full-cost development timing.
  ALL nine non-epsilon exact kernels mandatory, three epsilon ablations;
  unchanged20% wall AND CPU/favorable sign or localized equal-budget capacity.
  All six development docs ×4/8/16 masks; select one epsilon representation
  before new independent forwards, or reject if zero strong wins. Preserve
  every refusal/loss, no semantic/training/EPIC/world-priority claim.
- [ ] T4302: Only after gate success, all five new external JSONTestSuite
  documents, nine rotations and optional first-case full-head packet.

## M39 — Confirm a benefit in the actual structured-generation trajectory

Authorized on 2026-10-09 after the bounded PL decision: continue until relevant
advantages are confirmed. Preserve attempt 17, M34/M24 and maintained decoders.
Candidate 18 evaluates lexicographic equivalence and the competent classical
incremental alternative; classical foundations are not recast as inventions.

- [ ] T3900: Prove the observable greedy policy contract, independently check
  original-token transitions/fallback and compare full generation including
  preparation. Keep all negative/refused cases and stronger controls.
  **Started:** `attempts/18-monotone-grammatical-decoding/README.md` answers the
  eight scientific criteria before expansion; `work/specification.md` credits
  semiring/lexicographic parsing and Quimper–Walsh's incremental AND/OR grammar
  propagation. A minimal decremental reference preserves only actual commits,
  not speculative below-threshold acceptances. Three independent JSON-oracle
  tests pass, including aliases/prefixes, duplicates, thresholds/caps/fallback,
  counter bounds and >256-bit priorities. Native SAT plus bitset enumeration
  also agree in 40 independently enumerated small trajectories. Protocol is
  in `work/protocol.json`: six hash-selected development documents, twelve
  held-out, 4/8/16 masks, initial top16 without answer injection, actual MDLM
  forwards for each decoder and three rotated timing repetitions. Compiled
  witness greedy, integer lex, persistent-witness prefix greedy, classical
  monotone propagation, independent bitset enumeration and pinned native SAT
  are included. No publication priority is claimed.
  **CPU evaluation completed:** source
  `5da0df78e8a066ded1d0ce6c69ecbac77c966052` produced 324 development and 648
  held-out records, including every refusal/zero-support input. `work/evidence/`
  retains raw records, external MIT sources, hashes and exact commands. Generated
  `cpu-decision.md/json` verifies 504 exact shared trajectories (all proposals,
  original supports, updates and final output). Monotone completes 17/18
  development configurations and 21/36 held-out; no configuration satisfies
  the strong >=20% total wall+CPU criterion against all completed controls.
  These negative results stay published. `make test` passes 39 focused checks;
  `make check` passes upstream/lint/type and 18 attempts/35 versions integrity.
  **Next:** `gpu-addendum.json` was registered before GPU inference/timing,
  using the same documents/cases/controls and criterion. It responds to CPU
  forward cost dominating selection; it is a separately labelled secondary
  extension, not a replacement of the CPU experiment. Source/protocol/costs
  are frozen before CUDA runs. **GPU original completed:** 324 development and
  648 held-out rows; 504 additional exact shared trajectories, 1/18 and 1/36
  configurations meet the speed criterion. `work/evidence/gpu-decision.md/json`
  and `gpu-provenance.json` preserve everything. These are provisional: all
  forest controls must receive common root-dependency pruning, a classical
  optimization identified in the adversarial review. Keep the same documents,
  cases and costs; freeze a separate refinement before measuring. A victory
  against avoidable dead-forest work is insufficient to confirm useful benefit.
  **Root-pruning refinement completed:** 1,944 new CPU/GPU records over exactly
  the same documents/cases. All 1,944 match original status/support/proposals/
  updates/output. Zero configurations meet the speed criterion on either
  device: reject the original GPU gains as an adoption argument. Generated
  `trim-decision.md/json` and `trim-provenance.json` preserve all records.
  **Native refinement predeclared:** `native-addendum.json` keeps every case
  and adds Rust lex, eager and lazy native prefix greedy, using the same
  parser/lattice/linear validation. Existing Fraction/BigUint preserves dyadic
  priorities exactly, including 1075 bits; larger priority lists are unsupported
  in this reference. Rebuilt the current release binding; 20 small independent
  oracle trajectories and maximal priority width pass natively. Five focused
  offline tests pass (Python reference, no binding required in CI). Native
  speed/publication priority remains unmeasured; no promotion of production API.
  **Initial native development rejected:** 486 GPU development rows, 375 exact
  comparisons, zero criterion wins against all controls. The slower unshared
  token graph is preserved in `native-initial-*`; CPU/held-out expansion of this
  version was not run. `compression-addendum.json` preregisters the same
  proper-prefix/private-last-byte representation already used by the posterior
  and its compact equivalent CNF for ALL three native methods. All original
  cases/controls/clocks remain. Five offline oracles and20 additional native
  trajectories pass, including2/302/1075 exact priorities. These are correctness
  evidence, not timings or novelty. `make test` previously passed41 checks and
  `make check` upstream/lint/types/archive integrity; the compressed refinements
  still need full-generation measurement. No new Lean claim.
  **Compressed initial development also rejected:** 486 GPU rows,375 exact
  comparisons,zero wins; source/evidence frozen separately, no CPU/held-out
  expansion of that version. `shared-work-addendum.json` preregisters neutral
  graph reuse, dominated canonical fallback, equally improved controls, exact
  partial top16 and a common complete-word fastpath/lazy engine preparation.
  Six offline tests pass, including state reuse after direct commits and exactly
  one native lex query per ordinary transition. Native/SAT/full-sort audits are
  correctness checks before timing, not practical superiority or new theory.
  Count-warm native greedy is also included before measurement: maximizing
  proposal matches supplies a witness, not commitments; it then runs the same
  observable policy. Zero free matches certify canonical fallback directly.
  All ten controls receive the same fastpath/partial selection; complete costs
  and original cases remain. Shared refinement finished540 GPU development
  rows,438 exact comparisons,zero criterion wins. Preserve everything; CPU
  and heldout of this version were not run. Rooted semiring/Earley parsing is
  the next bounded implementation investigation, not an asserted new theorem.
  Implemented grouped root prediction/completion and exact max-plus byte-DAG
  deduction, plus complete structural forests for ALL forest controls. Same
  rooted kernel runs lex/eager/lazy/count-warm and speculative-prefix variants;
  Rust gets the same speculative-prefix policy. At most two queries per step,
  only a feasible joint prefix is accepted directly. Classical references,
  complete costs and sixteen methods are registered in rooted-addendum.json
  before timing. Seven offline oracles pass, including independent complete
  path counts and quoted/escaped/UTF8/alias inputs. Rooted development finished864 records,744 exact comparisons,zero wins.
  Preserve all; no CPU/heldout expansion for that version. Frozen-support
  propagation remains the better practical control. Investigate model-driven
  growing support separately with strong reusable-reservoir controls.

- [ ] T3901: Investigate model-driven growing support after rejecting repeated
  queries on fixed support. Attempt19 is independent of mutable attempt18:
  copied source origin15767f3, eight criteria and full-cost protocol first.
  Union current top16 with earlier free-slot domains, no target injection;
  all actual model argmax proposals are admitted. Exact per-step policy and
  monotone-domain invariants yield whole-trajectory equivalence. All16 controls
  remain, with additional SAT reserves32/64/128, explicit inactive-token masks
  and larger compilation budgets. Native/SAT60 small adaptive trajectories
  agree with independent JSON-product oracle before any model timing. Offline
  CI checks union and seven same-operation selectors on those trajectories.
  Same six development/twelve refinement documents, plus last six fresh
  hash-selected documents if development passes. No practical/novelty claim.

## M38 — Align standing instructions with the current scientific objective

Authorized on 2026-10-08: update `AGENTS.md` to reflect the current research
workflow and require useful, significant, preferably mathematical improvements
to CFG/JSON generation with dLLMs. Publication is an objective, not a promised
outcome. Depends on M37 preservation and the existing M36 research evidence;
does not assert that the open scientific-priority/review gates have passed.

- [x] T3800: Replace obsolete project framing and authorization chronology
  with the current state, mandatory idea/implementation questions, mathematical
  preference, fair empirical fallback, practical relevance and publication
  criteria. Check Jev against primary sources and define the dJev motivation.
  **Acceptance:** independent attempts, current focused tests and component
  contracts remain explicit. MWPC is a retained component, not a compulsory
  objective for every new approach. Distinguish typed decisions, grammar-valid
  text, semantic correctness, proved bounds and empirical speed. Preserve
  existing guarantees and clearly state unmet novelty/application claims.
  **Evidence:** `AGENTS.md` now describes the maintained posterior/commitment
  components and separate semantic research, with eight mandatory questions
  per idea/implementation. Written mathematics is preferred; empirical work is
  permitted with fair predeclared evaluation. Explicit rules cover significance,
  adoption, comparative advantage, total costs, counterexamples, publication,
  willingness to change direction and preservation of every attempt.
  Primary TypeSafe launch/API pages were consulted on 2026-10-08 and linked:
  Jev supplies typed parallel decisions rather than free string generation;
  vendor speed claims are not this project's evidence. dJev remains a research
  motivation, not a trained model or claimed speed win. Existing support,
  slots, statuses, certificate, probability and formal-scope contracts retained.
- [x] T3801: Verify the instructions against retained paths, tasks and current
  evidence, preserve every frozen archive and synchronize the documentation.
  **Acceptance:** no solver/archived data/frozen-version edits, no restored
  historical suite, no invented approval or scientific result. Normal push;
  local and upstream main agree.
  **Evidence:** `make check` passes upstream verification, lint/format, typing
  and all 16 attempt / 18 version integrity checks. `verify_artifacts.py`
  confirms 3,683 scientific files unchanged; `git diff --check` passes.
  A structural read verifies all eight questions and every local Markdown link.
  Only `AGENTS.md` and `TASKS.md` differ; protected `formal/MWPC.lean` and the
  attempt catalog match their original Git blobs. Solver sources, active tests
  and frozen versions are unchanged. Instruction source
  `339b804de5e9d6b6f4977444d75a3723f47502c9` was pushed normally; local/upstream
  counts are `0 0`. CI [37778210371](https://github.com/j0taaa/tcc-final/actions/runs/37778210371)
  passes. This is completion of the requested standing-instruction update,
  not a claim that the publication/novelty objectives have been achieved.

## M37 — Preserve every research direction in its own folder

Authorized on 2026-10-08 by the user's request for independent folders for
every attempt. Depends on the existing historical commits and archives, not
on the open M36 human-review/priority gates. Preserve the maintained decoders,
all original scientific artifacts and their producing provenance. Archiving
does not establish correctness, novelty, practical superiority or review approval.

- [x] T3700: Inventory the historical research directions and create separate
  immutable source/evidence snapshots with an index, recorded conclusions,
  full source commits and per-file checksums. Include discarded directions.
  **Acceptance:** each folder contains actual source and evidence bytes, not
  links to mutable live files; every existing raw archive is represented.
  Dependencies/model availability and source/evidence commit differences are
  explicit. Historical tests remain inside archives, outside the active suite.
  Snapshot creation refuses to overwrite an existing version. Integrity checks
  work offline without historical Git objects and also check origin trees when
  requested. Future attempts begin in their own folders before exploration.
  **Evidence:** `attempts/catalog.json` registers 16 directions, covering all
  19 existing raw-archive families, including discarded event reductions and
  unfavorable comparisons. Each `attempts/<id>/v1/` contains actual source and
  evidence archives plus original commits, submodule pins and per-file SHA-256.
  `python3 scripts/archive_attempts.py --create all --git` freezes/checks 13,012
  file copies (330,297,221 uncompressed bytes). `--check --git` confirms the
  complete selected origin trees, not just a few example files. Offline
  `env PATH= .venv/bin/python scripts/archive_attempts.py --check` passes without
  access to Git executables. A temporary-copy corruption check updates the outer
  ZIP checksum and still fails on the changed internal file; originals untouched.
  Attempting to freeze the existing event snapshot raises `FileExistsError`.
  A selection fixture confirms future `work/` is included while sibling work
  and previous snapshots are excluded. All principal reading paths exist inside
  their respective source archives. These are preservation checks, not new
  scientific experiments or restored historical test runs.
- [x] T3701: Make archive integrity mandatory in CI and document access and
  future preservation. Commit/push the completed organization.
  **Acceptance:** existing scientific archives and baseline source unchanged;
  validation distinguishes preservation from solver correctness. Local and
  upstream main agree after a normal fast-forward push.
  **Evidence:** `make check` passes upstream verification, lint/format (79
  source/script files), typing (58 package files) and the new mandatory offline
  `attempts-check` target; existing CI calls this target through `make check`.
  `make article-results-check` passes all 3,683 frozen-file checks, archived
  probability/CFG products and the generated complete semantic table.
  `formal/MWPC.lean` matches the pre-organization Git blob exactly.
  Instructions and future folder/version policy are in `attempts/README.md`
  and `AGENTS.md`. Source commit `40061d2695d3d8e54c3fe37e2841961c6ebc80c9`
  was pushed normally to `main`; local/upstream counts are `0 0`. Source CI
  [37771169655](https://github.com/j0taaa/tcc-final/actions/runs/37771169655)
  passes both jobs: mandatory archive integrity, the focused suite, Rust,
  original artifact products and selected Lean checks. Frozen version files
  remain unchanged after publication; this checklist records preservation,
  not resolution of the independent M36 scientific review gates.

- [x] T3702: Preserve the literal initial repository and the first completed
  MWPC prototype as separate versions of the original direction, following the
  user's question about the very first attempt.
  **Acceptance:** distinguish the initial README-only commit, the completed M2
  prototype and the consolidated M17 source. Copy historical bytes with full
  commits/hashes; do not modify any published frozen version or active tests.
  Check all snapshots against origin trees, preserve the existing scientific
  archive and synchronize the new versions to GitHub.
  **Evidence:** `archive_attempts.py --create 01-mwpc-original --version
  initial-repository --git` preserves the initial README-only Git tree
  (`836540d18fd0c37ae9f0d577e5c25ca508dfd13b`, one file). The same command with
  `--version first-working-prototype` preserves the completed M2 tree
  (`6a5945bef2e9c6dc55ad8d0d02f91656215ac6aa`, 86 files), including the original
  token-aligned parser, normalizer and validator. `--check --git` passes all
  16 directions / 18 versions / 13,099 file copies (330,825,529 bytes).
  `make attempts-check` passes offline integrity and `verify_artifacts.py`
  confirms all 3,683 original scientific files unchanged. Published `v1/`
  paths have no Git diff; historical tests stay inside the new ZIP only.
  Preservation source `11d773889dd2c1c21c33a7bace9da19fbe82f611` was pushed
  normally to `main`; local/upstream counts are `0 0`. This does not assert
  access to attempts or files that predate the repository's recorded history.

## M36 — Scientific contribution gates before another implementation

Authorized on 2026-10-07 by the user's staged research plan (items 1–22;
the user subsequently authorized completing item 22 and choosing later tasks,
and confirmed no external comments are available). Depends on completed M35. Preserve
`c018c3843b7b5c4dda41cb72f3f7cfc19ad7af80`, all unfavorable evidence and the
existing decoders. Research calculations do not authorize a novelty claim,
invented advisor approval, or replacing the article's established contribution.
Use one notebook: `docs/research/contribution-plan.md`.

- [x] T3613: Independently audit the received PL-latent resampling note.
  **Acceptance:** freeze the protocol before measurement; check exact posterior
  and gradient laws with independent enumeration; compare competent rejection
  and enumeration on every predeclared JSON model input, preserving losses and
  resource refusals. Separate correctness, novelty and training usefulness.
  **Evidence:** `attempts/17-pl-latent-resampling/work/final-report.md` is
  generated from all four preserved replay campaigns; producing commits,
  commands, rational normalizers and failures are in `work/evidence/`.
  Final source `5c88e6e7162267a5b6d32d1d454764f54d73a615` checks 1,151 events,
  2,939 paths and 48 gradient/covariance fixtures without exact mismatch.
  `make test` passes 30 focused checks; `make check` and the 3,683-file frozen
  scientific inventory pass. The nine original model inputs give eight
  compilations/48 native PL events; one compilation remains unresolved.
  The final control completes 144/144 batches against 138/144 for the mixture.
  Exact normalizer ratios favor the mixture over the single tilt in 1/48
  events; its full query cost loses to the best recorded control in all
  fully paired events. No unfavorable campaign or harness error was erased.
  `work/product-proposal-separation.md` proves a written asymptotic separation
  against any single product proposal, with counter-based alternatives and
  circuit/bit-cost assumptions explicit. It is not a new Lean verification.
  **Scientific decision:** technical audit complete; T3602's novelty/usefulness
  gate remains open. `work/auxiliary-variable-objection.md` derives a classical
  PL augmentation control that starts at the original stationary proposal and
  reduces variance with correlated replicas; it was not implemented/measured.
  Neither training benefit nor academic priority is confirmed. Directions
  15/16 remain rejected protagonists; the main paper/decoders were preserved.
  **Preservation:** five immutable versions in attempt 17, including the first
  harness failure; `make attempts-check` verifies 17 attempts/23 versions and
  16,404 files. Extracted v5 passes its five focused tests offline and losslessly
  reconstructs all nine original JSON inputs with archive hashes checked.
  CI for assessment commit `162d4001244900038ab1da3abede4317907609ba` passed.

- [x] T3614: Decide useful benefit of PL latent conditioning, including total
  training cost and the stationary auxiliary-variable alternative.
  **Historical refinement:** preserve v1–v5; the full-dyadic refinement protocol targets
  an observed coefficient-denominator bottleneck without changing the target.
  Strengthen the control equally. Do not call a query speedup, logit-only
  variance reduction, or a task list a completed neural benefit evaluation.
  **Completed evidence, not final decision:** immutable v6–v13 preserve the
  full-dyadic oracle/replay, all initial and failed neural harnesses, cached
  controls, complete 4096-draw campaigns and the forced-decision prototype.
  The final neural campaign has 4,044 completed timing records, nine estimators,
  six independently selected documents and 12 gradient configurations. An
  independent offline geometry check agrees to relative error below 3.2e-14.
  Exact conditional means win all 12 cases in all four cost scopes, even against
  the zero-extra-cost lower bound for an estimator using one iid replica.
  Source/evidence and this decision are preserved in
  `work/evidence/utility/neural-utility-v4/` and
  `work/evidence/utility/neural-iid-cost-floor-decision.json`.
  No optimizer update or final-generation improvement is claimed. The remaining
  all-input bulk comparison includes compact indexed profiles so that inefficient
  rational labels cannot manufacture a win for the mixture. Older losses,
  interrupted runs and timeouts remain in the record.
  **Decision completed:** `work/usefulness-decision.md` separates adoption,
  mathematics and priority. The final generated reports include all 48 events,
  13 methods/configurations, 1,872 queries and 6,215,868 accepted draws. Mixture
  has the predeclared >=20% CPU/wall advantage in 3/48 warm events and 2/48 cold
  events; the 1024 prefix has none. For json-context0-16/power1/k8, cold medians
  are 11.08s versus 23.82s for strengthened SingleTilt. Larger-resource profiles
  also fail their preparation deadline in that event; the win is not based only
  on the former 1M/3M representation caps. All nine inputs, failures and losses
  are retained. Sequential timing comparisons are descriptive, not a universal
  speed guarantee. Stream checks preserve 321 and 342 complete query laws.
  **Training boundary:** all 4,044 final neural records completed; exact
  conditional enumeration wins 12/12 cases, even versus zero-overhead iid
  resampling. The head-gradient operation includes forward/backward costs;
  optimizer updates, full-model training and final-document gains were not
  demonstrated. Those broader claims are rejected rather than marked complete.
  Proofs are written, not new Lean certificates. T3602/T3603 remain open.
  **Reproduce:** `utility_report.py` with final neural captures, combined bulk
  and independent geometry, plus `--prefix-1024`; exact commands and hashes in
  `work/evidence/utility/final-analysis-provenance.json`. The optional neural
  rerun uses the pinned public checkpoint; offline capture checks need no model.
  **Final preservation and verification (2026-10-09):** v14–v16 retain the
  final neural campaign, compact and larger-resource controls, complete reports
  and written decision without overwriting earlier versions. v16 uses source
  `f0f8322566d0c50c4ac0f7a988fd0fcf509b7aaa` and evidence
  `dae48ff8ba8a44c1d077b1439ab3d7870907fae8`. `make check`, `make test`
  (36 focused tests), `make article-results-check` and
  `scripts/archive_attempts.py --check --git` pass: 17 attempts, 34 versions,
  24,467 preserved file copies; all 3,683 frozen scientific files unchanged.
  Ruff checks of the research work and PL test pass. An isolated extraction
  into `.cache/pl-independent-v16` runs its own archived `src/`: 11 PL tests
  pass with `PYTHONPATH=src:. ../../.venv/bin/python -m unittest discover
  -s tests -p test_pl_resampling.py -q`. Its independent NumPy geometry check,
  `OPENBLAS_NUM_THREADS=1 PYTHONPATH=src:. ../../.venv-live/bin/python
  attempts/17-pl-latent-resampling/work/verify_neural_geometry.py --evidence
  attempts/17-pl-latent-resampling/work/evidence/utility/neural-utility-v4
  --output independent-geometry.json`, verifies all 12 configurations, with
  maximum relative error 3.1986037583459516e-14. Nine archived M34 input hashes,
  producer hashes and final report hashes also verify offline. These checks
  establish reproduction/correctness evidence, not novelty or human review.
  Evidence commit CI [37908892466](https://github.com/j0taaa/tcc-final/actions/runs/37908892466)
  passes Python/tests, Rust/artifacts and the selected Lean results. New proofs
  in attempt 17 remain written proofs, not Lean-verified implementation claims.

- [x] T3600: Record the stable base, precise candidate contract and one
  recursive structured-generation application (plan 1, 2, 4).
  **Acceptance:** original-token/fixed-slot/support/EOS/status guarantees stay
  explicit; an operation, competent comparator and falsifiable advantage are
  defined without a benchmark win or a unique answer built into the grammar.
  **Evidence:** clean `main` at the recorded full base hash, followed by
  `git fetch origin`/`git rev-list --left-right --count HEAD...origin/main`
  yielding `0 0` before edits were committed. Notebook sections 1–3, 7 and 11
  define the candidate contract, recursive filter application and exclusions.
- [x] T3601: Read the directed primary antecedents, build the novelty matrix
  and attempt reductions for at most two directions (plan 5–9).
  **Acceptance:** EPIC v2 dated 2026-10-04, CFG probabilistic-word/Markov
  inference, automata, FactorDLM and relevant coherence antecedents are treated
  fairly with exact locators. Known projection/cache reductions are rejected as
  sole novelty. Any surviving result remains a candidate pending review.
  **Evidence:** notebook sections 4–6 record directed original-source
  readings with theorem/equation/algorithm locators, a 14-row novelty matrix,
  SparseMAP/coherence and cache reductions, EPIC's dated v2 and the additional
  DUEL/trajectory/ranking/CAR antecedents required by the narrower candidate.
  Scientific novelty/significance is explicitly not established.
- [ ] T3602: Develop the surviving candidate's specification, comparator,
  written proof, total/bit costs, JSON corollary and integration boundaries
  (plan 10–18). Small independent enumeration may falsify the derivation;
  it is not a performance experiment or proof of novelty.
  **Acceptance:** distinguishing step proved or explicitly diagnosed; invalid
  cases, zero probability and local/global likelihood distinctions covered.
  **Evidence:** notebook sections 7–12 contain the event equivalence, mass
  identity, written total/bit-cost analysis, JSON application and objections.
  The one new research oracle checks 8,016 events across 24 small inputs
  (13 positive, 11 zero mass) against independent stack/JSON recognition and
  direct sort/group enumeration. `make test` passes all 12 focused checks;
  the historical suite remains deleted. This is no performance/novelty proof.
  **BLOCKED:** no distinctive theoretical advantage over competent WMC/ranking
  methods has been established. The scoped reduction may be a direct known
  consequence; T3602 stays open until that scientific gate is resolved.
  **Next investigation:** assess whether a genuinely requested operation needs
  more than the event-specific unary WMC reduction; reject improvements that
  only restate CAR/conditioning or compare with an incorrect likelihood.
  The §8.1 TV/KL diagnostic is a known conditional-probability consequence,
  not a resolution of this novelty gate.
  **Continuation:** notebook §14 replaces that operation as the research focus
  with execution-conditioned Boolean rule infilling. A tight `3^m` versus `2^m`
  bilinear-plan comparison and sampling law are written; the finite rectangle
  obstruction is checked in Lean. The transform and weighted synthesis are
  credited antecedents. Scientific priority/significance over a competent
  classical signed solver remain unestablished, so this gate stays open.
  **2026-10-08 continuation:** notebook §16 and T3609 establish a bounded
  exact refinement stream, a zero-rejection prefix representation gap and a
  weight-independent sufficient semantic core. These are useful scoped
  guarantees and an implemented specialization; compact automata/tree/factor
  methods can share them. The selected claim is not promoted to a novel
  general inference principle or exclusive priority without T3603.
  **Direction review, 2026-10-08:** notebook §17 and
  `attempts/15-adaptive-semantic-cores/work/2026-10-08-direction-review.md`
  add a checked primary antecedent: VSampler, Ji et al. PLDI 2020, §5 and
  Theorem 5.7. A classical telescoping reduction explains the overlap; a DNF
  expressivity argument rules out assuming small cores in unrestricted Boolean
  languages. Eight current scientific criteria and a total-cost comparison
  define the next investigation. No new solver, benchmark or novelty claim;
  this task remains open. `make check` passes; all 16 attempts / 18 versions
  retain their 13,099 frozen files. `verify_artifacts.py` confirms 3,683
  scientific files unchanged; local links/eight criteria and `git diff --check`
  pass. This is a documentation/mathematical review, not new solver testing.
- [ ] T3603: Obtain actual advisor/calendar alignment and independent human
  mathematical/novelty review (plan 3, 9, 19).
  **Acceptance:** real comments and their responses recorded; no inferred
  approval, no automatic contacting others. Promotion to the final contribution
  follows this review. User-authorized preliminary Lean checks have precise
  kernel/source boundaries and cannot substitute for independent comments.
  **BLOCKED:** no advisor/expert comments or confirmed institutional calendar
  have been supplied; the user explicitly confirmed no comments yet.
  Notebook supplies a concrete review dossier, not an approval.
  **Evidence:** pending external input.
- [ ] T3604: Once the novelty/advantage/review gates pass, implement only the
  selected result, validate it independently and register the complete
  experiment protocol before timing (plan 20–22).
  **Acceptance:** small implementation matches the reviewed theorem; CI runs
  focused independent checks. Strong classical controls, failures, fixed
  budgets, immutable configs and provenance precede any performance claims.
  **BLOCKED:** T3602–T3603 are open. Item 22 is now completed by authorized
  decision, removing the missing-text blocker. No new
  production decoder, model training or favorable benchmark is a substitute.
  **Evidence:** implementation/measurements pending; notebook §13 defines
  the protocol and tasks 23–27, explicitly without execution or gate approval.
- [ ] T3605: Prepare the reviewed publication change and synchronize completed
  work, without submitting or promising publication acceptance.
  **Acceptance:** bibliography, claim/proof/code/evidence map and manuscript
  are consistent with the actual result; user-required local/GitHub sync holds.
  **BLOCKED:** scientific scope/review T3602–T3604 remains open. Existing paper
  and historical results remain the stable submission, not a new-result claim.
  **Evidence:** pending.
- [x] T3606: Complete item 22 and choose the remaining publication/reproduction
  steps independently of implementing a new candidate.
  **Acceptance:** prior inputs are development, not retrospective held-out
  evaluation; prospective source/split, competent controls, same inputs,
  budgets, statuses, analysis and freeze rules are specified before timing.
  Later tasks and external review remain distinct from completed planning.
  **Evidence:** notebook §13 defines item 22 and tasks 23–27. Read the official
  JsonLogic consumer at `c5c73601c90b11e98f6846609bac4dec203d1c18`;
  fetched only the external corpus byte identity (17,574 bytes, SHA-256
  `a202b65edda0d7ab687c758b8f10cfe9ba75561cd7166e5650710f88f26303a4`).
  No rules were enumerated, model captured, solver timed or result selected.
  `git diff --check` validates document whitespace; scientific gates stay open.
- [x] T3607: Under the continued substantive-work instruction, deliver a small
  execution-conditioning research reference and a proved, scoped comparator
  (independent investigation for T3602; not production promotion for T3604).
  **Acceptance:** grammar/weights/support independent of labels; exact original
  token mass and sampling, finite slots, zero mass and resource refusal distinct.
  Independent token/tree and sampling-decision oracles pass. Non-negative
  comparator is optimal in its explicit bilinear class; signed-transform
  antecedents and full/target/sparse/global limitations remain explicit.
  **Evidence:** `make check test` passes the fifteen focused checks; reran the
  three semantic oracles after strengthening the nested-shape case; the latest
  full run also validates the sparse/transform dispatch.
  `make build-rust`, `make check-formal LAKE="$HOME/.elan/bin/lake"`, and
  `make paper` pass, preserving all 3,683 frozen archive files and the 16-page
  main manuscript. `make research-note` builds the three-page supplement with
  no overflow/unresolved references; all pages were visually inspected.
  Nine new Lean statements are audited, including the natural-coefficient
  bilinear lower bound. Scientific priority/human review and
  production promotion remain separate incomplete gates, not implied passes.
- [x] T3608: Materialize the frozen semantic integration demonstration.
  **Acceptance:** actual pinned local CPU MDLM probabilities, source/config
  commit, preserved full-softmax normalization, offline archived recomputation,
  independent enumeration and official pinned JsonLogic execution. Preserve the
  preregistered unsupported-by-canvas target as zero mass; no performance,
  external-test-set or out-of-example correctness claim.
  **Evidence:** clean producing commit `2be61a9773a016930dc407ab051d6f2d497704a0`,
  frozen config and complete raw artifacts at
  `docs/artifacts/raw/m36_semantic_reference_v1/`. Actual local CPU MDLM forward,
  independent full-softmax audit, all 108 template rules on eight records and
  pinned official JsonLogic execution pass. Both positive targets yield sixteen
  samples; the preregistered parity target is zero mass. Dependency-free offline
  replay exactly reproduces archived masses/statuses, and `make check test`
  passes all sixteen focused checks including that current-solver recomputation.
  Per-cell semantic/syntax mass partition checks now detect losses before
  final normalization. Commands and boundaries are recorded in
  `docs/evidence/m36-semantic-reference.md`; derived probabilities/trial counts
  are script-generated, not measured superiority. T3602–T3605 stay separate.
  Source/archive follow-up `d3223d7` is pushed; Actions run `37705745997`
  passes both jobs and its log confirms all sixteen tests actually ran.

- [x] T3609: Continue the scientific investigation with execution-counterexample
  refinement, its exact stream law/finite rejection bound and a competent
  prefix-representation comparison. Keep classical compact controls explicit.
  **Acceptance:** proof includes preparation, all-record verification, integer
  costs, caps and original-token probabilities. Independent stream-law and
  prefix-control oracles pass; selected finite obligations compile in Lean.
  Certify a sufficient example core with positive auxiliary weights on the
  entire support; retain correctness under reweighting, support contraction
  and new commitments, and reject expansion/released commitments.
  Audit all 256 labels of the unchanged MDLM capture with three frozen seeds,
  eager inference, enumeration, perfect-oracle prefix exclusion and certified
  cores. Preserve
  zero cases, losses and complete producing provenance; no new favorable corpus.
  **Evidence:** producing source `30e6ac38aac69ddc0e9ccad6c0ac06d36016fa9c`
  was clean before `python -m scripts.exact_commit.audit_adaptive_semantics
  --output docs/artifacts/raw/m36_adaptive_semantics_v1`. All 256 labels,
  three seeds and five methods are retained: 51 positive and 717 zero rows
  per method, no resource refusals. Independent `--check` verifies all masses,
  returned token paths and each core's equivalence on all 108 original paths.
  `make check test` passes 24 focused checks, including current-code first
  positive/zero recomputation and the 64-distinct-record/two-core oracle.
  The identifier trie additionally verifies real field names, shared prefixes
  and token splits without changing the pinned single-letter grammar/archive.
  `make check-formal LAKE="$HOME/.elan/bin/lake"` audits 66 selected statements;
  source CI run `37723768912` passes tests/build/artifacts/formal.
  Notebook §16 and supplement R1–R3 include written proofs and preparation/bit
  costs. `make research-note` builds seven pages without overflow/unresolved
  references; all final pages visually inspected. The generated complete report
  and table retain enumeration's faster result and core-preparation overhead.
  Scientific priority and external review remain separate from these technical
  acceptance criteria. No production promotion or native CARS speed claim.

- [x] T3610: Prove a finite-batch expected-rejection comparison against the
  published CARS visited-prefix update, beyond the zero-rejection representation
  bound. Keep the perfect oracle, exact output law and preparation costs explicit.
  **Acceptance:** stopped expectation argument is complete; uniform and
  nonuniform assumptions distinct. Independent exact decision trees agree with
  a finite-state recursion, including a worst-case feasible branch. Do not
  infer wall-time/automata/priority superiority or call the written law Lean-proved.
  **Evidence:** supplement Proposition C1 and notebook §16 include the
  bounded stopping argument, group occupancy lower bound, weighted extension
  and comparison to the one-rejection stream. `make check test research-note`
  passes lint/type/format, all 25 focused checks and the eight-page PDF build
  without overflow/unresolved references. The new oracle independently sums
  the finite control's whole decision trees and checks rational expectations
  against a finite-state recursion; it also realizes every still-uncut invalid
  path before the first valid output with positive probability. Final pages
  are visually inspected. The 768-row archive and its producing commit remain
  unchanged; C1 is a written universal comparison, not a new timing campaign.
  Source `69cf9acaf04bd480a2299bd8af31a1a74423b468` is synchronized and CI
  [37727393243](https://github.com/j0taaa/tcc-final/actions/runs/37727393243)
  passes both jobs. Its log confirms all 25 tests (including C1), Rust,
  3,683 preserved artifacts, the generated table and the Lean audit ran.
  Kernel/source/priority boundaries stay explicit.

## M35 — Consolidate posterior correctness gates and bounded compilation

Authorized by the 2026-10-06 review follow-up. Depends on M34. Preserve the
original-token posterior, LL(1) admission, exact finite-support scope, fixed
positions and existing baselines. Resource refusal is unresolved, never zero
mass or infeasibility. Historical experiment inputs/outcomes remain immutable;
new checks do not establish whole-source refinement or semantic superiority.

- [x] T3500: Run the existing focused suite in CI and recompute a small,
  deterministic sample of archived inputs against recorded mass/marginals.
  **Acceptance:** `make test` is mandatory in the Python job; one input selected
  by smallest free canvas then case ID from each final M34 cohort is recomputed
  with current code. No model/network dependency or historical suite restored.
  **Evidence:** Python CI now invokes `make test VENV_PY=python`. `make test`
  passes nine focused tests, including live recomputation of one input per
  final scaling/array/JSON cohort against the immutable rational mass/marginals.
  Selection depends only on free-slot count and case ID, never solver outcomes.
- [x] T3501: Bound admission, canonical normalization, private binarization,
  token-DAG construction and forest construction under one compilation deadline.
  **Acceptance:** preprocessing work is bounded before nullable expansion
  allocations; exact source/input comparison is retained. Independent oracles,
  archived regressions and focused work/deadline/mismatch checks pass. Limits
  terminate with `CompilationLimit`, preserving earlier archive outcomes.
  **Evidence:** `make check test` passes all 11 focused tests. A shared
  `WorkBudget` caps preprocessing before projected nullable/prefix allocations
  and carries the compiler deadline through all stages. Stable nullable-body
  deduplication preserves first occurrences; exact canonical equality remains.
  `build_cfg_posterior_results --recompute` attempts all 55 final inputs: 54
  match rational mass/all marginals exactly, one remains unresolved without an
  archived numerical oracle. No historical timing/result is overwritten.
- [x] T3502: Center the article's introduction/formulation on the posterior;
  document CI, bounded preprocessing and the offline/full-logit reproduction
  boundary. Keep MWPC and certificates as complementary contributions.
  **Acceptance:** mathematical/artifact/build gates and paper layout pass;
  scope and historical evidence remain accurate. Changes are committed/pushed
  and the GitHub checks including the focused suite pass.
  **Evidence:** Local `make build-rust`, `make check-formal`, article artifact
  checks and `make paper` pass (41 audited statements, 3,683 unchanged prior
  scientific hashes, 16-page/no-overflow/reference gate). Render overview and
  detailed changed-page review pass. Posterior formulation/results now precede
  complementary MWPC/certificates. Source/archive/optional-logit boundaries are
  documented. Implementation `c5c84b9` is pushed; GitHub Actions run
  `37565587358` passes both jobs. Its log confirms all 11 tests, including the
  current-solver recomputation, actually ran. Complete commands/limits/evidence:
  `docs/evidence/m35-consolidation.md`.

## M34 — Exact recursive-CFG posterior: investigate, prove, then falsify

Authorized on 2026-10-06: pursue a useful scientific contribution and add
necessary fair tests. Depends on M31 and M33; the old suite stays deleted.
Preserve MWPC, finite-slot/support/status/probability contracts and all negative
evidence. Candidate: ambiguity-checked LL(1) byte grammars and sum-product
inference on a token DAG, rather than enumerating valid sequences or expanding
all stack configurations. Classical weighted parsing is an antecedent, not a
new invention. No claim of world priority or general superiority is authorized
by a search, theorem, compilation or demonstration alone.

- [x] T3400: Establish the precise useful capability, primary antecedents,
  mathematical contract and falsifiable protocol before new measurements.
  **Acceptance:** exact original-token posterior under an automatically checked
  unambiguity condition; explicit support/EOS scope; polynomial arithmetic-work
  bound and a scoped automaton representation separation; known Markov/CFG
  inference credited. Predeclare exhaustive oracles, negative controls, external
  inputs and strong comparisons, including cases expected to favor alternatives.
  **Evidence:** `docs/research/m34-exact-cfg-posterior.md` states token-path,
  LL(1)/normalization, inside/outside/sampling obligations and the scoped NFA
  fooling-set separation. Primary literature includes Goodman/Stolcke and
  Rivaud--Pachet's already established CFG/Markov tractability, DINGO, EPIC,
  Dang--Ermon and FactorDLM; no first-ever claim. Before measurements,
  `configs/experiments/m34_cfg_posterior_v1.json` fixes all grid cells, losing
  controls, 18 M31 replays, resource limits and pinned JSONTestSuite's complete
  <=128-byte conformance subset. Source FIRST/FOLLOW checking and initial
  independent token-product tests are implemented; later gates remain open.
- [x] T3401: Implement the smallest reusable, model-independent compiler and
  exact sampler that satisfy T3400. Reuse immutable grammar/tokenizer contracts;
  fail explicitly on unsupported grammar/control semantics and work limits.
  **Acceptance:** independently enumerated token-path masses/marginals and
  sampling transition probabilities agree, including aliases, token prefixes,
  fixed positions, missing support, zero mass and changed weights. No old suite
  restored; focused new tests may falsify this extension. Mathematical proof
  obligations and Lean coverage/limits stated accurately.
  **Evidence:** `cfg_posterior.py` compiles a sparse probability-independent
  forest, evaluates rational inside/outside masses and samples original tokens;
  `reference/ll1.py` checks the source contract and `json_grammar.py` includes
  recursive RFC JSON syntax/UTF-8. `make check` passes (57 source modules).
  `make test` runs six newly authorized focused tests: 180 random reweighted
  product-oracle cases, exact RNG-transcript law with aliases, prefixes/fixed
  slots, explicit refusals/limits, independent stack-control oracle, and all
  281 defined plus 33 informational pinned <=128-byte JSON cases (empty JSON
  rejected at the nonempty canvas boundary). `make check-formal
  LAKE=/home/jota/.elan/bin/lake` checks 40 statements, including the conditional
  finite fooling-set/state bound; Python/normalizer/model source refinement and
  a fully mechanized sampling law are not claimed. New controls/protocol code
  is not practical-benefit evidence; T3402 remains open.
- [x] T3401a: Use exactly scaled integer unaries and binarize before nullable
  expansion; give the independent controller the same numerical benefit.
  **Acceptance:** common-denominator/path and private-binarization proofs,
  unchanged masses/marginals/sampling law against independent oracles; fixed
  original model inputs reused before/after, all earlier failures retained.
  **Evidence:** `6331e37` reruns all 28/18/9 saved inputs, no new forwards;
  all 52 previously resolved masses/marginals are exactly unchanged. Both
  independent controllers use row-scaled integer arithmetic. The median paired
  query ratio over those 52 cases is 10.23 versus our rational prototype, not
  a competitor speed claim. The forest/private-binarization and scaling proofs
  are in M34's research note/article; `row_product_scaling` is audited in Lean.
  All initial failures remain in the packed raw archive. `make test` passes
  eight focused independent tests, including 60 weighted JSON token-product
  cases, four direct JSON-family instantiations and 30 contracted-state oracles.
- [x] T3402: Evaluate every predeclared comparison/application; keep failures
  and losing cases. Include genuine saved/fresh dLLM predictions, external
  structured inputs and an independently implemented exact stack controller.
  **Acceptance:** immutable config/raw lineage, identical inputs, separately
  recorded construction/query/sample costs, correct outputs and an honest
  verdict. If the proposed useful advantage does not survive, continue the
  scientific search instead of relabeling the failed experiment a win.
  **Evidence:** complete immutable configs/outcomes/input hashes/producing
  commits/commands are losslessly packed under
  `docs/artifacts/raw/m34_cfg_posterior_v1/`; every final comparison is generated
  in the processed report. CFG resolves 28/28 scaling and 18/18 model arrays;
  six large explicit-stack cases hit their unchanged representation budget.
  Compact array inference generally remains cheaper. Fresh full-JSON resolves
  8/9, one work limit; syntax samples do not establish semantic quality.
  All 281 defined and 33 informational external JSON cases are retained.
  `build_cfg_posterior_results --check` checks original-input equality and
  control mass/marginal agreement, all statuses and generated products. Opt-in
  full-logit checks pass on all nine fresh and all 18 older captures, including
  full non-mask softmax/rational normalization and original retained unaries.
  Utility is exact recursive finite-token inference with a written scoped
  polynomial-versus-exponential JSON-family argument, not manufactured model
  superiority or a claim to invent classical weighted CFG sampling.
- [x] T3402a: Demonstrate posterior reuse under actual support/canvas contraction
  and compare exact represented-support rejection on every saved model case.
  **Acceptance:** independently checked reuse equals fresh compilation; fixed
  tokens preserved. Rejection uses the same original probabilities, renormalized
  only for represented-support draws, so expected attempts are retained mass/Z,
  not 1/Z. All 27 cases and favorable rejection outcomes included; this is a
  transparently added control, not a preregistered new population benchmark.
  **Evidence:** `e5b28e1` executes every one of the 27 saved model cases.
  Rejection samples 14 and exhausts 10,000 trials on 13; it is cheaper on every
  smaller JSON case in the recorded seed. Computed expected attempts use Q/Z,
  with no penalty for omitted tokens. Cached/recompiled mass and marginals
  agree in all 26 resolved clamped canvases; the remaining case keeps its work
  refusal. Fixed slots and sampled syntax independently check. The follow-up
  was added after the initial grid and is explicitly labeled accordingly.
- [x] T3403: Integrate the surviving contribution into the maintained project
  and article with reproducible checks and precise novelty/utility boundaries.
  **Acceptance:** operational/formal/new targeted checks and article artifacts
  pass; no universal source-correctness, semantic-quality or global-trajectory
  claim; scientific gain explained relative to actual alternatives.
  **Evidence:** maintained model-independent API supports reweighting,
  restriction and new commitments; offline original-model sampling runs via
  `build_cfg_posterior_results --sample json-context0-16`. README, reproduction,
  primary references and article describe the achieved capability/antecedents
  precisely. `make check`, eight focused tests, Rust/FFI format/Clippy, 41 Lean
  statements/canonical example and old/new article artifact checks pass.
  Existing 3,683 scientific hashes and EPIC production remain unchanged.
  `make paper` passes the unchanged 16-page/no-overflow/reference gate; final
  PDF is visually reviewed, including all new method/timing-table pages.
  External syntax cases occupy one small archive with every original hash and
  license; no old suite or model weights/logits committed. New source has no
  dependency changes. Full prior proof sources and negative observations stay
  available. Precise commands/results/limits: `docs/evidence/m34-result.md`.

## M33 — Further reduction of owned code

Authorized by the request to reduce further while leaving external EPIC alone.
Depends on M32. Keep the existing mathematical/input/status contracts, live
independent certificate validation, original probabilities, finite slots and
serial/EPIC/exact integration. Do not alter the pinned baseline, Lean sources,
archived scientific outcomes or recreate a test suite.

- [x] T3300: Remove remaining retired comparison/campaign layers and duplicate
  byte-lattice implementation; route current oracles to the existing validated
  solver result instead of a second benchmark result hierarchy. Keep strict
  JSON helpers without the obsolete evaluation package.
  **Acceptance:** active consumers import/build and verify actual certificates;
  finite-byte/EOS/PAD handling remains in the production EOS lattice; baseline
  files and scientific artifacts retain their hashes.
  **Evidence:** obsolete comparison result/selector hierarchy, byte-only lattice,
  unused enumerators/graph indices and fresh-campaign/metadata layers removed.
  Conflict/probability consumers use `solver.solve_state` and `SolveStatus` with
  the unchanged live independent validator. `make check` passes (54 modules),
  all retained/baseline/binding imports work, Python/Rust agree on the real
  geocoding state, and its budget-2 certificate is identical to pre-cleanup and
  independently verifies. Eight-query probability API output verifies against
  the original saved input and honestly remains incomplete. `make
  article-results-check` preserves all 3,683 scientific hashes/35 M31 checks;
  external EPIC/formal source diffs are empty. Details: `docs/evidence/m33-runtime.json`.
- [x] T3301: Update maintained command/documentation surface and record exact
  before/after owned source counts. Keep retired producers recoverable at
  `9deb3df`; perform operational/formal/package checks without claiming a suite
  pass or new scientific results.
  **Acceptance:** reproducible checks/counts recorded, no EPIC edits, no new
  tests, old measurements/proofs retained and limitations explicit.
  **Evidence:** version 0.4, README/reproduction/tool documentation point to the
  current direct state API/offline checks and retired producers at `9deb3df`.
  Own source falls 20,705 -> 17,679 lines (14.6% additional; 78.1% from before
  both cleanups), implementation 17,798 -> 15,623 and scripts 1,892 -> 1,041.
  `make check`, `make build-rust`, pinned Lean (35 statements/canonical example),
  original-input resource/certificate checks, packaging and isolated dependency-free
  wheel verification/sampling pass. All 158 pinned upstream package files retain
  their hashes. No new/restored suite, model forward, benchmark or article result.
  Exact scope, counts, commands/hashes and limitations: `docs/evidence/m33-cleanup.{md,json}`.

## M32 — User-authorized reset of tests and code reduction

Authorized by the explicit request on 2026-10-05 to remove all tests and start
again, and to reduce implementation/experiments. This overrides the historical
requirement to retain/run the old test suite for this cleanup only. Keep exact
objectives, finite token semantics, status separation, independent certificate
checks, serial/EPIC/exact behavior, mathematical proofs and recorded outcomes.
No deleted-suite run or smoke command is a new correctness certification.

- [x] T3200: Remove all owned Python/Rust tests and obsolete differential/test
  infrastructure; exclude upstream tests from the pinned EPIC production snapshot.
  **Acceptance:** no maintained test suite/fixtures/CI test jobs remain; the
  upstream production algorithms/provenance remain unchanged; no replacement
  suite is fabricated.
  **Evidence:** all 154 owned Python test files, owned Rust test modules and
  randomized integration file are removed. EPIC's original `5b1b310` snapshot
  becomes versioned production files, with 12 upstream test files and ten
  test-only sections removed, documented by `.upstream-manifest.json`.
  `scripts/verify_upstream.sh` verifies all 158 retained file hashes;
  `make test` intentionally refuses to claim a suite pass. No new suite created.
- [x] T3201: Remove unused historical experiment implementation and narrow the
  package/export/build surface to the retained inference and certificate APIs.
  Keep one current probability campaign and its independent exact comparator.
  **Acceptance:** removed modules are absent from the installed package; retained
  imports/commands/builds work; mathematical/data semantics are unchanged.
  **Evidence:** the wheel contains only 61 retained `mwpc_exact` modules;
  `mwpc_research`, historical campaigns/oracles/repair and 87 retired configs
  are absent. One M31 campaign/config and independent exact control remain.
  `make check`, `make build-rust`, upstream `cargo check --locked`, all retained
  imports and isolated wheel installation pass. Serial/EPIC/exact configuration
  commands work, explicit exact support remains mandatory, and a real archived
  geocoding state yields an independently verified optimal budget-2 certificate.
  Own source drops from 80,752 to 20,705 physical lines (74.4%). Complete counts,
  API changes and commands: `docs/evidence/m32-cleanup.{md,json}`.
- [x] T3202: Update documentation/CI/reproduction routes; preserve immutable
  scientific artifacts and producer-code recovery via the previous commit.
  Verify imports, certificates, Rust build, Lean and packaging without a suite.
  Record an actual before/after source count, explicit exclusions and limitations.
  **Acceptance:** completed operational checks and hashes are recorded; no claim
  that removing tests establishes correctness or scientific relevance.
  **Evidence:** `make article-results-check` verifies 3,683 unchanged scientific
  files and all 35 returned M31 proofs against exact controls. The unchanged
  Lean library checks 35 universal statements and the canonical resource proof;
  no current 16-fixture regression pass or full-source refinement is claimed.
  Strict original-input resource/probability checks, real sampling and isolated
  dependency-free wheel packaging pass; sdist is 9,059,035 bytes unpacked before
  final package evidence metadata, with all 158 baseline files hash-checked.
  The updated paper compiles to 16 pages with no
  unresolved references/overflow; all pages visually inspected. Build/CI/docs
  reflect the absent suite and historical recovery at `a98ae8e`. Frozen hash
  inventory, counts, Lean/package records and precise limitations are versioned
  under `docs/evidence/m32-*`.

## M31 — Falsification audit of scientific and practical relevance

Authorized by the request to run every necessary test before claiming relevance.
Depends on M30 and its M26/M27 mathematical/checker gates. Keep all archived
measurements, baseline decoders and scientific objectives unchanged. No finite
test campaign proves universal relevance or priority. Constructed distributions
are correctness controls, never empirical model predictions. A compact exact
reference must not be renamed as an execution of FactorDLM or Dang--Ermon.

- [x] T3100: Freeze falsifiable claims, adversarial controls, complete new CPU
  canvas cohort and same-input exact-reference comparison before measurement.
  **Acceptance:** scope/premises, failure outcomes and decision criteria are
  explicit; no favorable-case selection or a promised winner.
  **Evidence:** `docs/research/m31-relevance-audit.md` fixes six falsification
  criteria and data-availability/competitor boundaries. The immutable
  `m31_probability_scaling_cpu_v1.json` crosses all six declared prefixes with
  4/8/16 slots (18 new forwards), limits 8/64, exact controls, 30-second external
  process deadlines and 2 GiB parser workers before any new prediction.
- [x] T3101: Independently audit mass, error, ambiguity/aliases, omitted support,
  sampling and reweighting across recorded seeds; test exact finite-state
  inference against exhaustive original-token enumeration and a separate JSON
  parser; reject forged evidence. Fix every observed correctness failure before
  the practical study.
  **Acceptance:** all relevant regressions pass; constructed controls include
  counterexamples to unconditional quality, exactness and scaling claims.
  **Evidence:** `.venv/bin/python -m pytest -q
  tests/exact_commit/test_probability_relevance_audit.py
  tests/exact_commit/test_mass_certificates.py
  tests/exact_commit/test_probability_provenance.py`: 94 passed in 1.80 s.
  New controls compare 19,680 byte strings with Python JSON, enumerate 6,272
  original token paths at seeds 310000--310031, and check 128 partial/exhaustive
  partitions, full/represented mass/TV/event bounds, exact sampling tickets,
  reweighting, aliases, missing-coverage refusal, zero feasible mass, forged
  envelopes and fabricated softmax. Existing ambiguity/EOS/timeout/provenance
  regressions remain intact. Ruff passes all four added/changed audit scripts
  and tests. Capture metadata now derives its forward count from the actual
  validated grid, fixing the former hard-coded six-count without changing old
  archived measurements.
  A further adversarial saved-input test rejects Boolean/float aliases of
  serialized rational numerators/denominators; the new audit reader now uses
  the existing strict rational codec. The relevant gate is 95 passed in 1.70 s.
  A tokenizer-lineage regression additionally rejects changed byte emissions
  even when original token IDs/probabilities are unchanged; the same three-file
  gate passes 95 tests in 1.71 s after this audit-reader correction.
- [x] T3102: Capture every frozen larger MDLM canvas; compare certified partial
  inference with an independent exact forward/backward reference on the same
  original probabilities. Preserve all outcomes, independent checks, disjoint
  timing/memory/provenance and immutable raw evidence.
  **Acceptance:** every configured job is recorded; exact masses bound-check
  every returned certificate; external wall-time cutoffs are not infeasibility;
  reference advantages and refusals remain visible.
  **Evidence:** official offline CPU capture and `run_probability_audit` at
  `7780d94763d146799de564b38a328f3dd4686756` retain all 18 new forwards and 36
  jobs: 8 certified, 27 incomplete, 1 external timeout, no worker errors.
  `run_probability_audit --reference-followup` at
  `bb93550c6d5754ff193a612f05d9364dfc9514ca` repeats all 18 numeric references
  with separately recorded coverage/compile/query and fresh-worker RSS; original
  reference observations are unchanged. Independent `build_probability_audit_results
  --capture results/raw/m31_probability_v1/capture` verifies all 35 returned
  proofs against true mass, source softmax/normalization and original tokenizer
  bytes; offline regeneration also passes. At 64 calls, 4/8/16-slot admissions
  are 5/6, 1/6, 0/6. The exact control solves every canvas, up to 14,082,354,344
  positive token paths, and costs 11.714--81.180 ms including coverage/compile
  and median query. It is cheaper in 35/35 returned diagnostic pairs; differing
  numeric/certificate interfaces and source reconstruction exclusions are explicit.
  Compact archive: `docs/artifacts/raw/m31_probability_v1/{primary,reference-followup}`;
  manifests `3c677037d41fa7dda5f14f22e134e0226811227ebcc94b8692e8e5237affa486`
  and `c900665d75685ed9c0c44dc529146e5955f89cc82d3812bc62729f0952770b24`.
  Full large-logit traces stay ignored locally; Git's complete rational inputs,
  tokenizer, lineage and proofs reproduce mathematics/tables offline. Commands,
  immutable config and this availability boundary are in `REPRODUCING.md`.
- [x] T3103: Generate an auditable claim-by-claim verdict, update project/article
  conclusions from measured evidence, and run complete correctness/formal,
  upstream, artifact and relevant packaging/document gates.
  **Acceptance:** mathematical validity, engineering utility, novelty and general
  superiority are distinguished; no "100% certainty" claim about relevance.
  **Evidence:** `docs/artifacts/processed/m31_probability_v1/{summary.json,report.md}`
  and generated article macros retain all cells and explicitly reject practical
  superiority on these schemas. README/reproduction/article conclusions now
  distinguish certification from performance, semantic quality and priority.
  Full Python: 1,523 passed in 134.72 s; Ruff and MyPy (108 files) pass; Rust
  parser/binding tests (24), fmt/clippy and upstream EPIC regressions (19 passed,
  4 existing skips) pass. Upstream commit unchanged. `m31-formal-checks.json`
  records 35 universal statements and 16 concrete claims plus forged-bound
  rejection; full source refinement and the older large replay timeout remain
  excluded. `make article-results-check` verifies every current/historical
  derivative and all 2,664 M29, 192 M30 and 35 M31 original-input proofs.
  Clean-freeze isolated installed-wheel smoke passes, including the unchanged
  50 MB source-archive gate (48,868,031 bytes); M31 bulk research data stays in
  Git, excluded from library distributions. The rebuilt article passes the
  unchanged 16-page/no-overflow/reference gate; all pages were rendered and
  visually inspected. Complete commands, provenance, hashes, data availability
  and scientific limitations: `docs/evidence/m31-final-checks.{md,json}`.

## M30 — Certified probabilistic commitment beyond the replay cohort

Authorized by the 2026-10-05 request to broaden the scientific search. Depends
on M26/M27 correctness and certificates, not on favorable M29 timings. Preserve
all MWPC/baselines. A separate API studies the frozen **mean-field predictive**
distribution at one dLLM step, not the model's full generative distribution.
No invented probabilities may be described as model output.

- [x] T3000: Investigate ambiguity-safe probability mass, certified support-tail
  error, and practical admission/abstention. Attribute GAD/ASAp, CARS, exact DFA
  and factor inference, and probabilistic-language counting. Freeze proofs,
  application/protocol and novelty limits before collecting new model outcomes.
  **Evidence:** `docs/research/m30-probability-certificates.md` records primary
  antecedents, four complete mathematical proofs and sharpness, declared
  mean-field/support scopes, work limits and the six-probe fresh CPU protocol
  before any new model prediction. Exact probability inference and WMC are
  explicitly established principles, rather than novelty claims.
- [x] T3001: Implement an anytime disjoint token-space partition and independent
  original-input certificate checker. Exact rational mass must count tokens once,
  preserve fixed slots/EOS/PAD and expose unresolved/omitted mass. Prove and
  exhaustively check conditional total-variation bounds, sharpness, marginal
  transport and finite-trajectory error composition. Add precise Lean scope.
  **Evidence:** `mass_certificate.py`, `mass_solver.py`, `language_coverage.py` and `probabilistic_update.py` implement independently checked rational token partitions, full/represented error bounds, strict admission and safe reweighting. Mass/kernel/coverage tests (54) and provenance regressions (2) pass, including seeds 300000–300023/300500–300501, aliases, ambiguity, EOS/PAD, zero mass, timeouts and exact trajectory controls. Full Python: 1,482 passed; Ruff/MyPy (108 files), Rust (24) and EPIC regressions (19/4 existing skips) pass. `docs/evidence/m30-formal-checks.json`: 35 audited universal theorems plus 16 concrete claims; written coupling/source-refinement exclusions remain explicit.
- [x] T3002: Demonstrate the application on new inputs and, if available, fresh
  CPU dLLM predictions. Include unresolved/rejected cases and exact controls.
  Do not call constructed probabilities empirical model results. Generate
  report/article changes from versioned evidence and pass full relevant checks.
  **Evidence:** Two immutable configs produced six fresh CPU MDLM canvases each at commits `8e891f8` and `b0ed276`, not a repeat of the 72-state cohort. `docs/artifacts/raw/m30_probability_v1/`: complete logits/probabilities, revisions/hashes and 192 original-input proofs; 51 admitted, 93 incomplete and 48 zero-mass outcomes retained. At limit 64/top-eight plus declared support, coverage admits 9/12, generic bounds 0/12. Exact specialized controls and post-hoc geometric rejection expectations remain labeled. `build_probability_results --check`, all article-product checks, isolated dependency-free installed-wheel sampling/refusal and 16-page visual PDF QA pass. Complete commands/hashes and scope: `docs/evidence/m30-final-checks.{md,json}`.

## M29 — Useful exact commitment through certified conflict learning

Authorized 2026-10-05. Depends on M26--M28. Preserve the exact rational
budgeted objective and every baseline. The new engine separates a small
proposal master problem from finite-slot CFG feasibility, with portable
infeasibility proofs and safe conflict reuse. Attribute implicit hitting sets
and branch-and-bound to their established sources. Practical usefulness must
be demonstrated on the complete existing real-state cohort, with the same
objective/support as the reference; no semantic-quality or priority claim.

- [x] T2900: Freeze the mathematical contract, prior-art boundaries and a
  same-input protocol before evaluating the new engine. Include classical
  ranked-subset enumeration and the resource DP as exact comparators.
  **Evidence:** `docs/research/m29-conflict-commitment.md` acknowledges MaxHS,
  LMHS, certifying DP, EPIC and FactorDLM, and fixes the same rational objective,
  finite-support/status/certificate scope. `m29_conflict_real_v1.json` freezes
  all 72 existing inputs, budgets 0--2, four exact methods, repetitions and
  deadlines before any evaluation of the new engine on real states.
- [x] T2901: Implement the conflict master, independent certificate checker,
  safe reuse and model-independent API. Prove exactness, termination and
  the conflict-count/oracle-call bound. Exhaustive tests must cover aliases,
  duplicates, fixed slots, EOS/PAD, infeasibility, timeout and unsafe expansion.
  **Evidence:** Independent conflict/master cover and safe two-sided reuse pass 51 exhaustive/random/alias/fixed-slot/EOS/timeout/unsafe-expansion regressions (seeds 290000–290031), the interrupted-campaign regression and 13 Lean-bridge tests including real process-tree deadline termination. Every archived optimum/infeasibility certificate validates against its original input. Full Python 1,482; Ruff/MyPy, Rust 24 and existing EPIC 19/4 skips pass. The primary rational objective and ordinary decoder/baselines remain separate.
- [x] T2902: Execute the entire frozen real-state cohort, compare exact scores
  and independently verify every certificate. Measure total solve/check time,
  oracle calls and failures separately. Retain all outcomes and producing code.
  **Evidence:** `docs/artifacts/raw/m29_conflict_v1/{primary,followup}` retain all 3,312 frozen jobs, with 2,664 independently checked original-input proofs and complete same-score/status correspondence; zero worker errors/timeouts. Primary 68 retained DP measurements plus four independently completed measurements are attributed to `e609225`/`e31b651`; two missing proof files were regenerated at `bb661366` with archived scores checked and recovery excluded from timing rows. 5,527 original-file inventory entries across five attempts verify by SHA-256; additional diagnostic logs have explicitly recorded path sanitization. Complete ablations and unfavorable nested-JSON timings remain visible in the generated report.
- [x] T2903: Add Lean proofs for the new mathematical certificate/reuse scope;
  provide a concrete runnable application and generated comparative report;
  update the article only from audited results. Run full relevant regressions
  and inspect the PDF. State precisely the achieved and unachieved advantages.
  **Evidence:** `Conflicts.lean` provides eight audited cover/exactness/transport/query-count specifications; one constructed concrete learned conflict additionally passes the resource kernel bridge. A 75-node real replay export exceeded 180 s and is explicitly recorded as unfinished, not a Lean pass, in `m29-concrete-conflicts-lean.json`. Actual geocoding saved-input `conflict_cli` solve and optimizer-free verification pass. `build_conflict_results --check`, generated six-method report/macros, 16-page article/PDF QA, full Python and relevant Rust/binding/baseline/package gates pass. No new generation accuracy or full-EPIC advantage is claimed; complete final evidence is in `docs/evidence/m30-final-checks.{md,json}`.

## M28 — Budgeted commitment on archived real dLLM states

Authorized 2026-10-02. Depends on M27 and the immutable M17/M25 model
archives. Run the new budgeted method on authentic saved model inputs, without
selecting examples by outcome or calling a replay a new end-to-end generation.
Preserve per-step `exact_on_support`, original probabilities, fixed slots,
EOS/PAD, all statuses, and independently checked original-input certificates.

- [x] T2800: Freeze input hashes and the replay protocol before evaluating:
  all 24 M17 confirmation snapshots and all 12 geocoding-v2 pre-commit states;
  budgets 0--2; both all-primary and ordinary-primary reward profiles. The
  latter excludes EOS/PAD proposals for an aligned native EPIC comparison,
  while preserving EOS/PAD support. No answer injection or outcome filtering.
  **Evidence:** `configs/experiments/m28_budgeted_real_replay_v1.json` records
  27 source SHA-256 values, complete cohort, budgets, both reward policies,
  methods and limits. `docs/research/m28-real-state-replay.md` specifies the
  comparison and timing boundaries. Eight new offline tests check 72 rebuilt
  inputs, probabilities, token-ID mappings, EOS additions, profiles, profiling
  invariance, baseline separation and timeout accounting; full Python suite:
  1,368 passed. No real-state outcome was evaluated before this freeze.
- [x] T2801: Implement and test offline reconstruction, bounded execution,
  disjoint timings, portable proofs, baseline comparisons and independent
  archive verification. Native EPIC batches require finite-support feasibility
  validation; unknown feasibility and timeouts cannot count as losing scores.
  **Evidence:** `run_budgeted_real_replay.py` reconstructs all sources with
  lossless token-ID maps, runs bounded workers and verifies portable proofs
  against source inputs. Optional profiling preserves exact results. Thirteen
  replay tests pass, including both harness-bug regressions, serial-fallback
  exclusion and full archive/derivative verification with optimizers disabled.
  Full Python: 1,373 passed; Ruff/MyPy (98 source files), Rust (24 tests,
  fmt/clippy) and existing EPIC regressions (19 passed/4 existing skips) pass.
- [x] T2802: Execute every frozen case; retain failures/timeouts and compact
  original-input certificates. Report feasible objective comparisons separately
  from model quality and historical forward times. Record exact source commits.
  **Evidence:** corrected execution at `ac0e5da9300db83adbacf2fee312bcca082d7aec`
  uses the unchanged config frozen at `7b4d7ce`. Archive:
  `docs/artifacts/raw/m28_budgeted_real_v1/completed/`; 252 method jobs over
  36 source states/two profiles, 216 independently checked certificates
  (192 optimal/24 support-infeasible), zero worker errors/timeouts. The first
  interrupted harness attempt is separately retained with its exact reason.
  `run_budgeted_real_replay.py --verify` validates hashes, source correspondence,
  all proofs/batches and complete cohort coverage without model inference.
- [x] T2803: Generate the report/table from raw results, update the article and
  reproduction instructions, run regressions and inspect the resulting PDF.
  **Evidence:** `build_budgeted_real_results.py` generates the report, summary,
  table and manuscript macros from verified raw files. Ordinary-profile gains:
  2/64 versus confidence preselection; ties in all 64 post-filter and 50 eligible
  EPIC-selector/cap pairs. Pending native serial fallback is excluded. Existing
  relaxation certifies 114/128 post-filtered batches; the report separates
  profiles and zero rewards. README/reproduction guide and article Section 8.1
  updated; `make paper` passes artifact checks, final `make -C paper` gives
  16 pages with no overflow/unresolved references, pages 10--16 visually checked.
  Source distribution excludes only the interrupted audit duplicate, retained
  in Git; final replay remains installable/reproducible offline. Full verification
  and source/artifact hashes: `docs/evidence/m28-real-replay-verification.{md,json}`.

## M27 — Certified bounds, compact token graphs, Lean and focused simplification

Authorized 2026-10-01. Depends on M26 and the preserved M25 reproduction
pipeline. Assess each proposed extension before adopting it. Maintain ordinary
MWPC, all baselines and archived negative results. Formal claims must name the
Lean definitions proved and the implementation correspondence actually checked;
Lean does not automatically verify Python, Rust, external libraries or models.

- [x] T2700: Audit the three extensions, state proofs and scope, inventory actual
  code dependencies and pin a reproducible Lean toolchain.
  **Evidence:** `docs/research/m27-certified-extensions.md` records proofs, loose-bound cases, scope and primary antecedents. AST inventory of 145 Python files/45,386 lines found duplicated artifact helpers and unnecessary epsilon normalization, but no standalone private name occurring only once. Lean 4.34.0 installed from the official release and pinned in `formal/lean-toolchain`; no external proof-library dependency.
- [x] T2701: Add independently validated exact-rational batch bounds and support
  expansion certificates, including useful handling of a feasible incumbent.
  Preserve timeout/status distinctions and verify against exhaustive oracles.
  **Evidence:** `test_budget_bounds.py`: 48 passing checks, including exhaustive token/subset optima (seeds 270000–270031), outside-support proposals, loose/zero bounds, duplicate IDs, fixed slots and EOS/PAD. New features plus artifact-regression suites: 135 passed (`python -m pytest -q` with the five M27 feature test files and `test_artifact_pipeline.py`, `test_statistical_artifacts.py`, `test_final_artifacts.py`). Exact rational values and the retained-input expansion premise are documented in `docs/research/m27-certified-extensions.md`.
- [x] T2702: Implement token-prefix sharing with original token provenance,
  EOS/PAD and exact physical budgets; prove equivalence and graph-size bounds.
  Compare both graph representations with independent completion/path oracles.
  **Evidence:** `test_compact_budget_graph.py`: 38 passing checks; seeds 270100–270131 compare both layouts with independently enumerated original completions/subsets for every configured budget. Alias/prefix closures, split UTF-8, fixed slots, EOS/PAD and forbidden unused normalization regressions pass. Eight-token common-prefix family verifies exactly `q_private=4+8l`, `q_compact=4+l` for l=2,8,32; this is graph-size mathematics, not a latency benchmark. Proof and node/emission lemmas are in the M27 research note and `formal/MWPC/Prefixes.lean`.
- [x] T2703: Bind portable certificates to their original input and validate
  token choices, fixed slots, emissions, charges and complete graph construction
  independently. Reject tampered inputs, graphs and token metadata.
  **Evidence:** `test_original_budget_certificate.py` (22) and `test_portable_budget_proof.py` (11) pass, rejecting altered rewards, deleted choices, foreign inputs, alias/EOS meanings, forged token/commitment metadata and Boolean/float aliases of integer IDs. Verification subprocess imports neither weighted optimizer. `budget_math_example.py --verify docs/artifacts/math/m27-budget-proof.json`: PASS for caps 0–3; historical M26 graph-only verification remains available with explicit narrower scope.
- [x] T2704: Formalize the mathematical specification and certificate guarantees
  in Lean without admitted proofs; check concrete project certificates through a
  reproducible bridge. Add CI and an explicit verification/trust coverage map.
  **Evidence:** pinned Lean 4.34.0 `lake build` passes; `check_formal_project.py --lake $HOME/.elan/bin/lake` checks 17 audited universal theorems and 16 concrete optimum/infeasibility claims across five profiles, and rejects an altered root bound. `docs/evidence/m27-formal-checks.json` records source/input hashes, exact denominators, version and only standard logical axiom dependencies. No admissions, native shortcuts or project axioms. Twelve bridge/export/axiom-audit Python tests pass. Mandatory CI job and `check-formal`/`check-project` targets added; `formal/README.md` explicitly excludes unproved foreign-source refinement, model semantics and the written separation/completeness proofs.
- [x] T2705: Remove proven unused code and simplify duplication without merging
  independent oracles or deleting scientific reproduction dependencies. Record
  each removal's evidence; pass full regressions, packaging and artifact checks.
  **Evidence:** `docs/evidence/m27-simplification.md` records AST-identical helper consolidation, unused normalization/duplicate checking removal, strict metadata-ID regression and preserved reproduction dependencies. Final full Python: 1,360 passed; Ruff/MyPy (98 files), production Rust (24), upstream Python (406/8 skips), upstream Rust (63/1 ignored), provenance and artifact byte checks pass. Isolated wheel verifies/generates v2 proof and exports Lean; sdist contains formal sources without `.lake`. Read-only upstream formatting failure is explicitly recorded, not hidden or "fixed" by editing the baseline.
- [x] T2706: Update the project and article from the established proofs and
  checks, build and inspect the PDF, and record reproducible final evidence.
  No slides, remote publication or new model-performance claim.
  **Evidence:** `paper/main.tex` and `budgeted-math.tex` now describe quality/support-expansion bounds, token-closing prefix sharing, original-input certification and precise Lean coverage; 37 bibliography records audited. Every manuscript data derivative verified by `make paper`; final `make -C paper`: 16 pages, no overflow/unresolved references. All 16 final rendered pages visually reviewed. Full command results, source hashes, deviations and PDF hash in `docs/evidence/m27-final-checks.{md,json}`. README/reproduction/handoff and proof coverage updated. No slides, model benchmark, remote publication or push.

## M26 — Mathematical budgeted commitment and independently checkable optimality

Authorized by the user's mathematical requirement on 2026-09-30. Depends on
M25 and the existing independently tested finite-lattice/MWPC core. Mathematical
value must follow from stated theorems, not synthetic or external win rates.
Existing measured archives and strategies remain intact. This extension has a
separate budgeted-batch objective/result; it must not relabel a subset as the
complete selected set of an ordinary MWPC certificate.

- [x] T2600: Audit the relevant prior art; state the budgeted optimization problem,
  universal comparison scope, theorem obligations and exact-arithmetic boundary.
  **Evidence:** primary-source audit in `docs/research/m26-mathematical-core.md` and the 34-record bibliography audit; rechecked EPIC, FactorDLM, weighted CFG, semiring parsing, AXON and certifying DP. Explicit objective, same-input comparison hypotheses, binary-rational semantics and incremental novelty boundaries are recorded.
- [x] T2601: Prove budgeted completion equivalence, resource-DAG dynamic programming,
  certificate soundness/completeness, universal same-input batch dominance and
  an infinite-family approximation obstruction for confidence-first/preselection.
  Include finite slots, original paths, epsilon emissions and duplicate IDs.
  **Evidence:** six complete proofs and capacity/update corollaries in `docs/research/m26-mathematical-core.md`; main lemmas/Theorems 3–7 in `paper/budgeted-math.tex`. Proof-to-code review in `docs/evidence/submission-proof-audit.md`. Both infinite separations use one fixed regular language; no model-frequency or accuracy inference.
- [x] T2602: Implement an exact rational reference optimizer and independent
  optimality-certificate checker, finite-byte token adapter and exhaustive
  differential/regression tests. Exercise pinned EPIC selection control flow
  without presenting constructed counterexamples as population benchmarks.
  **Evidence:** 98 new exact-rational/oracle/certificate regressions, including 64 recorded random seeds, split UTF-8, paid EOS/PAD, duplicate/fixed positions, feasible suboptimal witnesses, input identity and eight unchanged upstream-selector control-flow tests. Full Python 1,229 passed; Rust 24 tests/fmt/clippy and upstream 406 passed/8 existing skips. Ruff and MyPy (91 source files) pass. `budget_math_example.py` emits and independently verifies all four budget certificates offline; modes preserve ordinary MWPC contracts.
- [x] T2603: Reframe the article and project around the proved mathematical
  result, preserve all historical experiments as secondary evidence, verify
  the manuscript and produce a separate local mathematical delivery.
  **Evidence:** `docs/evidence/m26-mathematical-verification.json`: exact-rational API/proof/wheel checks and full regression gates pass; the rebuilt SBC manuscript has 16 visually inspected pages, no overflow/unresolved references, unchanged fonts/margins and 34 audited bibliography records. Core results are complete universal proofs; unchanged negative M24/M25 experiments remain secondary and prior prose/proofs remain supplementary. `dist/math-2026-09-30/` is independently bundle-verified and freshly cloned (1,007 source hashes), with portable optimality proof and all payload checksums passing. README, reproduction and separate release guides describe actual implementation/limitations; no slides or remote publication.

## M25 — External grounded calls, runnable project and final article

Authorized 2026-09-29; slides, defense script and presentation are explicitly out
of scope. Closes the remaining T2404 work without changing historical evidence.
Preserve exact_on_support, immutable fixed slots, all failures and real EPIC.

- [x] T2500: Freeze a schema/question-only external eligibility rule, family split,
  candidate grounding policy, coverage audit and primary comparison before live
  evaluation. Keep ground truth out of support construction.
  **Evidence:** `docs/research/m25-external-protocol.md`, `prepare_grounded_bfcl.py --check`, frozen configs and `docs/evidence/m25-grounding-coverage.json`: all 68 eligible cases retained (26 development/42 confirmation), 50 function-name families with no split overlap, 56 answers represented; no labels enter grounding.
- [x] T2501: Implement and test free scalar argument grounding, independent grading,
  support/length diagnostics and experiment integration; preserve M24 behavior.
  Check oracles, malformed inputs and full regression gates before timing.
  **Evidence:** full `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m pytest -q`: 1,119 passed; targeted grounding/schema/artifact suite: 30 passed; upstream integration: 19 passed/4 existing skips. Ruff and MyPy (86 files) pass. M24 campaign `--check` reproduces unchanged. `preflight_grounded_calls.py` with pinned cached tokenizer verifies all 68 catalogs and byte reconstruction (20,140 calls, at most 43 ordinary tokens within 64 slots); evidence `docs/evidence/m25-tokenizer-preflight.json`. Split-UTF-8 regression covers the corrected tokenizer boundary.
- [x] T2502: Run a bounded development pilot and frozen external confirmation with
  strong EPIC, matched greedy and catalog controls; repeat timings, archive all
  outputs and regenerate paired uncertainty and coverage reports.
  **Evidence:** independently validated development 234/234 and two frozen confirmation grids of 336/336 each; all archives under `docs/artifacts/raw/m25_grounded_v1/`. `build_grounded_campaign.py --check` reproduces 928 recorded generations/15,596 forwards including smoke and every failure, without double-counting the interrupted development prefix. Confidence reaches 5/42 versus EPIC 32's 15/42 in both repetitions; EPIC 8 reaches 16/17. Coverage is 38/42, and paired uncertainty/status/component products are generated under `docs/research/generated/m25-*`. Primary and support remain frozen; budget 64 was selected on development only. Full Python 1,130 passed; integration 19 passed/4 existing skips; Ruff/MyPy and upstream pin pass. Process ledgers and gates are recorded in `docs/evidence/m25-experiment-verification.json`.
- [x] T2503: Deliver a runnable dLLM-to-read-only-query demo with validated calls,
  explicit live/replay modes, failure handling and reproducible local evidence.
  **Evidence:** eight real LLaDA/Open-Meteo trajectories archived under `docs/artifacts/demo/`; `build_query_demo_results.py --check` independently verifies all checksums, support, finite slots, fixed positions and matched objectives offline. All four v1 queries were empty; the separately declared quote-free v2 support yields Belo Horizonte for confidence/MAP/EPIC, while budget 64 stays empty. Defaults use the correct confidence v2 recording; `run_query_demo.py --mode replay` returns the attributed saved result without model/network. Both immutable configs, process ledgers, original failures and the post-hoc limitation are preserved; scientific benchmark results are unchanged.
- [x] T2504: Update the article from versioned M24/M25 artifacts, clarify novelty
  and limitations, regenerate tables/figures, build and visually verify the PDF.
  **Evidence:** M24/M25 tables and macros generated from versioned validated archives; source hashes and generating commands in `paper/generated/m25_live_v1/sources.json`. The final SBC PDF has 16 pages, no overflow/unresolved references, and all 16 rendered pages visually inspected. Main claims preserve the scoped synthetic benefit, failed external transfer, post-hoc demo restriction and exact_on_support; proofs explicitly declare slot support/H. Bibliography has 32 audited entries including weighted CFG, max-marginals, TACG and FactorDLM. Full Python 1,131 passed; 24 article regressions pass after prose adjustment; Rust 24 tests/fmt/clippy, upstream 406 passed/8 existing skips and artifact checks pass. Evidence `docs/evidence/m25-delivery-verification.json`.
- [x] T2505: Complete clean installation/reproduction checks, project documentation
  and a local source/PDF/evidence delivery; record unresolved external limitations.
  **Evidence:** `make release-wheel-smoke` passes a fresh non-editable install outside the checkout. `PYTHONDONTWRITEBYTECODE=1 make rehearse-artifact-rebuild` at clean source `5238e7e52e12d7412168c456db1a168807cb9edc` passes all historical/M24/M25 processed and article byte comparisons and all eight query records/replay, using an independently installed wheel; the missing M24 diagnosis now rebuilds identically with Python. `dist/dllm-2026-09-30/` contains the source bundle, reviewed 16-page PDF, manifest and checksums; bundle verification, a fresh bundle clone with 171 inventory hashes and `sha256sum -c SHA256SUMS` pass. Instructions and limits are recorded in `docs/releases/dllm-2026-09-30.md`, `REPRODUCING.md` and `docs/evidence/m25-delivery-verification.json`; the local manifest identifies the delivered source. External accuracy/latency benefit and synthetic primary non-inferiority remain unestablished. Advisor review is a separate human submission step.

## M24 — Investigate structurally stable commitment for useful tool calls

Depends on M23, M22 and M19. The broad campaign is measured; margins did not
justify continuation. Simple policies show scoped cost–quality benefits.
Preserve the MWPC selected set; record the actual committed subset separately.

- [x] T2400: Specify a one-month incremental plan, prior-art boundaries, useful
  task, strong EPIC baselines, ablations, development/test separation and stop rule.
  **Evidence:** `docs/research/m24-stable-commit-plan.md`: seven primary prior-art sources, explicit counterfactual rule and proof scope, BFCL coverage gate, full EPIC recovery, simple controls, uncertainty requirements and day-7 stop rule. No new model result or novelty assurance.
- [x] T2401: Implement a small exhaustive reference for counterfactual margins
  and a separate commitment gate. Test near-optimal consensus independently,
  strict threshold ties, fixed tokens, invalid weights and unscored fallback.
  **Evidence:** `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m pytest -q tests/exact_commit/test_commit_stability.py`: 47 passed, including 40 recorded randomized seeds against independent near-optimal consensus. Full `PYTHONDONTWRITEBYTECODE=1 .venv/bin/python -m pytest -q`: 1,017 passed. `.venv/bin/ruff check src tests`, `.venv/bin/mypy` (82 source files), and `git diff --check` pass. Reference is not production integration; no runtime or semantic-accuracy claim.
- [x] T2402: Add the gate around the production solver with a common deadline,
  conservative numerical comparisons, independent certificate validation and
  explicit unknown counterfactual statuses. Preserve existing decoder defaults.
  Pass differential, full Python and relevant integration gates before timing.
  **Evidence:** `src/mwpc_exact/commit_gate.py` reduces each counterfactual to a non-negative bonus query on unchanged support, including EOS/PAD; proof in M24 plan. 67 targeted tests (Python/Rust oracle comparisons, duplicate matches, fixed tokens, late/unknown queries and numerical ties); full pytest 1,085 passed. Ruff, MyPy (83 files), upstream pin pass; upstream integration 19 passed/4 pre-existing skips. In-process official recovery CPU test passes. No new solver timing claimed before frozen live run.
- [x] T2403: Freeze and commit a bounded live development pilot with confidence
  and budget controls and full EPIC recovery timed together. Audit external BFCL
  coverage without gold-based support. Archive every result; apply day-7 stop rule.
  **Evidence:** `docs/research/m24-findings.md`, immutable archives under `docs/artifacts/raw/m24_policy_v1/`, and generated campaign inventory: 40 smoke + 600 development calls; 320 external pilot calls plus 96 secondary external controls, all retained. All 11 original development errors exclude a representable answer while the objective prefers a wrong completion. Schema-only BFCL audit selects all 8 eligible cases out of 658; MAP is best on this narrow external subset. Day-7 rule applied: stop margins as the principal extension; retain confidence/budget policies. Complete verification commands and outcomes in `docs/evidence/m24-policy-verification.json`.
- [x] T2404: If pilot supports continuation, freeze primary comparison, uncertainty
  analysis and disjoint external test before measurement; generate paired results,
  a runnable read-only API demo and an evidence-grounded manuscript update.
  **Evidence:** 2,800 confirmed/secondary synthetic generations on 100 new requests, two repetitions, actual EPIC 2/4/6/8/12/24 and matched greedy/MAP controls. Frozen primary confidence 0.8 is faster than EPIC 24, but two-point accuracy non-inferiority remains unestablished. Budget four beats EPIC eight in observed accuracy at similar cost, including a whitespace sensitivity analysis. M25 closes the remaining external/demo/manuscript work: all 68 schema-eligible external cases split by function family (26 development/42 confirmation), two frozen 336-generation confirmation grids, independent grading/coverage/uncertainty, eight real read-only query recordings and the rebuilt 16-page article. External confidence is worse than EPIC 32 (5/42 versus 15/42 and slower); original failed queries and the post-hoc application restriction remain recorded. Clean wheel-based artifact reproduction and local source/PDF delivery pass in T2505. Evidence in `docs/research/m25-findings.md`, `docs/evidence/m25-delivery-verification.json` and `docs/releases/dllm-2026-09-30.md`. No claim of novel confidence decoding or universal superiority.

## M23 — Compare the tool task with the actual EPIC decoder

Depends on M22 and the M19 fairness audit. Preserve the pinned upstream source,
MWPC finite-support guarantees, answer-independent languages and all failures.

- [x] T2300: Test an adapter that runs upstream EPIC with regular-cover selection,
  DFA-free checking and caching enabled. Freeze native-vocabulary and explicitly
  domain-restricted variants, two parallel reveal schedules plus the 24-step control, identical prompts,
  model, language, slot/forward/time limits and a bounded pilot.
  **Evidence:** 18 targeted CPU tests and full suite 952 passed; native selector executes batches; language equivalence and structural grading pass. Pilot commit `2067ec3`, all 25 outputs preserved in `docs/artifacts/raw/m23_epic_tools_v1/pilot`. `docs/research/m23-epic-protocol.md` records the pre-confirmation whitespace correction and schedule control; upstream source unchanged.
- [x] T2301: Run every variant on the same frozen 100 M22 requests, with MWPC
  rerun in rotated order; repeat with reversed order. Preserve native EPIC events,
  rejection counts, selector calls/errors, actual forwards, timing and statuses.
  **Evidence:** 2,425 live generations including the 25-call pilot; source `657bbc4` / `aa1b14d`; both byte and lexical representations, native and masked vocabularies, schedules 1/2/4/24 where declared. All 100 requests retained, twice; outputs/status/forwards stable. Immutable archives under `docs/artifacts/raw/m23_epic_tools_v1/`; 20 targeted tests, upstream pin and artifact semantic checks pass. The decoder-only result is not the full EPIC baseline: T2302 must include official wrapper recovery.
- [x] T2302: Generate validated paired results and correct the current research
  claims. Explain support, confidence normalization, completion and scheduling
  differences; do not identify upstream EPIC with the matched greedy selector.
  Run full Python and relevant upstream checks, and archive reproducible evidence.
  **Evidence:** official `autocomplete_valid` replay at `9acda68`: 496 recoveries on saved states, 2,000 EPIC records, no new model forwards; independently checked fixed fragments and all effective calls. Generated byte/lexical/recovery reports and `docs/research/m23-findings.md` correct the full-pipeline comparison, including higher EPIC accuracy and nondeterministic fallback choices. `docs/evidence/m23-epic-verification.json`: 970 Python tests, Rust 24, upstream 406 passed/8 skips, Ruff/MyPy, upstream pin and all three artifact `--check` gates pass. README and research scope updated; PDF remains the prior historical version.

## M22 — Find an end-to-end dLLM benefit and check a bounded held-out cohort

Depends on M21 correctness and the M19 comparison audit. Keep repair secondary.
Preserve the per-step MWPC objective, named finite support, independent witnesses,
and all unsuccessful trials. Do not encode prompt answers in the grammar.

- [x] T2200: Freeze and test a small live-model screening protocol with an
  answer-independent tool language and matched confidence-greedy/exact selection.
  Use enumeration only as an explicitly named screening oracle, not the production
  CFG solver or EPIC. Record complete trajectories, versions and timing.
  **Evidence:** `docs/research/m22-dllm-discovery-protocol.md`; six new oracle tests, full pytest 935 passed; targeted Ruff and `git diff --check` pass. Frozen v1 config and opt-in live driver; no positive model result claimed by this task.
- [x] T2201: Run the screening with pinned LLaDA weights; retain every prompt and
  failure. Check functional outputs, ordinary-token gains and model evaluations.
  Separate an exploratory discovery from held-out confirmation.
  **Evidence:** four frozen development configs/producing commits; 456 real-model generations archived under `docs/artifacts/raw/m22_dllm_discovery_v1/screen_v{1,2,3,4}`. All neutral/negative trials retained. Operand-preserving v4 has one correctness win and one loss; ordinary proposals and EOS/PAD are separately counted. `summarize_tool_screen.py` rechecks complete trajectories and task outcomes.
- [x] T2202: If screening identifies a benefit, validate the mechanism with the
  production parser and compare relevant baselines on a frozen held-out cohort.
  Otherwise document the exact failure and next bounded experiment; never mark
  practical benefit established based only on selection scores.
  **Evidence:** producing commits `108309e` / `9d4e8e3`, frozen 100-request confirmation plus reversed-order repeat, 400 live generations, Rust byte CFG and independent certificates. Exact 65/100 vs witness-reusing greedy 63/100 in both runs; 205 forwards each; median paired speed ratio 2.13 on 63 jointly correct requests. Two new functional wins, no losses in confirmation; no EPIC/general-accuracy claim. Generated report `docs/research/generated/m22-results.md`; verification `docs/evidence/m22-dllm-verification.json`: 947 Python tests, make check, Rust 24, upstream 406 passed/8 skips, archive/semantic corruption gates and reproducible report pass.

## M21 — Certified JSON repair and a bounded comparative pilot

Depends on M20. Implement the chosen idea and measure a useful, explicitly scoped
case; do not promise population superiority or suppress unsuccessful repairs.

- [x] T2100: Implement model-independent protected token-slot repair and a useful
  JSON CLI. Check substitution optimality with independent exhaustive examples,
  both parser backends, token/byte provenance, locks, invalid inputs and deadlines.
  **Evidence:** `make check` and full pytest pass (921 tests); Rust parser 24 tests; upstream 406 passed/8 skips. New repair tests cover independent enumeration, Python/Rust, whole-token locks, grammar language preservation, late results, input validation and profiler invariance.
- [x] T2101: Freeze a controlled development/confirmation protocol with unmodified,
  substitution and out-of-support errors; compare no repair, json_repair default
  and schema modes, witness-reusing greedy, and bounded minimum-edit enumeration.
  Include real-tokenizer coverage, common evaluation and all statuses. Keep
  semantic target out of support/grammar construction. Lock dependencies.
  **Evidence:** `docs/research/m21-repair-protocol.md`, three frozen M21 TOML configs, optional pinned json-repair 0.63.5, schema standard/salvage, enumeration and single-feasibility controls. No model-generation result is claimed.
- [x] T2102: Commit tested source/config locally before measurement; run and archive
  the pilot plus held-out controlled confirmation, preserving failures. Generate
  tables and paired comparisons; report any measured advantage with its domain,
  comparator, tradeoffs and uncertainty. Real-model/retry evidence is separate.
  **Evidence:** clean producing commit `47b93c4`; 384 pilot + 3,840 confirmation + 768 mechanism calls archived with hashes in `docs/artifacts/raw/m21_repair_v1/`. `build_json_repair_results` verifies every cell/output and generates all comparisons. Full findings, including weaker classes and baseline ties, are in `docs/research/m21-findings.md`.
- [x] T2103: Deliver a runnable example, reproduction commands and scientific
  interpretation; run full Python and relevant Rust/baseline/artifact gates.
  Update the manuscript only for supported results, with producing source/config.
  **Evidence:** `docs/evidence/m21-repair-verification.json`; full pytest 929 passed, `make check` (14 unit/895 exact + Ruff/MyPy), Rust 24 tests and upstream 406 passed/8 skips, all artifact gates and isolated release-wheel smoke passed. CLI example returns a validated one-substitution repair. `make paper`: 16 pages, no overflow/unresolved references; rendered pages inspected. Reproduction and local delivery instructions are updated. No real-model/retry or general-superiority claim.

## M20 — Close the September audit and plan useful exact decoding

Depends on M19. Preserve existing objectives, finite-support exactness, baseline
defaults and immutable historical measurements. This milestone fixes the reviewed
software/delivery issues and designs new research; it does not claim new model results.

- [x] T2000: Enforce the greedy selector's final total deadline, including paths
  that reuse witnesses or make no final parser call. Add deterministic regressions
  for both backends and verify in-budget decisions remain unchanged.
  **Evidence:** `tests/exact_commit/test_selection.py`: 42 passed; before-fix regression reproduced; deterministic Python/Rust late results now TIMEOUT without certificate.
- [x] T2001: Verify every M19 manuscript derivative in the article/CI gate;
  exercise corruption detection without modifying archived evidence.
  **Evidence:** `make article-results-check` verifies M13/M17/M19. Seven artifact tests pass, including six missing/corrupted derivative cases; CI gate added.
- [x] T2002: Add the closest weighted-intersection/epsilon and parallel-selection
  references, focus the manuscript on current evidence, and restore the recorded
  16-page limit without changing template fonts/margins or concealing failures.
  Compile, check references/page count and visually inspect the PDF.
  **Evidence:** `make paper`: 16 pages, no undefined references or overfull boxes; all pages visually checked. Four primary-source references added; historical detail retained in supplement; compiled-PDF gate tested.
- [x] T2003: Specify a prioritized scientific plan with a useful target task,
  testable mechanisms, fair baselines, ablations, development/confirmation splits,
  costs, measurable success criteria and stopping rules. Distinguish planned work
  from implemented/proven/measured results; freeze new configs before measurement.
  **Evidence:** `docs/research/2026-09-28-json-repair-plan.md`: four-week repair protocol, five comparators, no unrestricted edit-distance/semantic guarantee, development/confirmation separation and day-7 stopping rule.
- [x] T2004: Align current setup/reproduction instructions and a new local delivery
  containing the reviewed source, PDF and evidence; preserve historical releases.
  Run full Python, relevant Rust/binding/baseline, artifact and packaging gates.
  **Evidence:** `docs/reviews/2026-09-28-resolution.md`: 885 Python tests, 24 Rust tests, 406 upstream tests (8 skips), Ruff/MyPy, artifact, PDF and wheel gates pass. `dist/review-2026-09-28/` contains base bundle + patch + 16-page PDF + evidence/manifest/checksums. Fresh checkout applies patch, matches 26 file hashes, regenerates artifacts and passes 54 targeted tests. No commit/tag/push performed.

## M19 — Audit the practical-benefit claim

Depends on M18. Preserve baseline defaults, the same proposal objective and
finite supports, independently validated witnesses, and immutable prior results.

- [x] T1900: Audit timing boundaries, censoring, EOS/PAD contributions and
  functional meaning; test a greedy variant that reuses its valid witness.
- [x] T1901: Freeze and rerun all 24 confirmation states, K=2/4/8 and
  budgets=2/8/32, three rotated-order repetitions, original greedy, witness-reuse
  greedy and exact. Use a common ten-second total-selection limit and retain
  every status. Report absolute times and paired wins/losses, not just ratios.
- [x] T1902: Correct manuscript/report claims to match the audit and verify
  the generated evidence. Keep the implementation small and leave LAVE untouched.

**Evidence:** T1900: 842 Python tests, 24 Rust tests, Ruff and MyPy pass.
Forty recorded seeds per backend preserve greedy decisions with fewer parser
calls; an injected clock rejects an exact result that exceeds the whole-call
deadline. M18's unique score-gain case includes 23 EOS/PAD matches in each
method and only 8 versus 7 ordinary proposal matches; both witnesses fail the
prompt. M18's exact native-parser deadline differed from greedy's total deadline,
although no old exact call exceeded one second. T1901: 1,944 completed calls
from frozen source/config `196d48c`, no timeout/error. Both greedy variants
agree on all 648 statuses and all 540 feasible selections. Ratios against
witness reuse: 0.96–1.00 (budget 2), 1.71–2.05 (8), 2.35–3.82 (32).
No replay witness passes the functional task checker. Raw records and generated
analysis: docs/artifacts/raw/m19_selection_audit_v1 and
paper/generated/m19_selection_audit_v1. T1902: assertions corrected in the
manuscript and docs/reviews/2026-09-22-selection-audit.md; old measurements retained.
All archive/config/input hashes and generated values reproduced; PDF built at
18 pages without overfull boxes or undefined references, with changed pages
and their neighbors visually inspected. Final full Python suite: 842 passed.

M18 follows the request for a practical use and less experimental scaffolding.

## M18 — Bounded practical selection and smaller maintenance surface

Depends on M17. Preserve exact_on_support, positive proposal matches, independent
certificates, fixed slots and all baseline tests. LAVE remains out of scope.

- [x] T1800: Remove repeated token-validation work without weakening input
  checks; retire superseded measurement launchers, retaining their immutable
  v0.2.0 source and current artifact reconstruction. Run correctness gates.
- [x] T1801: Compare simultaneous MWPC against sequential exact feasibility
  on every saved confirmation snapshot, K=2/4/8, budgets=2/8/32, three repeated
  timings with alternating order. Use saved top-permitted-token probabilities,
  common supports/proposals and no answer injection; retain all failed cases.
- [x] T1802: Generate a source-linked report with paired timing and score results,
  distinguish selector utility from end-to-end gains, and report net code reduction.

**Evidence:** T1800: full pytest 838 passed; Ruff and MyPy (78 files) pass;
`make test-rust-parser` passes 24 tests, formatting and Clippy; archived review
results reproduce with `build_review_results.py --check`. No baseline tests
removed. The three retired measurement CLIs remain at v0.2.0; REPRODUCING.md
documents a separate worktree for their historical executions. T1801/T1802:
1,296 runs from committed config/source `3d573b2`; every confirmation state
retained. Raw records in docs/artifacts/raw/m18_batch_selection_v1, regenerated
analysis in paper/generated/m18_batch_selection_v1. One real-state score gain
confirmed by both independent solvers; all paired negative gaps are zero.
Final suite: 839 Python tests; unchanged Rust/baseline gates as above. Article
built and visually checked at 18 pages. Net code reduction: 705 lines versus
a309b1c. Commands, scope and outcomes:
docs/reviews/2026-09-22-practical-selection.md.

## Previous submission

M17 closes the 22 September review, except LAVE as requested. That historical local
submission is v0.2.0; verification is in docs/evidence/m17-review-verification.json.

## M17 — Review closure and local submission release

Preserve all historical evidence, finite-support exactness and baseline source.
Complete T1700 before new model/performance experiments. T1701 also closes the
remaining live-evidence work in T1603; T1703 closes T1604 when its gates pass.

- [x] T1700: Bound sparse-chart work and classify every late conclusive Rust
  result as TIMEOUT; add deterministic regressions and rerun correctness gates.
- [x] T1701: Freeze and run matched-budget, nonliteral live pilot/confirmation,
  pre-commit ranked-support replay, and recursive resource scaling. Retain all
  failures and statuses; use committed code/configs and independent checkers.
- [x] T1702: Correct normalized-DAG pseudocode and token-level H composition;
  add a worked example; revise abstracts, result interpretation and table layout.
  Keep LAVE outside the requested changes.
- [x] T1703: Align a new local release, manuscript and reproducible evidence;
  run complete tests, packaging/artifact and clean-checkout gates. No remote push.

**Evidence:** Timeout regressions and 1,500 M5/M6/M7 oracle cases pass. New raw
measurements are in docs/artifacts/raw/m17_review_v1; producing commits and
derived outcomes are in paper/generated/m17_review_v1/summary.json. See
docs/reviews/2026-09-22-resolution.md for commands and final release gates.

## Previous starting point

M0 through M13, including the M10.5 hardening pass and M12.5 review-fix gate,
record the completed release baseline. **M14 review hardening and M15
behavior-preserving simplification are complete.**
M16's CPU and live studies are complete; final submission gates are tracked in M17.
Optional O1--O4 remain outside the required scope.

## M16 — Nontrivial scientific evidence

Depends on M15. Preserve the scientific contract, independent oracles, pinned
baselines and all historical artifacts. Strong evidence means discriminating,
reproducible tests of explicit hypotheses, not necessarily positive results.

- [x] T1600: Freeze a bounded protocol, grammar families, seeds, controls,
  analysis units, resource limits and stopping rules before experiments.
- [x] T1601: Implement recursive multi-output tasks with independent syntax
  and functional checkers. Check grammar/checker agreement exhaustively on
  small inputs and against the existing Python/Rust certificate oracles.
- [x] T1602: Run paired branching-support studies with oracle optima,
  full status accounting, support-sensitivity and cost/gap measurements.
  Keep generated cases distinct from real-model states.
- [x] T1603: Capture real model states without a known-answer support token;
  compare common supports and evaluate nonliteral end-to-end tasks, retaining
  failures and measuring functional quality separately from syntax/runtime.
  - Resolved by M17: GPU became available; both pilots and disjoint confirmation
    completed, and all saved-state replay conditions were retained.
- [x] T1604: Generate source-linked analyses; rerun correctness, baseline,
  packaging and artifact gates. Update manuscript claims only from committed
  code/configs and immutable raw evidence. No broad superiority claim without
  supporting measurements.
  - Resolved by T1703: local source checkpoints, immutable measured evidence,
    both clean-checkout gates and the revised manuscript are complete.

**Evidence:** Prospective design in ADR 0023; 817 Python tests, 22 Rust tests,
strict MyPy (75 files), Ruff, format/Clippy, isolated wheel/sdist and preserved
baseline/artifact checks passed. The 1,200-condition study covers 300 family/seed
states sharing 100 seed clusters: both exact backends agree with exhaustive
independent completion checks, with no failed certificates. The complete
generated report is `docs/evidence/m16-branching-development-v2/report.md`.
Commands, immutable raw paths, interpretation and remaining gates are in
[`docs/m16-scientific-evidence.md`](docs/m16-scientific-evidence.md).

## M15 — Behavior-preserving simplification

Depends on M14. Preserve exact-on-support objectives and certificates, status
and timeout distinctions, independent reference algorithms, baseline decoders,
profiling semantics, and all versioned evidence. Add no dependency or framework.

- [x] T1500: Remove duplicated profiled/unprofiled execution paths and manual
  immutable-record copying. Keep disabled profiling clock-free and retain all
  enabled component boundaries and counters.
- [x] T1501: Consolidate identical serialization helpers, remove unused private
  arguments, and verify full tests, type/lint checks, packaging and artifacts.

**Evidence:** 192 net implementation lines removed across nine Python files,
with four additional regression cases. Full Python suite: 771 passed; Rust:
22 passed. Ruff, strict MyPy (73 files), Rust format/Clippy, isolated release
wheel/sdist rehearsal, baseline tests (19 passed, 4 upstream skips), upstream
pin and existing artifact checks passed. Commands and scope are recorded in
the M15 section of [`docs/review-hardening.md`](docs/review-hardening.md).

## M14 — Repository review hardening

Depends on the M13 release baseline. Preserve published raw inputs and derived
artifacts; new correctness evidence does not retroactively update measurements.

- [x] T1400: Bind commit authority to frozen inputs, correct EOS completion,
  report missing support validation, and guarantee sampler cleanup. Every
  reported failure has a minimal regression.
- [x] T1401: Preserve exact ordering of represented proposal sums despite
  floating-point rounding; retain float/f64 public scores and independent
  Python/Rust algorithms. Pass adversarial and exhaustive differential gates.
- [x] T1402: Exclude build artifacts from sdists, inspect both release archives,
  and pin development/EPIC environments and the Rust toolchain.
- [x] T1403: Consolidate duplicated non-algorithmic helpers and orchestration,
  remove unused code and brittle prose checks, and eliminate unnecessary
  normalization, parsing, validation, and model-adapter work. Document and test
  correctness of any skipped work.
- [x] T1404: Run full Python, Rust, binding, baseline, packaging and artifact
  gates; document remaining empirical limits and exact reproduction commands.

**Evidence:** 767 Python tests; 22 Rust tests; lint/type/format/Clippy, wheel/sdist
rehearsal, pinned baseline and artifact checks passed. Each normal M5/M6/M7
campaign passed 500 cases. Commands, numerical/skipped-work proofs, limitations
and the finding-to-regression mapping are in
[`docs/review-hardening.md`](docs/review-hardening.md); new summaries are in
`docs/evidence/review-hardening/`. Historical campaign summaries remain unchanged.

## Completed milestone summary

- **M0--M7:** pinned baseline, formal contracts, Python/Rust exact parsers,
  exhaustive gates, tokenizer-aware finite lattices, and EOS/PAD exactness.
- **M8:** proposals, adaptive support, typed validation/commit authority,
  fallbacks, profiling, and offline exact-step integration.
- **M9:** pinned LLaDA integration, baseline preservation, saved-logit loop, and
  one live correctness smoke.
- **M10:** shared frozen selector input, precise baseline adapters, guarded brute
  force, and versioned replay artifacts.
- **M10.5:** compact ranked support, pinned-EPIC integration CI, total selector
  deadlines, precise component-selector names, fair candidate-universe checks,
  executable exact/EPIC grammar alignment, and evaluation-package cleanup.
- **M11:** immutable experiment configs, Q1--Q5 drivers, and component
  timing/memory instrumentation.
- **M12:** run metadata, raw/processed/paper separation, statistical summaries,
  deterministic generated artifacts, and reproduction instructions.

See `docs/evidence/`, `docs/decisions/`, and the archived checklist for exact
commits, commands, configured-case boundaries, and result counts.

---

# M11--M12 — Completed experiment and artifact milestones

M11 and M12 are complete. Their full task definitions, acceptance criteria,
commands, and evidence are archived in
[`docs/history/TASKS-through-M12.md`](docs/history/TASKS-through-M12.md).

- **M11 / T1100--T1106:** immutable experiment configuration; executable Q1
  correctness, Q2 heuristic-gap, Q3 finite-slot, Q4 scaling, and Q5
  end-to-end drivers; and component timing/memory instrumentation.
- **M12 / T1200--T1204:** run metadata; raw/processed/paper separation;
  statistical summaries; the deterministic T1203 Q1--Q5 bundle; and
  reproduction instructions.

Stable entry points are `configs/experiments/`, `docs/evidence/t110*.json`,
`docs/artifacts/raw/t1203_final_results_v1/`,
`docs/artifacts/processed/t1203_final_results_v1/`,
`paper/generated/t1203_final_results_v1/`, and `REPRODUCING.md`. The T1201
and T1202 outputs remain internal validation fixtures. The T1203 name
`final` denotes deterministic artifact-build output, not publication-level
benchmark status.

---

# M12.5 — Review fixes before article writing

This milestone addresses the twelve findings from the post-M12 review. It must
not redesign the parser, certificate model, finite-support representation, Rust
backend, or decoder integration. Preserve serial and EPIC as baselines, keep
the existing diagnostic raw evidence immutable, regenerate derived artifacts
only through their scripts, and add no new generic experiment or artifact
framework. A publication-scope decision may restrict claims or require
additional runs, but it may never relabel existing diagnostic evidence.

## T1250 — Package and smoke-test the research modules

**Depends on:** M12 gate

**Review finding:** 1 — the release wheel omits `mwpc_research`.

- [x] Include both `src/mwpc_exact` and `src/mwpc_research` in the wheel.
- [x] Build the sdist and wheel with the locked project build toolchain.
- [x] Inspect the wheel contents so an editable checkout cannot mask omissions.
- [x] Install the wheel into a new isolated environment and import both packages.
- [x] From that wheel-installed environment, run one small experiment and one
  artifact-generation smoke without importing either package from the checkout.
- [x] Add a deterministic release-packaging regression test or CI command.

**Acceptance criteria**

- [x] A non-editable wheel install exposes `mwpc_exact` and `mwpc_research` and
  completes both smokes without `PYTHONPATH` or source-tree leakage.
- [x] The release test fails if either package is removed from the wheel.

**Evidence:** implementation commit
`2c3092ef2d34c6535c02afb8177d289f412781af`; `make
release-wheel-smoke` from that clean commit built the sdist and wheel with
`build==1.3.0` and `hatchling==1.27.0`, installed the wheel with `--no-index
--no-deps` into a new temporary environment, and found 50 `mwpc_exact` plus 17
`mwpc_research` Python files. Both imports resolved inside the temporary
site-packages directory rather than the checkout. The installed wheel then ran
the two-case Q3 experiment with zero failures and created the T1202 statistical
artifact with pinned SHA-256
`40b236f2e5988eca6ccdbe9aa2cb22b5df4cda087dfea34bade4f19f6e34a776`.
`python -m pytest -q tests/unit/test_package_boundaries.py
tests/exact_commit/test_reproduction_instructions.py` -> 5 passed; `make check`
-> upstream pin verified, Ruff and strict MyPy clean, 10 unit and 594 exact
tests passed. The same wheel rehearsal is a required `project-checks` CI step.

## T1251 — Correct the Q1 agreement presentation

**Depends on:** T1203

**Review finding:** 4 — confidence intervals are attached to fixed case sets.

- [x] Report canonical agreement as an exact numerator/denominator only.
- [x] Report the complete configured exhaustive family as an exact
  numerator/denominator only.
- [x] Keep a Wilson interval only for the randomized-seed family and describe
  the generator and seed distribution to which it applies.
- [x] Report the mixed overall configured total as an exact count with no
  confidence interval.
- [x] Regenerate the Q1 processed result, table, manifest hashes, and tests from
  the pinned raw rows; do not hand-edit generated values.

**Acceptance criteria**

- [x] No canonical, exhaustive, or mixed deterministic/random row has a
  probabilistic confidence interval.
- [x] The randomized interval remains formula-tested and traceable to raw rows.

**Evidence:** implementation commit
`84ec0f4244a6db9a21d028536599bba9975f5f6f`; the unchanged 249-row Q1
input retains SHA-256
`62fb83b48c8809a3958df486b387e017ba245e97e4e74e475ca1fb55659ade8a`.
`make final-artifacts-check` from that clean commit byte-verified
`final-results.json` at
`b72d6fd08429e3eb3c18fca4e5788a4fe3617a62a1972deedd6801cd176884d0`,
the manifest at
`06e9e8d86441b4f35a0fb863654b797081a62608ea729e7bab3dc870ea2f369f`,
and the correctness table at
`119fd38aeec70ef870941fe13a528a62170bb8e20bebf5f0b0842033e2fdad7b`.
The table reports `5/5`, `144/144`, `100/100`, and `249/249`; only the
randomized row has a 95% Wilson interval and it records the generator plus 100
unique consecutive seeds 1101--1200. `python -m pytest -q
tests/exact_commit/test_q1_correctness.py
tests/exact_commit/test_final_artifacts.py
tests/exact_commit/test_t1203_evidence.py` -> 15 passed; `make check` -> 10
unit and 595 exact tests passed; full `python -m pytest -q` -> 615 passed;
`make paper` -> 15 pages.

## T1252 — Freeze the evidence tier and allowed article claims

**Depends on:** M12 gate

**Review finding:** 2 — reproducible diagnostic results are not automatically
publication-level experiments.

- [x] Record a versioned decision stating whether M13 targets a preliminary
  article with diagnostic evidence or a final article with new publication-mode
  runs.
- [x] Inventory, per Q1--Q5, what the current evidence supports and what it does
  not support.
- [x] Keep every existing `publication_mode=false` run classified as diagnostic.
- [x] If publication-mode runs are selected, define immutable configs, minimum
  metadata, stopping/resource rules, and a new artifact bundle ID before runs.
- [x] Record that the preliminary-evidence branch was not selected; broader
  claims remain blocked until the predeclared publication runs pass.

**Acceptance criteria**

- [x] Every planned M13 empirical claim maps to an evidence tier and artifact;
  unsupported claims are explicitly excluded.
- [x] No existing smoke or diagnostic is renamed or promoted to publication
  evidence.

**Evidence:** decision/config commit
`d454f922aca7b90565e44e8cb1c25562fc5924a4` records the final-article choice,
Q1--Q5 claim matrix, metadata requirements, and stopping/resource rules in
[`docs/decisions/0016-publication-evidence-tier.md`](docs/decisions/0016-publication-evidence-tier.md).
The predeclared Q2, Q4, and Q5 config hashes are respectively
`5e950bf7bd71a537a40ee50c282c30fd9d54a260933e53e2f17cce8cdc3bb5a3`,
`265f812036df651bab9c585a8c95a496f5ab27f9ab0c073e56ff35897320cfa7`,
and `ef6500bea33bf50a1b0ca112f3e1086f0f1f7c804dd49a86868705da1132b004`.
All use `publication_mode=true` and reserve `m125_publication_results_v1`;
tests also verify that the six existing full configs remain diagnostic and
that the old bundle ID is not reused. `python -m pytest -q
tests/exact_commit/test_publication_evidence_policy.py
tests/exact_commit/test_experiment_config.py` -> 18 passed; `make check` -> 10
unit and 599 exact tests passed.

## T1253 — Exercise genuine EPIC parallel commitment end to end

**Depends on:** T1105, T1106, T1252

**Review finding:** 3 — the current Q5 EPIC rows only exercise serial fallback.

- [x] Add one small structured task with at least two ordinary content tokens.
- [x] Feed exact and EPIC comparable candidate states and record their
  comparison fingerprint.
- [x] Require `regular_cover_selector_calls > 0` and at least one EPIC selected
  batch of cardinality greater than one.
- [x] Independently check the output and preserve exact-result certificate
  validation and `exact_on_support` reporting.
- [x] Keep the existing single-token task, but label its row as an EPIC-enabled
  decoder with serial fallback rather than evidence of EPIC parallel speed.
- [x] If T1252 selects publication-mode evidence, run at least two nontrivial
  structured tasks in the new Q5 campaign; otherwise classify this addition as
  integration evidence rather than a representative benchmark.
- [x] Add a regression that fails if the new EPIC task silently falls back for
  every selection.

**Acceptance criteria**

- [x] Versioned raw evidence proves that the regular-cover selector ran and made
  at least one parallel commitment on independently valid output.
- [x] Serial, EPIC, and exact remain distinct strategies with comparable inputs;
  fallback counts are reported rather than hidden.

**Evidence:** implementation commits `7bb73c3`, `9c4278f`, `3cc34e0`,
`6914b96`, and `b4a8ffd` add structured task manifests, multi-byte literal
grammars, task/seed comparison fingerprints, Rust-regex-safe EPIC literals,
repeated exact steps, independent output checks, hard EPIC execution gates,
and the old single-token fallback label. ADRs 0017--0019 preserve the rejected
v1--v3 pilots and explain the v4 choice without promoting failed runs to
evidence. The accepted immutable v4 config has file SHA-256
`0c7afd505e2dc1330d7d917f2dda0369a4033f7c43825967b3eeb04661b747a7`
and normalized SHA-256
`6318a4c2810ac7926806ceda86ad4b013146f4d27f879cbb5ab7dfb7b08a28c4`.
Six clean CUDA commands ran fenced JSON and `ADD 0 0` DSL tasks at seeds
125301--125303, ten repetitions and four strategies each, from producing
commit `b4a8ffde4cc2aabc61844a955ce98933ef03dfb9`. The resulting 240 versioned
raw rows are at
`docs/artifacts/raw/m125_publication_results_v1/q5-end-to-end-rows.jsonl`
(SHA-256 `8acfb789e14779c9c33c7fec50fb713194797a2a5ae1a2ad59a56f5f5e266f44`).
`python scripts/exact_commit/summarize_q5_publication.py` independently
rechecked all outputs and 60 stored `OPTIMAL` step certificates, observed 330
regular-cover selector calls total and a maximum EPIC batch of two in every
task/seed pair, and wrote
`docs/evidence/t1253-q5-publication-summary.json` (SHA-256
`700aa99e870c06704bbd98a4bd481bb2ee1c73c3dbff7843f3cca16a2b7f5ec1`).
That summary reports EPIC fallback counts per task/seed rather than hiding the
remaining serial selections. `python -m pytest -q
tests/exact_commit/test_t1253_evidence.py tests/exact_commit/test_q5_end_to_end.py
tests/exact_commit/test_publication_evidence_policy.py` -> 22 passed; `make
check` -> 10 unit and 608 exact tests passed; `make paper` -> 15 pages.

## T1254 — Separate illustrative Q2 cases from empirical gap evidence

**Depends on:** T1252

**Review finding:** 5 — three synthetic states are a useful unit experiment,
not an empirical heuristic-gap distribution.

- [x] Retain the existing six rows and classify them as illustrative canonical
  and adversarial cases.
- [x] Remove or prevent prose that generalizes their mean gap to model behavior.
- [x] If T1252 selects publication-mode evidence, collect a predeclared,
  versioned sample of saved real decoder states spanning multiple denoising
  steps and nontrivial tasks.
- [x] Replay greedy feasibility, EPIC regular cover, and exact MWPC over the same
  proposal/support snapshot for every sampled state.
- [x] Validate exact certificates independently and report selection failures,
  timeouts, and zero-optimum rows without dropping them silently.
- [x] Preliminary-only branch is not applicable because T1252 selected
  publication-mode evidence; the real-state campaign was run instead.

**Acceptance criteria**

- [x] Synthetic rows are never presented as a representative model-state sample.
- [x] Any empirical aggregate uses only the separately identified real-state
  sample and traces every row to a saved common snapshot.

**Evidence:** ADR 0020 amends the infeasible five-state-per-task predeclaration
to four genuine EPIC selector states for each of two Q5 v4 tasks and three
seeds. `env PYTHONDONTWRITEBYTECODE=1 .venv-live/bin/python
scripts/exact_commit/collect_q2_real_snapshots.py` captured 24 clean,
versioned snapshots from commit
`fc2ba5507589d41ffd482f532061323b9c756100`; the pinned snapshot corpus is
`docs/artifacts/raw/m125_publication_results_v1/q2-real-snapshots.jsonl`
(SHA-256
`443eda3bf4a7eb9d82c474fa9f0f3a9a11227779a07dc623e92c7f97c6f185b2`).
`env PYTHONDONTWRITEBYTECODE=1 .venv-live/bin/python
scripts/exact_commit/run_q2_real_state_gap.py` replayed all three selectors
from commit `5b6d9349adec9ac910c7bb0601d92d7e5de6f956`: 24/24 rows completed,
all exact certificates and objectives independently reproduced, with no
timeouts, failures, or zero optima. The pinned replay rows are
`docs/artifacts/raw/m125_publication_results_v1/q2-real-gap-rows.jsonl`
(SHA-256
`917aa8640ffea67305439d0526432f118801afee97932e0c120e26b7419386f7`)
and the summary is `docs/evidence/t1254-q2-real-gap-summary.json` (SHA-256
`dfa49cb7e9c7747475bebf89b28aedd64086f7368f1cda365a446e0c37745ec4`).
All 24 supports collapsed to one completion after proposal/target
deduplication, so the versioned interpretation is an execution/alignment
check with zero observed gaps, explicitly not a difficult-state or population
gap claim; no confidence interval is reported for the non-IID corpus. The old
six rows and generated table remain labeled configured synthetic illustrative
cases. `python -m pytest -q tests/exact_commit/test_t1254_evidence.py
tests/exact_commit/test_q2_real_gap.py tests/exact_commit/test_q2_gap.py
tests/exact_commit/test_publication_evidence_policy.py` -> 22 passed; `make
check` -> 10 unit and 617 exact tests passed; `make paper` -> 15 pages.

## T1255 — Separate Q4 smoke diagnostics from scaling evidence

**Depends on:** T1252

**Review finding:** 6 — the current two-repetition ranges cannot support broad
runtime or scaling claims.

- [x] Retain the current Q4 bundle as a CPU component smoke.
- [x] Label `graph_size_scale` as a compound graph-size setting because it
  changes represented width and token byte length together.
- [x] Prevent median/IQR claims for groups with insufficient repetitions.
- [x] If T1252 selects publication-mode evidence, use an immutable config with
  at least 10 repetitions per point (target 20 where the declared resource plan
  permits), broader slot and top-`K` ranges up to declared resource limits,
  explicit censoring/timeouts, and separate Python/Rust series.
- [x] Preliminary-only branch is not applicable because T1252 selected
  publication-mode evidence; the expanded run was completed instead.

**Acceptance criteria**

- [x] No timeout or censored row is summarized as a successful runtime.
- [x] The article cannot describe the compound graph-size setting as an isolated
  causal variable or the smoke curves as representative workload scaling.

**Evidence:** Commit `a4ea377570d730a32000cf376f29ff500da84a3b`
enabled only the predeclared publication fields in the existing Q4 driver and
changed the T1203 two-repetition smoke artifact to withhold all 42 per-point
median/IQR distributions. Its replacement SVG says that the raw rows remain
diagnostic and that `graph_size_scale` jointly changes support width and token
byte length. `env PYTHONDONTWRITEBYTECODE=1 .venv/bin/python
scripts/exact_commit/run_q4_scaling.py --config
configs/experiments/q4_scaling_publication_v1.toml` ran 27 generated settings,
10 repetitions and both backends in isolated 2 GiB workers: 540/540 `OPTIMAL`,
zero censored/timeouts/errors, and zero mismatches across 270 Python/Rust
pairs. Slots and top-`K` reached 16; grammar productions reached 32; compound
graph size and token byte length reached 8; proposal count reached 16.
`python scripts/exact_commit/summarize_q4_publication.py --raw-input
results/raw/q4_scaling_publication_v1/q4_scaling_publication_v1-20260901T030111Z/q4-scaling-rows.jsonl`
independently recomputed all witness objectives and selected IDs before
pinning `docs/artifacts/raw/m125_publication_results_v1/q4-scaling-rows.jsonl`
(SHA-256
`63abf6a974bdd74f20b34f7f80e9c3d646a30f9385f359a76a4747c86f8eef51`)
and `docs/evidence/t1255-q4-publication-summary.json` (SHA-256
`8570ee64c462a8139302867be56a8abc3c7f116cbb589f363a4c29807b5505f1`).
Every one of the 54 backend/point distributions contains 10 successful,
uncensored runtimes and reports median/IQR separately by backend. `python -m
pytest -q tests/exact_commit/test_t1255_evidence.py
tests/exact_commit/test_q4_scaling.py tests/exact_commit/test_final_artifacts.py
tests/exact_commit/test_t1203_evidence.py
tests/exact_commit/test_publication_evidence_policy.py` -> 20 passed; `make
final-artifacts-check` passed; `make check` -> 10 unit and 621 exact tests
passed; `make paper` -> 15 pages.

## T1256 — Freeze the experiment and artifact architecture

**Depends on:** M12 gate

**Review finding:** 7 — the infrastructure has reached the overengineering
boundary.

- [x] Record that M13 may reuse the existing config, metadata, raw/processed,
  statistics, and final-artifact paths but must not add another generic layer.
- [x] Treat T1201's two-row inventory and T1202's synthetic formula artifact as
  internal validation fixtures, not scientific findings.
- [x] Treat the T1203 Q1--Q5 bundle as the only current scientific-result bundle.
- [x] Prohibit a plugin system, workflow engine, artifact schema, charting
  framework, database, dependency-injection layer, second statistical library,
  or second raw/processed convention during M12.5/M13.
- [x] Split a large module only when a required modification makes the split
  necessary; do not refactor solely for file size or aesthetics.

**Acceptance criteria**

- [x] M12.5 and M13 add no generic infrastructure unrelated to a concrete task.
- [x] Internal pipeline fixtures are not imported or cited as research results.

**Evidence:** ADR 0021 freezes the existing configuration, metadata,
raw/processed, statistics, and final-artifact layers for M12.5/M13; lists the
prohibited generic infrastructure; limits future splitting to required
functional changes; and classifies T1201/T1202 as internal fixtures. It keeps
T1203 as the only currently assembled Q1--Q5 scientific-result bundle while
classifying `m125_publication_results_v1` as staged evidence consumed through
the same paths. `git diff --name-status
4deb73c7094004aedb5de8b2c3db20d57e353e89..HEAD` was reviewed: the M12.5
changes are task-specific configs, drivers, validators, evidence, tests, and
corrections to existing layers; no generic replacement layer was added.
`python -m pytest -q tests/exact_commit/test_t1256_architecture_freeze.py
tests/exact_commit/test_publication_evidence_policy.py` -> 7 passed.

## T1257 — Clarify the meaning of the existing final-results name

**Depends on:** T1203, T1252

**Review finding:** 8 — `final-results` can be mistaken for final empirical
evidence even though parts of the bundle are diagnostic.

- [x] Keep the T1203 bundle ID and pinned raw input paths/hashes stable; update
  derived hashes only through the existing generator when presentation changes.
- [x] Add a prominent generated-manifest, reproduction, and M13-source note that
  "final" means deterministic output of that artifact build, not publication-
  level benchmark status.
- [x] Require any later publication-mode evidence to use a new bundle ID and
  never overwrite `t1203_final_results_v1`.
- [x] Add a regression that keeps the clarification synchronized across the
  processed bundle and documentation.

**Acceptance criteria**

- [x] A reader following the T1203 manifest or reproduction guide encounters
  the diagnostic-status clarification before interpreting its results.
- [x] Existing artifact provenance remains verifiable after the clarification.

**Evidence:** `FINAL_NAME_CLARIFICATION` is emitted into both
`docs/artifacts/processed/t1203_final_results_v1/final-results.json` and
`artifact-manifest.json`, and the same rule appears before results in
`REPRODUCING.md` and the `docs/artifacts/README.md` M13 source note: `final`
means deterministic build output, not publication-level benchmark status;
later publication evidence uses a new bundle ID and never overwrites T1203.
All five config-pinned T1203 raw paths and hashes remain unchanged. The existing
generator produced only new derived hashes: manifest
`28a17dcd3e054d9ab4d676793caf081bbba75eafd6513d1f751fa38436c46acb`
and results
`1dd39f7f115c5363ab6340faaee178e1ca4d48aa665f7c85d135cfb2fb03827f`;
all table/figure hashes stayed stable. `python -m pytest -q
tests/exact_commit/test_t1257_final_name.py
tests/exact_commit/test_final_artifacts.py
tests/exact_commit/test_t1203_evidence.py` -> 9 passed; `make
final-artifacts-check` passed; `make check` -> 10 unit and 626 exact tests
passed.

## T1258 — Set the article result and page budget

**Depends on:** T1252, T1257

**Review finding:** 9 — inserting all seven artifacts would exceed the
institutional 16-page limit.

- [x] Select at most three compact result elements for the article body.
- [x] Prefer replacing expected-results placeholders over appending new tables
  and figures.
- [x] Record which remaining artifacts stay in the repository or approved
  supplementary material.
- [x] Define a page-budget allocation including references and the required
  summaries before T1301 imports results.
- [x] Keep every omitted artifact traceable from the reproduction guide.

**Acceptance criteria**

- [x] The versioned article plan stays within the 10--16 page regulation without
  silently shrinking required content or claiming an unmeasured final page count.
- [x] T1301 depends on this selection and does not append all generated artifacts.

**Evidence:** `docs/article/M13_RESULTS_AND_PAGE_BUDGET.md` selects exactly
three compact body elements: R1 combines Q1 correctness and Q3 finite-slot
evidence, R2 separates illustrative Q2 cases from the bounded T1254 real-state
replay, and R3 combines selected T1255 Q4 scaling facts with the structured Q5
integration result. It requires replacement of `tab:resultados` and removal of
the obsolete `tab:cronograma`, lists all seven T1203 artifacts retained in the
repository/supplement, and keeps them indexed by `REPRODUCING.md`. The planning
allocation is 14.25 pages including summaries and references, with 1.75 pages
of contingency under the 16-page maximum; it explicitly preserves template
font/margins and calls the final count unmeasured until T1301 rebuilds the PDF.
`python -m pytest -q tests/exact_commit/test_t1258_article_budget.py` ->
5 passed. `make paper` passed and `pdfinfo paper/main.pdf` reported the current
pre-import baseline as 15 pages; this is not a final page-count claim.

## T1259 — Decide and normalize repository/article language

**Depends on:** T1258

**Review finding:** 10 — repository and article terminology are mixed between
English and Portuguese.

- [x] Record the article-language decision before editing result prose; use an
  English body unless an institutional or advisor constraint is documented.
- [x] Apply English consistently to the article body, section titles,
  theorem/algorithm names, captions, code, and repository terminology.
- [x] Preserve the institutionally required Portuguese `Resumo` and provide a
  matching English `Abstract`.
- [x] Translate `IMPLEMENTATION_PLAN.md` or archive it with a clear supersession
  notice if `TASKS.md` and ADRs have replaced it.
- [x] Add a terminology review for `exact_on_support`, statuses, finite slots,
  proposals, witness, fallback, and baseline names.

**Acceptance criteria**

- [x] Mixed-language prose remains only where institutionally required or where
  a cited title/quotation must retain its original language.
- [x] Language normalization does not alter scientific claims or generated data.

**Evidence:** ADR 0022 selects an English title/body, English theorem and
algorithm names and captions, an institutionally required Portuguese `Resumo`,
and a matching English `Abstract`; it also fixes the meanings of
`exact_on_support`, all five solver statuses, finite slots, proposal, witness,
progress fallback, and the `serial | epic | exact` strategies. The 1,030-line
Portuguese implementation plan is preserved verbatim at
`docs/history/IMPLEMENTATION_PLAN-legacy-pt.md` (SHA-256
`fefe0b6f250e75c887455fcf3fe3459fa5d1be3fc92a385aef42dc0428c07f33`),
while its root path now indexes maintained English sources. A structural
pre/post translation check found identical sets/counts for 20 citations, 23
labels, 13 references, 20 equation environments, one align environment, three
algorithms, four theorems, three definitions, two propositions, and 34
placeholders. `python -m pytest -q
tests/exact_commit/test_t1259_language_and_terminology.py` -> 3 passed;
`make check` -> 10 unit and 634 exact tests passed; `make paper` passed and the
normalized article remained 15 pages. No generated artifact or measured result
changed. A final requirement-by-requirement audit then found two active
Portuguese paper-support documents that the original regression did not cover.
`paper/README.md` is now English and the translated checklist is
`paper/FIELDS_TO_FILL.md`; the former Portuguese checklist path was removed.
The added regression scans both active documents and rejects the old filename
and Portuguese headings. `python -m pytest -q
tests/exact_commit/test_t1259_language_and_terminology.py` -> 4 passed; `make
check` -> 11 unit and 645 exact tests passed; `make paper` still produced 15
pages. This documentation-only correction changed no generated artifact or
measured result.

## T1260 — Add artifact-rebuild and source-rerun rehearsals

**Depends on:** T1250, T1251, T1252, T1253, T1254, T1255

**Review finding:** 11 — the current clean-clone rehearsal rebuilds artifacts
from pinned rows but does not rerun the source experiment.

- [x] Name and document two distinct rehearsal levels:
  `artifact-rebuild` (pinned raw rows to generated output) and
  `source-experiment-rerun` (code plus config to new raw rows and output).
- [x] Keep byte-for-byte comparison for deterministic artifact rebuilds.
- [x] For the CPU correctness source rerun, compare case IDs, statuses,
  objectives, agreement counts, and certificate validity while excluding timing
  fields from byte-identity requirements.
- [x] Run the release-oriented rehearsal from a clean checkout and non-editable
  wheel install so packaging and source availability are tested together.
- [x] Document which GPU/model experiments remain external or optional and do
  not claim they were rerun when they were not.

**Acceptance criteria**

- [x] Both rehearsal levels have distinct commands, expected artifacts, and
  failure conditions.
- [x] A deterministic test proves that a semantic correctness mismatch fails the
  source-rerun rehearsal even when timing fields differ legitimately.

**Evidence:** `REPRODUCING.md` defines `make rehearse-artifact-rebuild` and
`make rehearse-source-correctness` with separate inputs, temporary outputs,
comparison rules, and failure conditions; it explicitly excludes Q2/Q4 and all
CUDA/model Q5 runs from the T1260 claim. Both commands clone the clean commit,
build `mwpc-exact` from that clone, install its wheel non-editably outside the
source tree, and reject source-tree imports. On commit
`8bd5ff5c69f896e1b799f2703eafe4dc6b71d869`, `make
rehearse-artifact-rebuild` passed a recursive byte comparison of every
processed/paper output and reproduced manifest SHA-256
`28a17dcd3e054d9ab4d676793caf081bbba75eafd6513d1f751fa38436c46acb`.
`make rehearse-source-correctness` additionally built and non-editably
installed the independent Rust binding, reran all 249 configured Q1 cases, and
reported `comparison=PASS`, 249 agreements, 334 independent certificate
validations, semantic-summary SHA-256
`8658c44a1d442e7dd63cc434ab65386daf66605d4baa18ba49015a1cf55fe682`,
and table SHA-256
`ea89d63ff989a629a0d60b05335d306b8f2de0401b591b9f5bd314d0cda17f9a`;
timing fields were not compared. The first source run exposed that infeasible
rows correctly omit optimal-certificate checks; the comparator now maps that
absence to zero only for non-`optimal` rows, with a deterministic regression.
`python -m pytest -q tests/exact_commit/test_t1260_correctness_rehearsal.py
tests/exact_commit/test_reproduction_instructions.py` -> 9 passed; `make
check` -> 10 unit and 640 exact tests passed.

## T1261 — Archive completed M11/M12 task detail

**Depends on:** T1250, T1251, T1252, T1253, T1254, T1255, T1256, T1257,
T1258, T1259, T1260

**Review finding:** 12 — the active task file is large and its next work is hard
to locate.

- [x] Archive the complete M11/M12 task text and evidence under
  `docs/history/TASKS-through-M12.md` without losing prior history links.
- [x] Replace completed M11/M12 detail in this file with a concise summary and
  stable links to evidence and the archive.
- [x] Keep M12.5 and M13 in full detail until their gates close.
- [x] Verify that task IDs, dependencies, evidence links, and current starting
  point remain unambiguous after the move.

**Acceptance criteria**

- [x] A new agent can identify the first incomplete task and its dependencies
  without reading completed command logs.
- [x] No completed evidence or blocking scientific contract is lost.

**Evidence:** `docs/history/TASKS-through-M12.md` preserves the prior M11/M12
range byte-for-byte after its 16-line archive header and links the earlier
M0--M10 archives; its SHA-256 is
`b649031694f399cb3a3379129ad7211c1796a0e1abde8fb7ccbfcec9d3ce429a`.
The active file fell from 1,297 to 787 lines, retains M12.5 and M13 in full,
states that the M12.5 gate audit is current and T1300 is the first remaining
task after that gate, and replaces only M11/M12 command logs with task-ID and
artifact entry points. `python -m pytest -q
tests/exact_commit/test_t1261_task_archive.py` -> 4 passed. A direct `diff` of
the archived body against lines 43--575 of the pre-archive
`355150d:TASKS.md` produced no differences; all versioned links checked by the
regression resolve.

**M12.5 review-fix gate — complete**

- [x] The installed wheel contains and exercises both Python packages.
- [x] Q1 statistical presentation distinguishes fixed and random case families.
- [x] Evidence tier, genuine EPIC execution, and any selected Q2/Q4 expansion
  are versioned without promoting diagnostics.
- [x] Artifact naming, architecture freeze, page budget, and language are settled.
- [x] Both reproduction levels pass and completed M11/M12 detail is archived.
- [x] No correctness gate regresses and no unsupported article claim remains.

**Gate evidence:** commits `2c3092e` through `6a8f747` implement and document
T1250--T1261. Follow-up commit `f47ee05` keeps optional EPIC/Rust imports out of
the generic test environment while explicitly exercising the affected Q2/Q5
tests in the pinned EPIC job. GitHub Actions run
[`33467321623`](https://github.com/j0taaa/tcc-final/actions/runs/33467321623)
passed all three jobs at `f47ee05837dcd8a66bbf353391fc49a3548bea98`:
lightweight verification and release-wheel rehearsal, production Rust/full
correctness campaigns, and pinned EPIC integration. The final local audit
passed `make check` (11 unit and 644 exact tests), `make test-rust-parser` (20
Rust tests plus formatting and Clippy), `make release-wheel-smoke`, `make
final-artifacts-check`, `make paper` (15 pages), the 500-case M6 and 500-case
M7 oracle campaigns, the ten pinned-EPIC integration tests, and the six-case
Q2 smoke. T1260 separately records passing clean-clone artifact-rebuild and
source-experiment-rerun rehearsals. ADR 0016, the T1257 artifact clarification,
and the T1258 result budget prevent diagnostic evidence from being promoted to
publication claims; no CUDA/model experiment is claimed as rerun by this gate.
The final requirement-by-requirement audit is versioned at
[`docs/evidence/m125-completion-audit.md`](docs/evidence/m125-completion-audit.md).
It found and corrected the remaining T1259 paper-documentation language gap in
commit `7b0d9aabeeaa3388b4b652b9e24d66f0da9b784d`; GitHub Actions run
[`33468417087`](https://github.com/j0taaa/tcc-final/actions/runs/33468417087)
then passed all three jobs, including both 500-case oracle campaigns, release
wheel rehearsal, pinned EPIC integration, and focused combined Q2/Q5 tests.

---

# M13 — Synchronize implementation with the TCC

## T1300 — Fill implementation-method fields in LaTeX

**Depends on:** M12.5 gate

- [x] Insert exact repository and upstream commits.
- [x] Insert module/backend architecture.
- [x] Insert grammar normalization and epsilon handling.
- [x] Insert tokenizer byte semantics.
- [x] Insert support/top-`K` policy and exactness wording.
- [x] Insert candidate/weight policy.
- [x] Insert EOS/PAD, timeout, tie, and fallback behavior.
- [x] Insert model, tokenizer, hardware, and software versions.

**Acceptance criteria**

- [x] No implementation field is filled from memory when an artifact can provide it.
- [x] Paper claims match the actual code path.

**Evidence:** commit `02aabd239a3d76ef4d9176c6d8257651c27af5ac`
fills the method fields in `paper/main.tex` and keeps the parent license status
explicitly pending rather than inventing one. Repository/upstream provenance
comes from `docs/evidence/m125-completion-audit.md` and `UPSTREAM.md`; grammar,
epsilon, tokenizer, support, proposal, EOS/PAD, timeout, tie, and fallback
semantics come from ADRs 0001--0013 and their referenced implementation paths.
The exact model/tokenizer revision and vocabulary audit come from
`docs/evidence/t600-llada-tokenizer-audit.json`; Q5 schedules, support, weights,
specials, and protocol come from
`configs/experiments/q5_structured_publication_v4.toml` and
`configs/experiments/q5_structured_tasks_v4.toml`; hardware/software values
come from the pinned Q4 summary and Q5 raw JSONL metadata under
`docs/artifacts/raw/m125_publication_results_v1/`. The paper now states that
the live path uses a raw-byte CFG without a production lexical transducer,
reports only per-step `exact_on_support`, retries wider support only after
`INFEASIBLE_ON_SUPPORT`, and preserves non-optimal statuses and baseline
separation. `python -m pytest -q
tests/exact_commit/test_t1300_paper_method.py` -> 6 passed; `make check` ->
11 unit and 651 exact-commit tests passed; full `python -m pytest -q` -> 672
passed. `make paper` passed and `pdfinfo paper/main.pdf` reported 16 pages.
Poppler renders of pages 1--2 and 11--16 were visually checked with no
clipping, overlap, unreadable table text, or broken identifiers. Advancing the
active pointer exposed a stale T1261 test that hard-coded T1300 as the next
task; `tests/exact_commit/test_t1261_task_archive.py` now deterministically
expects T1301 while continuing to protect the archived M0--M12 content.

## T1301 — Fill and analyze results

**Depends on:** M12.5 gate, T1258

T1301 must follow `docs/article/M13_RESULTS_AND_PAGE_BUDGET.md`: replace the
two named placeholder/planning tables with R1--R3 and does not append all
generated artifacts.

- [x] Import generated tables/figures.
- [x] Report correctness campaign size and agreement.
- [x] Analyze heuristic gaps.
- [x] Analyze finite-slot findings.
- [x] Analyze runtime/memory and the dominant component.
- [x] Analyze end-to-end validity, fallbacks, and limitations.
- [x] Report negative or null findings honestly.

**Acceptance criteria**

- [x] Every number is generated by a script and traceable.
- [x] No smoke-test result is presented as a benchmark conclusion.

**Evidence:** commit `844dc68c34d49e31253aff799fdd9e6f89471108`
adds the task-specific `m1301_article_results_v1` builder and immutable config,
which pin seven T1203/M12.5 inputs by SHA-256 and generate one processed value
map, LaTeX macros, and exactly the three R1--R3 tables selected by T1258. The
paper replaces `tab:resultados` and `tab:cronograma`; it reports configured Q1
agreement and certificate checks, illustrative versus singleton-support Q2
evidence, both Q3 finite-slot outcomes, separate Python/Rust Q4 timing and
memory with the compound-axis qualification, and Q5 validity, real EPIC
batching, serial fallback events, exact certificates, and bounded-task runtime
ratios. It explicitly withholds population, realistic-workload, full-vocabulary,
and broad output-quality conclusions. `make article-results-check` reproduced
processed SHA-256
`f2ebbe091d5b00a6324d1c13c8b6058bcec6ed3c10e9511ed6e6eaca3a42ddb0`
and table hashes `fa7f50a8`, `621b589d`, and `354d77b4`; `make
final-artifacts-check` preserved the T1203 manifest hash `28a17dcd`. Focused
generator, budget, method, reproduction, and architecture tests -> 21 passed;
`make check` -> 11 unit and 655 exact-commit tests passed; full `python -m
pytest -q` -> 676 passed. `make paper` passed with no overfull box or unresolved
reference, and `pdfinfo paper/main.pdf` reported 16 A4 pages. Poppler renders
of all 16 pages were visually inspected; the three result tables are legible
with no clipping or overlap.

## T1302 — Update limitations and theorem-to-code correspondence

**Depends on:** T1300, T1301

- [x] State exact-on-support limitations.
- [x] State tokenizer and byte-level language limitations.
- [x] State the CFG syntax-versus-semantics limitation.
- [x] State per-step versus trajectory optimality.
- [x] State timeout and resource limits.
- [x] Add a table mapping theorem assumptions to code/config enforcement.

**Acceptance criteria**

- [x] No theorem assumption is silently violated by the reported experiment.

**Evidence:** commit `4cabaef8b98c1f7e973e0205ef2d9214da426e0e`
expands Section~10 of `paper/main.tex` and adds Table~5, which maps Theorems
1--4 and the decoder propositions to executable weight, CNF/parser,
support/EOS, tokenizer-byte, validation, and monotone-commit boundaries. The
paper now states top-K and per-step scope, raw-byte/no-lexer semantics,
syntax-versus-semantics, timeout-versus-infeasibility, and time/memory limits.
The audit also resolves two presentation ambiguities: the upstream
`low_confidence` label ranks still-masked baseline candidates but exact Q5
never remasks, and the lexicographic tie/cardinality-chart variants are named
unimplemented rather than implied as active. The Q5 config-to-execution
regression in `tests/exact_commit/test_t1302_paper_limitations.py` protects
these claims. `make article-results-check` reproduced the pinned processed and
R1--R3 hashes; the focused T1261/T1302 regressions passed 9 tests; `make check`
passed 11 unit and 660 exact-commit tests; full `python -m pytest -q` passed
681 tests. `make paper` passed without overfull boxes or unresolved references, and
`pdfinfo paper/main.pdf` reported 16 A4 pages. Poppler renders of all 16 pages
were visually inspected with no clipping, overlap, broken glyphs, or
unreadable tables.

## T1303 — Fill AI-use declaration

**Depends on:** T1300

- [x] Name tools, providers, and versions used.
- [x] State purposes: planning, drafting, review, coding assistance, and related uses.
- [x] Identify affected sections/components.
- [x] State that the author reviewed proofs, code, references, and results.
- [x] Ensure no fabricated data or unattributed text is included.

**Acceptance criteria**

- [x] Declaration satisfies the institutional regulation.

**Evidence:** commit `cca3f889342a0711b36ab9124f9c4ea3f32f7f39` replaces the placeholders with `paper/main.tex`'s `AI-Use Declaration` and closes the paper checklist. It names OpenAI Codex/OpenAI, Codex CLI 0.151.0, the GPT-5 basis, and the unexposed immutable hosted-build ID; purposes and affected manuscript/Python/Rust components; author review/responsibility; and excluded AI-proposed measurements, fabricated data, AI-generated figures, and unattributed text. Focused regression -> 3 passed; `make check` -> 11 unit + 663 exact tests; full pytest -> 684 passed; `make paper` -> 16 A4 pages; all-page Poppler inspection (pages 15--16 full-size) found no clipping, overlap, broken glyphs, or crowded references.

## T1304 — Create final reproducibility release

**Depends on:** T1301, T1302, T1303

- [x] Run full Python tests.
- [x] Run Rust tests and formatting.
- [x] Rebuild bindings.
- [x] Re-run publication configs or verify immutable artifacts.
- [x] Build the final LaTeX PDF.
- [x] Create a release tag.
- [x] Archive configs, small raw evidence, processed data, figures, tables, and reproduction instructions.
- [x] Record known limitations and any non-reproducible external dependency.

**Acceptance criteria**

- [x] Repository and paper point to the same release commit.
- [x] Worktree is clean or intentional untracked artifacts are documented.

**Evidence:** release payload commit `08f59455620630c3b5b0e29f69171af69f515662` is the dereferenced annotated tag [`v0.1.0`](https://github.com/j0taaa/tcc-final/releases/tag/v0.1.0) named by the repository and paper. The published release archives 132 config/raw/processed/evidence/table/figure/source/reproduction entries in `mwpc-exact-v0.1.0-evidence.tar.gz` (SHA-256 `e1ae69b6c9e2dbfd1cf69de6c2de2e9d47665a9573e6f9d911ca92f5bfbbf8d5`) plus the 16-page PDF (SHA-256 `5ba5858c549b063ffab0f965407009f3f29339077aee4187fe12cd4dd01716ab`); local and GitHub asset digests agree. `docs/releases/v0.1.0.md` records the exact archive command, scientific boundaries, external EPIC/model/toolchain dependencies, private-release/licensing constraint, and the three author-only identification fields. Gates: full pytest 688 passed; `make check` 11 unit + 667 exact tests; rebuilt PyO3 binding; Rust formatting/Clippy plus 17 unit and 3 randomized tests passed; M4 2000/2000, M5 500/500 + 2000/2000, M6 500/500 + 2000/2000, and M7 500/500 + 2000/2000 differential cases had zero failures; immutable artifact checks reproduced T1203 manifest `28a17dcd3e054d9ab4d676793caf081bbba75eafd6513d1f751fa38436c46acb`; clean-clone artifact rebuild matched byte-for-byte and source rerun reproduced 249/249 agreements with 334 certificate validations; release-wheel installation/import/experiment/artifact smoke passed; `make paper` and all-page Poppler inspection passed at 16 A4 pages. GitHub Actions run [`33554812631`](https://github.com/j0taaa/tcc-final/actions/runs/33554812631) passed verify, Rust correctness, and pinned EPIC integration. The tagged and final bookkeeping worktrees were clean; ignored local copies in `dist/release-v0.1.0/` correspond to the published checksummed assets.

**Required project completion gate**

- [x] M0–M13 complete.
- [x] All scientific-contract rules in `AGENTS.md` hold.
- [x] Correctness evidence is 100% on configured oracle campaigns.
- [x] Exact end-to-end mode and baselines are reproducible.
- [x] TCC contains no fabricated or unsupported implementation/result fields.

---

# OPTIONAL O1 — Exact cardinality budget

## O100 — Extend objective with `|B| <= k`

**Depends on:** Required project stable

- [ ] Add a budget dimension or formally equivalent semiring/state construction.
- [ ] Prove recurrence and complexity.
- [ ] Compare with candidate-set truncation semantics.
- [ ] Add brute-force tests.

**Acceptance criteria**

- [ ] Exact budgeted solver agrees with exhaustive subsets.

---

# OPTIONAL O2 — Deterministic lexer transducer

## O200 — Replace byte grammar with token-lattice × lexer composition

**Depends on:** Required byte-level path stable

- [ ] Define lexer state, maximal munch, priority, whitespace, comments, and keyword rules.
- [ ] Compose without losing token provenance or slot count.
- [ ] Validate against an independent lexer on complete strings.
- [ ] Reuse lexeme-level EPIC CFGs only when semantics match exactly.

**Acceptance criteria**

- [ ] Every accepted witness produces the same lexeme sequence as the declared lexer.

---

# OPTIONAL O3 — Incremental parsing across denoising steps

## O300 — Reuse chart/lattice state safely

**Depends on:** Required solver correct and profiled

- [ ] Identify unchanged graph regions between steps.
- [ ] Define invalidation rules.
- [ ] Preserve exactness under updates.
- [ ] Compare incremental and full-recomputation certificates.

**Acceptance criteria**

- [ ] Scores and certificates match full recomputation on all tests.

---

# OPTIONAL O4 — Lazy/full-vocabulary support

## O400 — Add trie/lazy token expansion

**Depends on:** Required top-`K` solver stable

- [ ] Share token byte prefixes without merging token provenance.
- [ ] Generate arcs lazily from parser demand or admissible-prefix analysis.
- [ ] Prove pruning safety.
- [ ] Compare with explicit full support on small vocabularies.

**Acceptance criteria**

- [ ] Lazy and explicit support return equal optimum and valid provenance.

---

# Historical v0.1.1 evidence index

Fill this section only with real artifacts.

- Baseline commit: `b9f2179caadf8640fe026f7a73833cbda9755876`
- Upstream EPIC commit: `5b1b31098f34ed3691d2a9f4aae14fdf5839d072`
- Token-aligned correctness artifact: `docs/evidence/m3-differential-summary.json`
- Rust/Python differential artifact:
  `docs/evidence/m5-rust-differential-normal-summary.json`
- Finite-slot counterexample artifact:
  `docs/evidence/t703-finite-slot-counterexamples.json`
- Heuristic-gap experiment artifact:
  `docs/evidence/t1102-q2-heuristic-gap-summary.json`
- Scaling experiment artifact: `docs/evidence/t1255-q4-publication-summary.json`
- End-to-end experiment artifact: `docs/evidence/t1253-q5-publication-summary.json`
- Parent release license: MIT; scope and release evidence in
  `docs/evidence/submission-license-release.md`
- Reproduction release/tag: [`v0.1.1`](https://github.com/j0taaa/tcc-final/releases/tag/v0.1.1), commit `3db85bb0ec7e4416352b74832e8a6750af8bcaf2`
- Final TCC PDF/source commit: [`mwpc-exact-v0.1.1-paper.pdf`](https://github.com/j0taaa/tcc-final/releases/download/v0.1.1/mwpc-exact-v0.1.1-paper.pdf), source tag `v0.1.1`

## Current v0.2.0 evidence index

- Local release: docs/releases/v0.2.0.md; no remote publication.
- Review corrections: docs/reviews/2026-09-22-resolution.md.
- Verification: docs/evidence/m17-review-verification.json.
- Immutable new measurements: docs/artifacts/raw/m17_review_v1/.
- Generated analysis: paper/generated/m17_review_v1/summary.json.
- Revised PDF: dist/mwpc-exact-v0.2.0-paper.pdf, source tag v0.2.0.
- Source delivery: dist/mwpc-exact-v0.2.0.bundle; checksums in dist/SHA256SUMS.

- [x] T3902: Finish the preregistered growing-support development campaign
  (`f675fe3`, MDLM/CUDA, 19 controls, 1,026 rows). 939 complete, 888 equal
  trajectories, no unexplained divergence, 0/18 strong wins. Full archives
  and immutable raw SHA: attempt19/work/evidence/development-*. No expansion
  to heldout/fresh or CPU under failed gate; this does not fulfill utility goal.

- [ ] T4000: Audit all-state lexical token quotient for model-driven growing
  JSON supports (attempt20), compare equally optimized byte AND token-level
  lexer controls. Preserve original token trajectories, account per-request
  classification/preparation and all model forwards. Prove congruence and
  stability under same-class expansion; credit classical lexer and FactorDLM.
  Predeclared success is representation benefit, not algorithm exclusivity.

- [x] T4001: Execute all864 preregistered attempt20 MDLM/CUDA rows. 795
  complete, 744 equal comparisons, 0/18 strong wins for primary and secondary.
  Global-class candidate fails development gate versus equally lexical controls;
  no heldout/fresh/CPU expansion. Preserve data in attempt20/work/evidence.
- [ ] T4100: Investigate context-specific overlapping token groups with explicit
  incoming lexer states, original-ID queries and growth checks. Compare against
  ALL competent byte/lexer/global-class controls; no gate relaxation.

- [x] T4101: Implement isolated context-aware grouped lattice, GAC original
  membership retention, native SAT OR selectors and exact lex argmax on group
  members. Offline product oracle covers144 GAC/root trajectories, optional SAT
  adds72; mutation scanner oracle3000 cases; all19 fake-driver methods agree.
  Commitment ambiguity and support-contract regression included. Benefit pending.

- [x] T4102: Finish all1026 contextual-development MDLM/CUDA rows. 948
  complete, 897 equal comparisons, zero strong wins primary/secondary against
  all noncontextual controls. Archive commands/data/statuses/provenance.
  Do not weaken gate or expand this candidate to heldout/fresh. Utility goal open.


- [x] T4203: Preserve incomplete v1 full-vocabulary campaign (116/216 rows,
 91 complete,25 refusals), explicit interruption. Do NOT call it confirmed:
 add per-position reachable-state quotient as competent comparator; increase
 count guards10x, keep120s/8GiB physics equally. Written proof/oracles cover
 all FOUR exact representations, including clamps and remasking. Freeze v2
 before timings on SAME archived full model floats; no fresh case evaluated.


- [x] T4201-v3: Complete all270 full-V development records,208 conclusive,
 62 resource refusals,6/18 strong primary wins vs raw/global/PER-POSITION
 quotients. Same actual full model floats, CPU+wall include shared forward,
 conversion, per-frame compile and all original marginals.3GiB/120s equal,
 count guards10x and supervisor150s. Preserve BOTH interrupted prior campaigns.
 No sampling win vs rejection, no fresh confirmation/novelty claim yet.
- [x] T4204: Independently enumerate ALL50258 original tokens in24 disclosed
 one-hole/clamped frames;96 comparisons exact in4 representations,1,206,192
 candidates. No new forward or performance claim. Code and evidence in22/work.

M42 v5 strengthening before timings: all methods coarsen NUMBER/Boolean/null
syntax terminals identically, keeping original identities. Independent
predictive stack control includes lexical coaccessibility, memoization, summed
target arcs and safe suffix necessary bounds; no guessed depth limit. Five
tiny independent checks pass across nine exact kernels, including primitive
values, recursive arrays, sampler law, aliases and incompatible reuse shapes.
Commands: `.venv/bin/python -m unittest attempts.22-full-vocabulary-posterior.work.test_correctness`;
The full-V rerun passes216 exact comparisons (24 one-hole frames ×9 kernels,
1,206,192 original choices recognized by strict UTF8/Python JSON). Evidence:
`work/evidence/stack-and-coarsening-full-vocabulary-oracle.json`. Frozen-source
timing is pending.

M42 v5 measurement interrupted171/540 (144 complete,27 localized refusals),
all preserved in `work/evidence/development-v5-partial`, producer7f25848.
One first-rotation bidir_local16-hole case was11.93s versus15.99s stack, but
NOT a passed gate. Before independent capture, standard per-layer residual-stack
suffix-bound caching and direct primitive consumption strengthen the control;
`stack-counter-cache-addendum.json` records this v6 refinement. Repeat every
development case; do not treat initial speed against repeated scans as final.

M42 v6: whole campaign stopped411/540 (331 complete,80 localized refusals).
Negative-only post-hoc audit of unchanged necessary conditions proves zero
possible strong wins for either candidate in all18 configurations, regardless
of129 remaining timings. Missing rows are not fabricated. Commands/modules:
work.audit_futility and work.analyze, evidence/development-v6-partial. No
independent neural capture and no confirmed scientific benefit. Continue M43.

M43 v1 negative:262/702 original records, plus TWO post-hoc negative-only
paired repeat1 probes of sole unrefuted eps_global0bb39717-4. Full raw original,
supplement and disjoint combined view are retained, with provenance explaining
reordered timing; no positive claim from this probe. Necessary-condition audit
rejects all THREE epsilon variants in all18 configurations regardless of438
missing records. No new independent neural capture; preserve23, continue M44.
