# A68 — Sample a Bernstein increment without evaluating its full coefficient

2026-10-17. Written BEFORE new implementation or scientific execution. A67's
generic locality claim stays withdrawn. This adopts its strongest CLASSICAL
n-1 control as the starting operator, not as an own approximation invention.

1. **Operation/use.** An exact-simulation library accepts an unknown-p coin
   and a supplied smooth probability link f, and returns Bernoulli(f(p)).
   Existing BernoulliFactory.jl and general-factory interfaces identify this
   numerical operation independently of our benchmark. The narrower operation
   here is sampling each normalized Bernstein increment using a value callback
   for f. No dLLM application is established; this is the separately authorized
   numerical-library TCC scope. A decoder-verifier p-coin is only a possible
   interface, not measured use or an assumption of cheap model forwards.
2. **Own candidate.** Derive an explicit f-INDEPENDENT hypergeometric residual
   envelope whose known mass fits inside the positive-mixture increment. It
   permits a deterministic cap of NINE f-value calls for a complete output,
   irrespective of degree/curvature metadata. Finite differences, quadratic
   quasi-interpolation, control variates, importance sampling, positive series,
   rejection and binary splitting are CLASSICAL. Candidate significance is
   the complete certified constant-query specialization, not those principles.
   Priority and adequate publication significance are still OPEN.
3. **Comparative consequence.** At the SAME enlarged envelope/count law, the
   output law is exactly that of dense coefficient evaluation, with <=9 value
   calls instead of a growing grid. A written exact-coefficient oracle lower
   bound is restricted to EVALUATING that coefficient, not all competing
   samplers. The tighter H-envelope classical factory uses fewer input coins;
   retain it, direct polynomial/analytic factories, caching, lazy bounds and
   generic signed-estimation/importance controls. No full-cost victory yet.
4. **Proof first.** theory-v1.md writes residual identity, pointwise envelope,
   mass bound9H/(8m^1.5), safe Bernoulli mixture and conditional/unconditional
   laws. At most six setup calls plus three on an optional branch. The larger
   envelope2H increases the written input mean to n0+24H/sqrt(n0); explicitly
   charge that cost. New proof is written, not Lean/human review/software proof.
5. **Bounded initial validation.** protocol-v1.json fixes independent rational
   checks of EVERY residual on the original six functions and two degrees,
   both stencil directions, exact mixture laws and callback counts. No random
   frequencies can prove exactness. No full production sampler, timing/model
   campaign before the resource/priority comparison justifies one.
6. **Full costs.** Computing/sampling the envelope still costs arithmetic and
   auxiliary bits. Known rational weights have a theoretical fast-arithmetic
   O(m polylog m) route; naive Fraction tables do not inherit it. Count all
   source coins, callback bit costs, hypergeometric preparation and unranking,
   auxiliary RNG, output and memory. A low query cap is not a speed claim.
7. **Fatal objections.** The explicit construction may be a minor or previously
   used specialization of classical importance/control-variate methods. Cheap
   f, available derivatives/closed forms, full-grid caching, or the enlarged
   input count can make it worse. Known-value integration can use the same
   envelope machinery. An all-method complexity lower bound is NOT claimed.
8. **Article gap.** Audit closest quantitative constructions, validate all law
   identities, implement charged exact arithmetic and show a useful COMPLETE
   operation against those controls for a real callback consumer. The paper
   2510.01941v2 is a close non-adaptive antecedent, not an unanswered generic
   existence problem. No priority, practical win, acceptance or fulfilled user
   goal is claimed from this initial proof/finite audit.

No mutable imports from other attempts. Source reading scopes/hashes are in
work/primary-v1.md. Historical A67 proof/data remain unchanged. Progress on
this candidate does not promote the old operator or reopen closed neural uses.

V1 contractad5a55b/sourceb5064b2 precede ONE PASS/direct0:966 exact laws,
40134 residual/callback checks,966 mass/term/setup checks,21 zero-H points,
1032 collected oracle weights9 refusals. Enumerated paths need at most9
f-values; no complete sampler or timing/NN evidence. Enlarged2H still pays
more input coins; next sharper slope bound is a separate POST-audit lead.
See[the V1 result](work/result-v1.md). Own useful priority/full cost/goal OPEN.

V2 re-evaluates2/3/4/6 BEFORE new code: the sharper CLASSICAL Peano slope
bound H/(3m) gives a smaller f-independent envelope and safe margin H/(28m^1.5).
It permits the SAME tighter H-gap source-count law as the competent classical
control, retaining <=9 calls. V1's input penalty is therefore removed in the
WRITTEN V2 construction, not relabeled in V1 data. Remaining criteria and
priority/full-cost/real-consumer obligations unchanged. Prospective audit and
proof in[the addendum](work/same-count-theory-v2.md), before V2 execution.

V2 proofb7acbb0/source13e5aa1 precede ONE PASS/direct0:966 exact laws,
40134 residual/callback checks,41100 sharp slope checks,966 strict margins,
21 zero-H points1032 collected weights9 guards. The written <=9-call theorem
now has the SAME tighter source-count law; the finite reference audits
conditional paths, not a complete sampler or timing. See[the V2 result](work/result-v2.md).
Closest coefficient-free/signed/retrospective controls and real complete cost
remain open; the positive scientific goal is NOT yet achieved.

V3 re-evaluates ALL eight criteria BEFORE new implementation:

1. Original2024 genetics model identifies an actual consumer: ancestry first,
   node colours later. This is a numerical simulation scope, not a dLLM claim
   or a new duality. Our bounded-range subclass excludes absorbing fixation.
2. Candidate difference is a certified quartic residual envelope with four-
   moment mass and log-concavity. General moment/rejection/mixture ideas known;
   priority and sufficient significance remain open, as in earlier versions.
3. Classical component splitting lowers cap9 to6; the quartic envelope removes
   dense proposal normalization, using O(log m) known-weight preparation and
   <=8 expected rejection attempts. SAME H-gap count/kernel; not a timing win.
4. sparse-proposal-theory-v3.md proves the explicit constants, law, log-concavity
   and shared finite-mean genealogy consequence before code. No new general
   rejection, non-explosion or duality theorem is claimed.
5. protocol-v3.json freezes bounded exact certificate/law checks, ALL old cases
   plus an explicitly prospective m256 certificate check. No full genealogy,
   production sampler/model or performance gate is activated.
6. Exact big integers, geometric RNG, source coins, preparation, memory, output
   and callback/metadata costs remain. O(log m) density queries are NOT bit
   complexity. Fast-bit route remains theoretical until implemented/audited.
7. Equally informed classic rejection, analytic/derivative methods, global
   grid caching and retrospective/signed estimators may match or beat it.
   Real genealogies can amortize cached grids; do not fabricate a slow callback.
8. Specific novelty and real full-cost advantage remain article gaps. A
   passing finite certificate is not publication or completed user goal.

V3 contractbdedd14/source5e97323 precede ONE PASS0:1347 four-moment proposals,
6735 raw moments including zeroth,211011 envelope/rejection points,208323
strict log-concavity inequalities,1347 mode/cutoff/rejection laws; all966
function laws40134 residual branches21 zero-H points8 refusals pass. Max6
callbacks; source count unchanged. No full RNG/sampler/genealogy/timing/NN.
See[the result](work/result-v3.md). Real whole-operation gain/priority and the
user goal remain OPEN; six queries alone do not settle the article.

V4 reassesses the eight criteria BEFORE runtime code. Criteria1/2/3/4 retain
the published node-vote consumer, quantitative specialization and written
guarantees, without claiming a new duality/rejection principle or priority.
Criteria5/6 now require an executable GMP/bit runtime and matched balanced
dense control, with separate source/level/auxiliary streams, explicit resource
failures and charged preparation/cache/RNG. Criteria7/8 additionally require
formula-aware spline moment integration, analytic derivatives, cheap direct
factories and scalar/global-grid cache reuse BEFORE competitive measurements.
Only a fixed correctness preflight follows; no performance/NN campaign yet.
See[the frozen contract](work/runtime-contract-v4.md). The goal stays OPEN.

V4 contract67bafcf/source5775a89 precede ONE PASS0 under isolated gmpy2 2.2.1/
GMP6.3.0:8400 balanced binomials103 varied-denominator sums,30576/13104/26208
bit-prefix cases1076 shared-uniform comparisons1347 proposals4041 weights966
conditional kernel pairs. ALL1152 complete factory calls/576 matched pairs
use24480 actual input p-coins; deliberate RESOURCE_FAIL occurs before source
calls. Cache12/18 and8 invalid guards pass. This executes the full numerical
factory, not a genealogy/NN/performance campaign or novelty confirmation.
See[the result](work/result-v4.md). Strong formula-aware/derivative/direct/
cached controls and full-cost usefulness remain open before timings.

V5 re-evaluates3/5/6/7/8 BEFORE control code: provide the SAME known formulas
to compact piecewise-polynomial/truncated-HG-moment integration and analytic
derivatives, with their own valid initial degree and persistent scalar/piece/
moment caches. Include cheap direct and non-adaptive padded polynomial
factories. Zero callback counts do not make their arithmetic free. Criteria
1/2/4 retain the operation/own-candidate/written-proof scope; these are
CLASSICAL CONTROLS, not promoted contributions. Prospective checks in
[the control contract](work/formula-control-theory-v5.md); no competitive
measurement or sufficient priority/user-goal claim yet.

V5 contract63e1ecb/source22278c0 precede ONE PASS0:2034 piece/derivative
checks7520 exact HG intervals2136 compiled kernels12 cache replays; ALL288
complete formula/derivative calls use8928 actual p-coins. Direct controls
have616 exhaustive transcripts84 complete laws6 refusals. These CLASSICAL
known-formula controls need ZERO black-box f queries and expose real algebraic
work, so oracle-query savings alone cannot justify a practical win. See
[the result](work/result-v5.md). Timings/full consumer/priority and goal OPEN.

V6 rechecks the eight criteria BEFORE control code. Criteria1/2/3/4 retain
the node-colour consumer and candidate-specific quantitative claims; the new
retrospective algorithm is a CLASSICAL CONTROL, not an own contribution.
Criteria5/6 require an exact nested-bound audit and complete numerical calls,
with full source/RNG/preparation/cache costs left for a later frozen timing
protocol. Criteria7/8 now explicitly permit the control to use our residual
envelope, descending-weight lazy integration and persistent partial bounds.
The scalar-coefficient lower bound does not constrain this sampler. Source,
proof and prospective checks in[the V6 contract](work/retrospective-control-theory-v6.md).
No large implementation/consumer campaign or completed scientific goal follows.

V6 contract7792fe9/source7439b49 precede ONE PASS0:966 full refinement
chains42066 nested intervals40134 remaining masses2448 dyadic prefixes96
cache replays;288 complete calls/8928 SIMULATED source calls and288 literal
source matches. Four guards/one explicit pre-source failure pass. This is
a stronger classical CONTROL, not a new own result; no timings/genealogy/NN.
See[the result](work/result-v6.md). Whole-cost/priority/goal remain OPEN.
